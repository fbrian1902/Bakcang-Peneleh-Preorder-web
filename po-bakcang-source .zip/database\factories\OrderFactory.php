<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Enums\FulfillmentType;
use App\Enums\OrderStatus;
use App\Models\Order;
use Illuminate\Database\Eloquent\Factories\Factory;
use Illuminate\Support\Carbon;

/**
 * @extends Factory<Order>
 */
class OrderFactory extends Factory
{
    protected $model = Order::class;

    /**
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $type = fake()->randomElement(FulfillmentType::cases());
        $subtotal = fake()->numberBetween(15, 300) * 1000;
        $deliveryFee = $type->incursDeliveryFee()
            ? (int) config('bakcang.fulfillment.delivery_fee')
            : 0;

        return [
            // Sequence is unique per call rather than per day; OrderService
            // owns real BP-YYYYMMDD-NNNN generation in application code.
            'order_number' => sprintf(
                '%s-%s-%04d',
                config('bakcang.order.prefix'),
                now()->format('Ymd'),
                fake()->unique()->numberBetween(1, 9999),
            ),
            'customer_name' => fake()->name(),
            'customer_phone' => '08'.fake()->numerify('##########'),
            'customer_email' => fake()->safeEmail(),
            'fulfillment_type' => $type,
            'address' => $type->requiresAddress() ? fake()->address() : null,
            'fulfillment_date' => Carbon::tomorrow()->addDays(fake()->numberBetween(0, 7)),
            'fulfillment_time' => fake()->randomElement(['09:00:00', '11:00:00', '14:00:00', '16:00:00']),
            'status' => OrderStatus::AwaitingPayment,
            'subtotal' => $subtotal,
            'delivery_fee' => $deliveryFee,
            'total' => $subtotal + $deliveryFee,
            'notes' => fake()->boolean(30) ? fake()->sentence() : null,
        ];
    }

    public function status(OrderStatus $status): static
    {
        return $this->state(fn (): array => ['status' => $status]);
    }

    public function pickup(): static
    {
        return $this->state(fn (array $attributes): array => [
            'fulfillment_type' => FulfillmentType::Pickup,
            'address' => null,
            'delivery_fee' => 0,
            'total' => $attributes['subtotal'],
        ]);
    }

    public function delivery(): static
    {
        $fee = (int) config('bakcang.fulfillment.delivery_fee');

        return $this->state(fn (array $attributes): array => [
            'fulfillment_type' => FulfillmentType::Delivery,
            'address' => fake()->address(),
            'delivery_fee' => $fee,
            'total' => $attributes['subtotal'] + $fee,
        ]);
    }
}
