<?php

declare(strict_types=1);

namespace App\Services\Order;

use App\Enums\OrderStatus;
use App\Events\OrderStatusChanged;
use App\Models\Order;
use App\Repositories\Contracts\OrderRepositoryInterface;
use Illuminate\Validation\ValidationException;

class OrderStatusService
{
    public function __construct(
        private readonly OrderRepositoryInterface $orders,
    ) {}

    /**
     * Moves an order forward, refusing transitions the state machine does not
     * permit.
     *
     * Guarding here rather than only in the UI matters because the admin form
     * is not the only caller — and because `awaiting_payment` deliberately has
     * no manual path to `confirmed`: only a verified Midtrans notification may
     * mark an order paid.
     */
    public function transition(Order $order, OrderStatus $target): Order
    {
        $current = $order->status;

        if ($current === $target) {
            return $order;
        }

        if (! $current->canTransitionTo($target)) {
            throw ValidationException::withMessages([
                'status' => sprintf(
                    'Tidak dapat mengubah status dari "%s" ke "%s".',
                    $current->label(),
                    $target->label(),
                ),
            ]);
        }

        $updated = $this->orders->updateStatus($order, $target);

        OrderStatusChanged::dispatch($updated, $current, $target);

        return $updated;
    }

    /**
     * Confirms an order after payment. Called only by the webhook pipeline.
     *
     * Bypasses the forward-only transition table on purpose: payment is an
     * external event that legitimately moves `awaiting_payment` to
     * `confirmed`, which no human is allowed to do by hand.
     */
    public function markConfirmed(Order $order): Order
    {
        if ($order->status !== OrderStatus::AwaitingPayment) {
            return $order;
        }

        $updated = $this->orders->updateStatus($order, OrderStatus::Confirmed);

        OrderStatusChanged::dispatch($updated, OrderStatus::AwaitingPayment, OrderStatus::Confirmed);

        return $updated;
    }

    /**
     * Cancels an unpaid order whose payment window has closed.
     *
     * Paid orders are never auto-cancelled: an expiry notification arriving
     * after a settlement would otherwise cancel an order the customer has
     * already paid for.
     */
    public function markCancelledIfUnpaid(Order $order): Order
    {
        if ($order->status !== OrderStatus::AwaitingPayment || $order->isPaid()) {
            return $order;
        }

        $updated = $this->orders->updateStatus($order, OrderStatus::Cancelled);

        OrderStatusChanged::dispatch($updated, OrderStatus::AwaitingPayment, OrderStatus::Cancelled);

        return $updated;
    }
}
