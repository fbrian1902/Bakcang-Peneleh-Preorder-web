<?php

declare(strict_types=1);

namespace App\Repositories\Contracts;

use App\Enums\OrderStatus;
use App\Models\Order;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

interface OrderRepositoryInterface
{
    /**
     * @param  array{search?: string|null, status?: string|null, from?: string|null, to?: string|null}  $filters
     * @return LengthAwarePaginator<int, Order>
     */
    public function paginateForAdmin(array $filters, int $perPage): LengthAwarePaginator;

    public function findByNumber(string $orderNumber): ?Order;

    /**
     * Row-locked fetch used by the webhook so concurrent Midtrans retries for
     * the same order serialise instead of racing.
     */
    public function lockForUpdate(int $orderId): ?Order;

    public function create(array $attributes): Order;

    /**
     * Next sequence number for a given day, derived from existing order
     * numbers. Callers must handle a UNIQUE violation and retry: the read is
     * not atomic with the subsequent insert.
     */
    public function nextDailySequence(string $datePrefix): int;

    /**
     * @return array{today: int, awaiting_payment: int, confirmed: int, preparing: int, ready: int}
     */
    public function dashboardCounts(): array;

    /**
     * @return Collection<int, Order>
     */
    public function recent(int $limit): Collection;

    /**
     * @return Collection<int, object{day: string, orders: int}>
     */
    public function ordersPerDay(int $days): Collection;

    /**
     * @param  array{search?: string|null, status?: string|null, from?: string|null, to?: string|null}  $filters
     * @return Collection<int, Order>
     */
    public function forExport(array $filters): Collection;

    public function updateStatus(Order $order, OrderStatus $status): Order;
}
