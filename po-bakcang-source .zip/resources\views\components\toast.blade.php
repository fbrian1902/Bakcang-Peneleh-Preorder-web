{{-- Flash messages. Dismissible, and they stay put rather than fading out. --}}
@php
    $messages = collect([
        'success' => session('success'),
        'error' => session('error'),
    ])->filter();
@endphp

@if ($messages->isNotEmpty())
    <div role="status" aria-live="polite">
        @foreach ($messages as $type => $message)
            <div x-data="{ show: true }" x-show="show"
                 class="flex items-start gap-3 border-b px-4 py-2.5 text-sm
                        {{ $type === 'success'
                            ? 'border-accent-100 bg-accent-50 text-accent-800'
                            : 'border-red-200 bg-red-50 text-red-800' }}">
                <p class="mx-auto max-w-5xl flex-1">{{ $message }}</p>
                <button type="button" @click="show = false"
                        class="shrink-0 font-medium underline underline-offset-2"
                        aria-label="Tutup pemberitahuan">Tutup</button>
            </div>
        @endforeach
    </div>
@endif
