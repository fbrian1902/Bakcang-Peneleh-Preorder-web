<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * Mirrors the `orders.fulfillment_type` ENUM.
 */
enum FulfillmentType: string
{
    case Delivery = 'delivery';
    case Pickup = 'pickup';

    public function label(): string
    {
        return match ($this) {
            self::Delivery => 'Diantar',
            self::Pickup => 'Ambil Sendiri',
        };
    }

    /**
     * Only delivery orders carry a fee; pickup is always free.
     */
    public function incursDeliveryFee(): bool
    {
        return $this === self::Delivery;
    }

    public function requiresAddress(): bool
    {
        return $this === self::Delivery;
    }

    /**
     * @return array<string, string>
     */
    public static function options(): array
    {
        return array_reduce(
            self::cases(),
            static fn (array $carry, self $case): array => $carry + [$case->value => $case->label()],
            [],
        );
    }
}
