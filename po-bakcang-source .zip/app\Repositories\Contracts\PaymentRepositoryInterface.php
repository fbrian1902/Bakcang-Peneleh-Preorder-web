<?php

declare(strict_types=1);

namespace App\Repositories\Contracts;

use App\Models\Order;
use App\Models\Payment;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

interface PaymentRepositoryInterface
{
    /**
     * @param  array{search?: string|null, status?: string|null, from?: string|null, to?: string|null}  $filters
     * @return LengthAwarePaginator<int, Payment>
     */
    public function paginateForAdmin(array $filters, int $perPage): LengthAwarePaginator;

    public function findByMidtransOrderId(string $midtransOrderId): ?Payment;

    /**
     * Row-locked fetch keyed by the Midtrans order id. The webhook uses this
     * so duplicated notifications cannot interleave their read-compare-write.
     */
    public function lockByMidtransOrderId(string $midtransOrderId): ?Payment;

    public function create(array $attributes): Payment;

    /**
     * How many attempts an order has already made, used to build the next
     * unique midtrans_order_id suffix.
     */
    public function attemptCountFor(Order $order): int;

    /**
     * Total settled revenue in a date range, from settlement_time rather than
     * order creation, so unpaid orders never count as income.
     */
    public function revenueBetween(?string $from, ?string $to): float;

    /**
     * @return Collection<int, object{day: string, revenue: float, transactions: int}>
     */
    public function revenuePerDay(int $days): Collection;

    /**
     * @return Collection<int, object{transaction_status: string, total: int}>
     */
    public function statusBreakdown(): Collection;

    /**
     * @param  array{search?: string|null, status?: string|null, from?: string|null, to?: string|null}  $filters
     * @return Collection<int, Payment>
     */
    public function forExport(array $filters): Collection;
}
