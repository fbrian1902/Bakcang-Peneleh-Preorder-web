@php use App\Support\Money; @endphp
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Laporan Pesanan</title>
    <style>
        @page { margin: 24px 28px; }
        body { font-family: DejaVu Sans, sans-serif; font-size: 10px; color: #1C1917; }
        h1 { font-size: 17px; color: #1F4D2E; margin: 0; }
        .muted { color: #78716C; }
        .right { text-align: right; }
        .head { border-bottom: 2px solid #1F4D2E; padding-bottom: 10px; margin-bottom: 14px; }
        .summary { width: 100%; border-collapse: collapse; margin-bottom: 14px; }
        .summary td {
            width: 33.33%; background: #F1F6F2; border: 1px solid #DCEBE0;
            padding: 9px 11px;
        }
        .summary .label { font-size: 8px; text-transform: uppercase; letter-spacing: 0.7px; color: #2C6140; }
        .summary .value { font-size: 14px; font-weight: bold; color: #1F4D2E; margin-top: 2px; }
        table.data { width: 100%; border-collapse: collapse; }
        table.data th {
            background: #1F4D2E; color: #FDFCF9; text-align: left; padding: 6px;
            font-size: 8px; text-transform: uppercase; letter-spacing: 0.5px;
        }
        table.data td { padding: 6px; border-bottom: 1px solid #EFEBE1; }
        table.data tr:nth-child(even) td { background: #FBFAF7; }
        .foot { margin-top: 14px; font-size: 8px; color: #78716C; }
    </style>
</head>
<body>
    <div class="head">
        <h1>Laporan Pesanan</h1>
        <div class="muted" style="margin-top:3px">
            {{ config('bakcang.store.name') }} ·
            {{ \Illuminate\Support\Carbon::parse($filters['from'])->translatedFormat('d F Y') }}
            &ndash;
            {{ \Illuminate\Support\Carbon::parse($filters['to'])->translatedFormat('d F Y') }}
        </div>
    </div>

    <table class="summary">
        <tr>
            <td>
                <div class="label">Pendapatan (settled)</div>
                <div class="value">{{ Money::format($revenue) }}</div>
            </td>
            <td>
                <div class="label">Jumlah pesanan</div>
                <div class="value">{{ number_format($orders->count()) }}</div>
            </td>
            <td>
                <div class="label">Rata-rata per pesanan</div>
                <div class="value">
                    {{ Money::format($orders->count() > 0 ? $orders->sum('total') / $orders->count() : 0) }}
                </div>
            </td>
        </tr>
    </table>

    @if ($orders->isEmpty())
        <p class="muted">Tidak ada pesanan pada rentang tanggal ini.</p>
    @else
        <table class="data">
            <thead>
                <tr>
                    <th style="width:13%">Nomor</th>
                    <th style="width:9%">Tanggal</th>
                    <th style="width:17%">Pelanggan</th>
                    <th style="width:12%">Telepon</th>
                    <th style="width:9%">Metode</th>
                    <th style="width:10%">Jadwal</th>
                    <th style="width:5%" class="right">Item</th>
                    <th style="width:11%" class="right">Total</th>
                    <th style="width:8%">Status</th>
                    <th style="width:6%">Bayar</th>
                </tr>
            </thead>
            <tbody>
                @foreach ($orders as $order)
                    <tr>
                        <td>{{ $order->order_number }}</td>
                        <td>{{ $order->created_at?->format('d/m/y') }}</td>
                        <td>{{ $order->customer_name }}</td>
                        <td>{{ $order->customer_phone }}</td>
                        <td>{{ $order->fulfillment_type->label() }}</td>
                        <td>{{ $order->fulfillment_date?->format('d/m/y') }}</td>
                        <td class="right">{{ $order->items->sum('quantity') }}</td>
                        <td class="right">{{ Money::format($order->total) }}</td>
                        <td>{{ $order->status->label() }}</td>
                        <td>{{ $order->successfulPayment ? 'Lunas' : '—' }}</td>
                    </tr>
                @endforeach
            </tbody>
        </table>
    @endif

    <div class="foot">
        Dicetak {{ now()->translatedFormat('d F Y, H:i') }} WIB.
        Pendapatan dihitung dari waktu settlement Midtrans, bukan tanggal pesanan dibuat.
    </div>
</body>
</html>
