<?php

declare(strict_types=1);

namespace App\Services\Report;

use App\Models\Order;
use Barryvdh\DomPDF\Facade\Pdf;
use Barryvdh\DomPDF\PDF as PdfWrapper;
use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Encoding\Encoding;
use Endroid\QrCode\ErrorCorrectionLevel;
use Endroid\QrCode\Writer\PngWriter;

class InvoiceService
{
    public function generate(Order $order): PdfWrapper
    {
        $order->loadMissing(['items', 'successfulPayment', 'latestPayment']);

        return Pdf::loadView('pdf.invoice', [
            'order' => $order,
            'payment' => $order->successfulPayment ?? $order->latestPayment,
            'store' => config('bakcang.store'),
            'qrCode' => $this->trackingQrCode($order),
        ])->setPaper('a4');
    }

    public function filename(Order $order): string
    {
        return "invoice-{$order->order_number}.pdf";
    }

    /**
     * A scannable link to the public order page, inlined as a base64 PNG.
     *
     * PNG rather than SVG because DomPDF's SVG support is partial and renders
     * QR modules unreliably; a raster data URI always embeds correctly. Data
     * URI rather than a file path because DomPDF would otherwise need
     * filesystem access enabled to read it.
     */
    private function trackingQrCode(Order $order): string
    {
        $result = (new Builder(
            writer: new PngWriter,
            data: route('order.show', $order->order_number),
            encoding: new Encoding('UTF-8'),
            errorCorrectionLevel: ErrorCorrectionLevel::Medium,
            size: 220,
            margin: 8,
        ))->build();

        return $result->getDataUri();
    }
}
