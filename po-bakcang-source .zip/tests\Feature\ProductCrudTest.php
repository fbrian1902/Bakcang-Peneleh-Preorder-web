<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Http\UploadedFile;
use Illuminate\Support\Facades\Storage;
use Tests\TestCase;

class ProductCrudTest extends TestCase
{
    use RefreshDatabase;

    private function admin(): User
    {
        return User::factory()->admin()->create();
    }

    public function test_guests_are_redirected_from_the_admin_panel(): void
    {
        $this->get(route('admin.products.index'))->assertRedirect(route('login'));
    }

    /**
     * 404 rather than 403 so a signed-in non-admin does not learn the panel
     * exists at this path.
     */
    public function test_non_admins_receive_a_404(): void
    {
        $this->actingAs(User::factory()->create())
            ->get(route('admin.products.index'))
            ->assertNotFound();
    }

    public function test_an_admin_can_create_a_product(): void
    {
        $this->actingAs($this->admin())
            ->post(route('admin.products.store'), [
                'name' => 'Bakcang Ayam Jamur',
                'price' => 32000,
                'is_available' => '1',
            ])
            ->assertRedirect(route('admin.products.index'));

        $this->assertDatabaseHas('products', [
            'name' => 'Bakcang Ayam Jamur',
            'price' => 32000,
            'is_available' => 1,
        ]);
    }

    public function test_an_admin_can_upload_a_product_image(): void
    {
        Storage::fake('public');

        $this->actingAs($this->admin())->post(route('admin.products.store'), [
            'name' => 'Bakcang Udang',
            'price' => 42000,
            'image' => UploadedFile::fake()->image('bakcang.jpg', 800, 600),
        ]);

        $product = Product::query()->firstOrFail();

        $this->assertNotNull($product->image_path);
        Storage::disk('public')->assertExists($product->image_path);
    }

    public function test_a_non_image_upload_is_rejected(): void
    {
        Storage::fake('public');

        $this->actingAs($this->admin())
            ->post(route('admin.products.store'), [
                'name' => 'Berbahaya',
                'price' => 1000,
                'image' => UploadedFile::fake()->create('payload.php', 40, 'application/x-php'),
            ])
            ->assertSessionHasErrors('image');

        $this->assertDatabaseCount('products', 0);
    }

    public function test_an_undersized_image_is_rejected(): void
    {
        Storage::fake('public');

        $this->actingAs($this->admin())
            ->post(route('admin.products.store'), [
                'name' => 'Terlalu Kecil',
                'price' => 1000,
                'image' => UploadedFile::fake()->image('tiny.jpg', 50, 50),
            ])
            ->assertSessionHasErrors('image');
    }

    public function test_duplicate_names_are_rejected(): void
    {
        Product::factory()->create(['name' => 'Bakcang Original']);

        $this->actingAs($this->admin())
            ->post(route('admin.products.store'), [
                'name' => 'Bakcang Original',
                'price' => 30000,
            ])
            ->assertSessionHasErrors('name');
    }

    public function test_an_admin_can_update_a_product(): void
    {
        $product = Product::factory()->create(['name' => 'Lama', 'price' => 20000]);

        $this->actingAs($this->admin())
            ->put(route('admin.products.update', $product), [
                'name' => 'Baru',
                'price' => 25000,
                'is_available' => '0',
            ])
            ->assertRedirect(route('admin.products.index'));

        $this->assertDatabaseHas('products', [
            'id' => $product->id,
            'name' => 'Baru',
            'price' => 25000,
            'is_available' => 0,
        ]);
    }

    public function test_an_unused_product_can_be_deleted(): void
    {
        $product = Product::factory()->create();

        $this->actingAs($this->admin())
            ->delete(route('admin.products.destroy', $product))
            ->assertRedirect(route('admin.products.index'));

        $this->assertDatabaseCount('products', 0);
    }

    /**
     * order_items.product_id is ON DELETE RESTRICT and products carry no soft
     * delete, so an ordered product is permanently undeletable. The app must
     * report that rather than surfacing integrity error 1451.
     */
    public function test_an_ordered_product_cannot_be_deleted(): void
    {
        $product = Product::factory()->create();
        $order = Order::factory()->create();
        OrderItem::factory()->forProduct($product)->create(['order_id' => $order->id]);

        $this->actingAs($this->admin())
            ->delete(route('admin.products.destroy', $product))
            ->assertSessionHas('error');

        $this->assertDatabaseHas('products', ['id' => $product->id]);
    }

    public function test_the_catalogue_hides_unavailable_products(): void
    {
        $shown = Product::factory()->create(['name' => 'Tampil']);
        $hidden = Product::factory()->unavailable()->create(['name' => 'Tersembunyi']);

        $this->get(route('landing'))
            ->assertOk()
            ->assertSee($shown->name)
            ->assertDontSee($hidden->name);
    }
}
