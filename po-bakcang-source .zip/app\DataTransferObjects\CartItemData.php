<?php

declare(strict_types=1);

namespace App\DataTransferObjects;

use App\Models\Product;

/**
 * A single cart line, priced from the catalogue rather than from the request.
 */
final readonly class CartItemData
{
    public function __construct(
        public int $productId,
        public string $name,
        public float $unitPrice,
        public int $quantity,
        public ?string $imageUrl = null,
    ) {}

    public static function fromProduct(Product $product, int $quantity): self
    {
        return new self(
            productId: $product->id,
            name: $product->name,
            unitPrice: (float) $product->price,
            quantity: $quantity,
            imageUrl: $product->imageUrl(),
        );
    }

    /**
     * @param  array<string, mixed>  $data
     */
    public static function fromArray(array $data): self
    {
        return new self(
            productId: (int) $data['product_id'],
            name: (string) $data['name'],
            unitPrice: (float) $data['unit_price'],
            quantity: (int) $data['quantity'],
            imageUrl: $data['image_url'] ?? null,
        );
    }

    /**
     * @return array<string, mixed>
     */
    public function toArray(): array
    {
        return [
            'product_id' => $this->productId,
            'name' => $this->name,
            'unit_price' => $this->unitPrice,
            'quantity' => $this->quantity,
            'image_url' => $this->imageUrl,
        ];
    }

    public function lineTotal(): float
    {
        return $this->unitPrice * $this->quantity;
    }

    public function withQuantity(int $quantity): self
    {
        return new self(
            productId: $this->productId,
            name: $this->name,
            unitPrice: $this->unitPrice,
            quantity: $quantity,
            imageUrl: $this->imageUrl,
        );
    }
}
