<?php

declare(strict_types=1);

return [

    /*
    |--------------------------------------------------------------------------
    | Store Profile
    |--------------------------------------------------------------------------
    |
    | Rendered on the landing page, invoices and customer notifications.
    |
    */

    'store' => [
        'name' => env('BAKCANG_STORE_NAME', 'Bakcang Peneleh'),
        'phone' => env('BAKCANG_STORE_PHONE', ''),
        'email' => env('BAKCANG_STORE_EMAIL', ''),
        'address' => env('BAKCANG_STORE_ADDRESS', ''),
    ],

    /*
    |--------------------------------------------------------------------------
    | Order Numbering
    |--------------------------------------------------------------------------
    |
    | Produces BP-YYYYMMDD-0001. The sequence resets daily and the four-digit
    | pad caps a single day at 9,999 orders. Because `orders.order_number`
    | carries a UNIQUE index, a concurrency collision surfaces as an exception
    | rather than a duplicate; OrderService retries on that exception.
    |
    */

    'order' => [
        'prefix' => env('BAKCANG_ORDER_PREFIX', 'BP'),
        'sequence_padding' => 4,
        'max_number_attempts' => 5,
    ],

    /*
    |--------------------------------------------------------------------------
    | Fulfillment
    |--------------------------------------------------------------------------
    |
    | `delivery_fee` is a flat charge applied to delivery orders only; pickup
    | is always zero. It is snapshotted onto `orders.delivery_fee` at checkout,
    | so changing it here never rewrites the value on historical orders.
    |
    | Lead days bound how far ahead a customer may schedule: a minimum so the
    | kitchen has notice, a maximum to stop absurd dates.
    |
    */

    'fulfillment' => [
        'delivery_fee' => (int) env('BAKCANG_DELIVERY_FEE', 15000),
        'min_lead_days' => (int) env('BAKCANG_MIN_LEAD_DAYS', 1),
        'max_lead_days' => (int) env('BAKCANG_MAX_LEAD_DAYS', 30),
        'pickup_open' => env('BAKCANG_PICKUP_OPEN', '08:00'),
        'pickup_close' => env('BAKCANG_PICKUP_CLOSE', '17:00'),
    ],

    /*
    |--------------------------------------------------------------------------
    | Cart
    |--------------------------------------------------------------------------
    |
    | `order_items` carries UNIQUE (order_id, product_id), so the cart must
    | merge repeat additions of a product rather than appending a second line.
    | CartService enforces that; `max_quantity_per_item` bounds the merge.
    |
    */

    'cart' => [
        'session_key' => 'bakcang.cart',
        'max_quantity_per_item' => 99,
    ],

    /*
    |--------------------------------------------------------------------------
    | Product Images
    |--------------------------------------------------------------------------
    |
    | Uploads land on the `public` disk, which requires `storage:link`.
    | Validation is enforced by MIME type rather than file extension.
    |
    */

    'images' => [
        'disk' => 'public',
        'directory' => 'products',
        'max_kilobytes' => 2048,
        'mimes' => ['jpg', 'jpeg', 'png', 'webp'],
        'min_width' => 200,
        'min_height' => 200,
    ],

];
