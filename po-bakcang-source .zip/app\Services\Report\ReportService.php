<?php

declare(strict_types=1);

namespace App\Services\Report;

use App\Enums\TransactionStatus;
use App\Repositories\Contracts\OrderRepositoryInterface;
use App\Repositories\Contracts\PaymentRepositoryInterface;
use App\Repositories\Contracts\ProductRepositoryInterface;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;

class ReportService
{
    public function __construct(
        private readonly OrderRepositoryInterface $orders,
        private readonly PaymentRepositoryInterface $payments,
        private readonly ProductRepositoryInterface $products,
    ) {}

    /**
     * Everything the dashboard needs, in one call.
     *
     * @return array<string, mixed>
     */
    public function dashboard(int $days = 14): array
    {
        return [
            'counts' => $this->orders->dashboardCounts(),
            'revenue' => [
                'today' => $this->payments->revenueBetween(today()->toDateString(), today()->toDateString()),
                'month' => $this->payments->revenueBetween(today()->startOfMonth()->toDateString(), today()->toDateString()),
                'all_time' => $this->payments->revenueBetween(null, null),
            ],
            'charts' => [
                'revenue' => $this->revenueSeries($days),
                'orders' => $this->orderSeries($days),
                'payment_status' => $this->paymentStatusSeries(),
            ],
            'popular' => $this->products->popular(5),
            'recent' => $this->orders->recent(8),
        ];
    }

    /**
     * Zero-fills days with no activity.
     *
     * Without this a chart would connect the last day that had a sale to the
     * next one, drawing a straight line across the gap and implying steady
     * trade through days when nothing was sold.
     *
     * @return Collection<int, array{label: string, value: float}>
     */
    public function revenueSeries(int $days): Collection
    {
        $rows = $this->payments->revenuePerDay($days)->keyBy('day');

        return $this->dateRange($days)->map(static fn (Carbon $date): array => [
            'label' => $date->format('d M'),
            'value' => (float) ($rows->get($date->toDateString())->revenue ?? 0),
        ]);
    }

    /**
     * @return Collection<int, array{label: string, value: float}>
     */
    public function orderSeries(int $days): Collection
    {
        $rows = $this->orders->ordersPerDay($days)->keyBy('day');

        return $this->dateRange($days)->map(static fn (Carbon $date): array => [
            'label' => $date->format('d M'),
            'value' => (float) ($rows->get($date->toDateString())->orders ?? 0),
        ]);
    }

    /**
     * @return Collection<int, array{label: string, value: int, status: string}>
     */
    public function paymentStatusSeries(): Collection
    {
        return $this->payments->statusBreakdown()->map(static fn (object $row): array => [
            'status' => $row->transaction_status,
            'label' => TransactionStatus::from($row->transaction_status)->label(),
            'value' => (int) $row->total,
        ]);
    }

    /**
     * @return Collection<int, Carbon>
     */
    private function dateRange(int $days): Collection
    {
        return collect(range($days - 1, 0))
            ->map(static fn (int $offset): Carbon => today()->subDays($offset));
    }
}
