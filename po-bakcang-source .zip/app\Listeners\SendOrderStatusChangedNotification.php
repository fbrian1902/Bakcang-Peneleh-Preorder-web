<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Enums\OrderStatus;
use App\Events\OrderStatusChanged;
use App\Notifications\OrderStatusChangedNotification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Notification;

class SendOrderStatusChangedNotification implements ShouldQueue
{
    /**
     * Only milestones the customer cares about are announced. `confirmed` is
     * omitted because PaymentSettled already sends a receipt covering it, and
     * two emails for one event reads as a bug.
     */
    private const NOTIFIABLE = [
        OrderStatus::Preparing,
        OrderStatus::Ready,
        OrderStatus::Completed,
        OrderStatus::Cancelled,
    ];

    public function handle(OrderStatusChanged $event): void
    {
        if (blank($event->order->customer_email)) {
            return;
        }

        if (! in_array($event->to, self::NOTIFIABLE, strict: true)) {
            return;
        }

        Notification::route('mail', $event->order->customer_email)
            ->notify(new OrderStatusChangedNotification($event->order, $event->to));
    }
}
