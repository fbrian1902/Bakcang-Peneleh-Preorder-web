<?php

declare(strict_types=1);

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use App\Models\Order;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

/**
 * Landing point for Midtrans' Finish / Unfinish / Error redirects.
 *
 * Each Snap transaction already carries a per-order `callbacks.finish`, so this
 * only catches the dashboard-configured fallback — redirect-mode payments, and
 * channels that navigate the browser away rather than returning to the popup.
 *
 * Nothing here decides whether an order was paid. Midtrans appends
 * `order_id`, `status_code` and `transaction_status` to the redirect, but the
 * customer's browser is on the other side of that URL and can be made to
 * request anything at all. Payment state is only ever written by a
 * signature-verified webhook, or by a status pulled directly from the Midtrans
 * API. The query string is used for exactly one thing: working out which order
 * page to show.
 */
class PaymentReturnController extends Controller
{
    public function __invoke(Request $request): RedirectResponse
    {
        $order = $this->resolveOrder($request->query('order_id'));

        if ($order === null) {
            return redirect()
                ->route('landing')
                ->with('error', 'Pesanan tidak ditemukan. Silakan cek kembali tautan pesanan Anda.');
        }

        return redirect()->route('order.show', $order->order_number);
    }

    /**
     * Midtrans returns the per-attempt id (BP-20260722-0001-2); the trailing
     * attempt number is stripped to recover the order number.
     */
    private function resolveOrder(mixed $midtransOrderId): ?Order
    {
        if (! is_string($midtransOrderId) || blank($midtransOrderId)) {
            return null;
        }

        $orderNumber = preg_replace('/-\d+$/', '', $midtransOrderId);

        return Order::query()->where('order_number', $orderNumber)->first();
    }
}
