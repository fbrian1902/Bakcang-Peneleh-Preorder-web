@php
    $nav = [
        ['admin.dashboard', 'Dasbor'],
        ['admin.orders.index', 'Pesanan'],
        ['admin.products.index', 'Produk'],
        ['admin.payments.index', 'Pembayaran'],
        ['admin.reports.index', 'Laporan'],
    ];
@endphp

<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">
    <title>{{ $title ?? 'Admin' }} — {{ config('bakcang.store.name') }}</title>

    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @stack('head')
</head>
<body class="min-h-screen">
    <x-toast />

    <header class="border-b border-zinc-200">
        <div class="mx-auto flex max-w-6xl flex-wrap items-center gap-x-4 gap-y-2 px-4 py-3">
            <span class="text-sm font-semibold">{{ config('bakcang.store.name') }}</span>

            <nav class="flex flex-wrap gap-x-4 gap-y-1 text-sm">
                @foreach ($nav as [$route, $label])
                    @php $active = request()->routeIs(str_replace('.index', '', $route).'*'); @endphp
                    <a href="{{ route($route) }}"
                       @if ($active) aria-current="page" @endif
                       class="{{ $active
                           ? 'font-medium text-accent-700 underline underline-offset-4'
                           : 'text-zinc-600 hover:text-zinc-900' }}">
                        {{ $label }}
                    </a>
                @endforeach
            </nav>

            <div class="ml-auto flex items-center gap-3 text-sm">
                <a href="{{ route('profile.edit') }}" class="text-zinc-600 hover:text-zinc-900">
                    {{ auth()->user()->name }}
                </a>
                <form method="POST" action="{{ route('logout') }}">
                    @csrf
                    <button type="submit" class="text-zinc-600 hover:text-zinc-900">Keluar</button>
                </form>
            </div>
        </div>
    </header>

    <main class="mx-auto max-w-6xl px-4 py-8">
        <div class="mb-6 flex flex-wrap items-center justify-between gap-3">
            <h1 class="text-xl font-semibold">{{ $title ?? 'Admin' }}</h1>
            <div>{{ $actions ?? '' }}</div>
        </div>

        {{ $slot }}
    </main>

    @stack('scripts')
</body>
</html>
