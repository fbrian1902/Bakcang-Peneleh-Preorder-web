<?php

declare(strict_types=1);

namespace App\Repositories\Contracts;

use App\Models\Product;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;

interface ProductRepositoryInterface
{
    /**
     * @return LengthAwarePaginator<int, Product>
     */
    public function paginateForAdmin(?string $search, int $perPage): LengthAwarePaginator;

    /**
     * @return Collection<int, Product>
     */
    public function availableForCatalog(): Collection;

    /**
     * Fetches available products by id, keyed by id.
     *
     * @param  array<int, int>  $ids
     * @return Collection<int, Product>
     */
    public function findAvailableByIds(array $ids): Collection;

    public function create(array $attributes): Product;

    public function update(Product $product, array $attributes): Product;

    /**
     * @return bool True when deleted; false when the product is referenced by
     *              an order and the ON DELETE RESTRICT constraint forbids it.
     */
    public function delete(Product $product): bool;

    /**
     * @return Collection<int, object{product_id: int, product_name: string, total_quantity: int, total_revenue: float}>
     */
    public function popular(int $limit): Collection;
}
