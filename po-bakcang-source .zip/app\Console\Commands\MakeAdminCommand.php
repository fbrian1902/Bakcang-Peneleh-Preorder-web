<?php

declare(strict_types=1);

namespace App\Console\Commands;

use App\Models\User;
use Illuminate\Console\Command;
use Illuminate\Support\Facades\Hash;
use Illuminate\Support\Facades\Validator;
use Illuminate\Validation\Rules\Password;

use function Laravel\Prompts\password as promptPassword;
use function Laravel\Prompts\text;

/**
 * Creates or promotes an administrator.
 *
 * Public registration is disabled, so this is the supported way to add staff.
 */
class MakeAdminCommand extends Command
{
    protected $signature = 'bakcang:make-admin
                            {email? : Email address of the administrator}
                            {--name= : Display name, used when creating a new account}';

    protected $description = 'Create a new administrator, or grant admin access to an existing user';

    public function handle(): int
    {
        $email = $this->argument('email') ?? text(
            label: 'Email administrator',
            required: true,
        );

        $user = User::query()->where('email', $email)->first();

        if ($user !== null) {
            $user->is_admin = true;
            $user->save();

            $this->info("Akses admin diberikan kepada {$user->email}.");

            return self::SUCCESS;
        }

        $name = $this->option('name') ?? text(label: 'Nama lengkap', required: true);
        $plain = promptPassword(label: 'Kata sandi', required: true);

        $validator = Validator::make(
            ['email' => $email, 'name' => $name, 'password' => $plain],
            [
                'email' => ['required', 'email', 'unique:users,email'],
                'name' => ['required', 'string', 'max:255'],
                'password' => ['required', Password::defaults()],
            ],
        );

        if ($validator->fails()) {
            foreach ($validator->errors()->all() as $error) {
                $this->error($error);
            }

            return self::FAILURE;
        }

        $user = new User;
        $user->name = $name;
        $user->email = $email;
        $user->password = Hash::make($plain);
        $user->email_verified_at = now();
        // Assigned directly: is_admin is excluded from the fillable list so a
        // mass-assigned registration payload cannot grant it.
        $user->is_admin = true;
        $user->save();

        $this->info("Administrator {$user->email} berhasil dibuat.");

        return self::SUCCESS;
    }
}
