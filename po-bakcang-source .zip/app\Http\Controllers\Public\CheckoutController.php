<?php

declare(strict_types=1);

namespace App\Http\Controllers\Public;

use App\DataTransferObjects\CheckoutData;
use App\Exceptions\CheckoutException;
use App\Http\Controllers\Controller;
use App\Http\Requests\StoreOrderRequest;
use App\Services\Cart\CartService;
use App\Services\Order\OrderService;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;

class CheckoutController extends Controller
{
    public function __construct(
        private readonly CartService $cart,
        private readonly OrderService $orders,
    ) {}

    public function show(): View|RedirectResponse
    {
        // Re-priced against the live catalogue: a cart can sit in a session
        // for days while an admin edits products underneath it.
        $items = $this->cart->reconcile();

        if ($items->isEmpty()) {
            return redirect()
                ->route('landing')
                ->with('error', 'Keranjang belanja masih kosong.');
        }

        return view('public.checkout', [
            'items' => $items,
            'subtotal' => $this->cart->subtotal(),
            'deliveryFee' => (float) config('bakcang.fulfillment.delivery_fee'),
        ]);
    }

    public function store(StoreOrderRequest $request): RedirectResponse
    {
        try {
            $order = $this->orders->createFromCart(
                CheckoutData::fromArray($request->validated()),
            );
        } catch (CheckoutException $exception) {
            return back()
                ->withInput()
                ->with('error', $exception->getMessage());
        }

        return redirect()
            ->route('order.show', $order->order_number)
            ->with('success', 'Pesanan berhasil dibuat. Silakan selesaikan pembayaran.');
    }
}
