<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('products', function (Blueprint $table): void {
            $table->id();
            $table->string('name', 100);
            $table->decimal('price', 10, 2)->default(0);
            $table->string('image_path', 255)->nullable();
            $table->boolean('is_available')->default(true);
            $table->timestamps();

            $table->index('is_available', 'ix_products_available');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('products');
    }
};
