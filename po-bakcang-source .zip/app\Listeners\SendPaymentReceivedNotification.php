<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\PaymentSettled;
use App\Notifications\PaymentReceivedNotification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Notification;

class SendPaymentReceivedNotification implements ShouldQueue
{
    public function handle(PaymentSettled $event): void
    {
        if (blank($event->order->customer_email)) {
            return;
        }

        Notification::route('mail', $event->order->customer_email)
            ->notify(new PaymentReceivedNotification($event->order, $event->payment));
    }
}
