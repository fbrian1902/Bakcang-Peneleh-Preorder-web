<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Enums\FraudStatus;
use App\Enums\OrderStatus;
use App\Enums\TransactionStatus;
use App\Events\PaymentSettled;
use App\Models\Order;
use App\Models\Payment;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Event;
use Tests\TestCase;

class MidtransWebhookTest extends TestCase
{
    use RefreshDatabase;

    private const SERVER_KEY = 'SB-Mid-server-testkey';

    protected function setUp(): void
    {
        parent::setUp();

        config([
            'midtrans.server_key' => self::SERVER_KEY,
            'midtrans.client_key' => 'SB-Mid-client-testkey',
            // Disabled so tests exercise the payload path without reaching the
            // network; the re-query path is covered by its own assertion below.
            'midtrans.webhook.verify_status_with_api' => false,
        ]);
    }

    private function makeOrder(int $total = 70000): Order
    {
        return Order::factory()->pickup()->create([
            'status' => OrderStatus::AwaitingPayment,
            'subtotal' => $total,
            'delivery_fee' => 0,
            'total' => $total,
        ]);
    }

    private function makePayment(Order $order): Payment
    {
        return Payment::factory()->create([
            'order_id' => $order->id,
            'midtrans_order_id' => $order->order_number.'-1',
            'gross_amount' => $order->total,
            'transaction_status' => TransactionStatus::Pending,
        ]);
    }

    /**
     * @return array<string, mixed>
     */
    private function notification(Payment $payment, array $overrides = []): array
    {
        $payload = array_merge([
            'order_id' => $payment->midtrans_order_id,
            'status_code' => '200',
            'gross_amount' => number_format((float) $payment->gross_amount, 2, '.', ''),
            'transaction_status' => 'settlement',
            'fraud_status' => 'accept',
            'transaction_id' => 'txn-'.fake()->uuid(),
            'payment_type' => 'qris',
            'transaction_time' => '2026-07-22 10:15:00',
            'settlement_time' => '2026-07-22 10:16:30',
        ], $overrides);

        $payload['signature_key'] = hash(
            'sha512',
            $payload['order_id'].$payload['status_code'].$payload['gross_amount'].self::SERVER_KEY,
        );

        return $payload;
    }

    public function test_a_settlement_confirms_the_order(): void
    {
        Event::fake([PaymentSettled::class]);

        $order = $this->makeOrder();
        $payment = $this->makePayment($order);

        $this->postJson(route('webhook.midtrans'), $this->notification($payment))
            ->assertOk();

        $this->assertSame(TransactionStatus::Settlement, $payment->refresh()->transaction_status);
        $this->assertSame(OrderStatus::Confirmed, $order->refresh()->status);

        Event::assertDispatched(PaymentSettled::class);
    }

    public function test_a_forged_signature_is_rejected(): void
    {
        $order = $this->makeOrder();
        $payment = $this->makePayment($order);

        $payload = $this->notification($payment);
        $payload['signature_key'] = str_repeat('0', 128);

        $this->postJson(route('webhook.midtrans'), $payload)->assertForbidden();

        $this->assertSame(TransactionStatus::Pending, $payment->refresh()->transaction_status);
        $this->assertSame(OrderStatus::AwaitingPayment, $order->refresh()->status);
    }

    public function test_a_missing_signature_is_rejected(): void
    {
        $payment = $this->makePayment($this->makeOrder());

        $payload = $this->notification($payment);
        unset($payload['signature_key']);

        $this->postJson(route('webhook.midtrans'), $payload)->assertForbidden();
    }

    /**
     * Midtrans retries until it gets a 2xx, so the same settlement can arrive
     * several times. The receipt must only be sent once.
     */
    public function test_a_duplicate_settlement_does_not_refire_the_event(): void
    {
        Event::fake([PaymentSettled::class]);

        $payment = $this->makePayment($this->makeOrder());
        $payload = $this->notification($payment);

        $this->postJson(route('webhook.midtrans'), $payload)->assertOk();
        $this->postJson(route('webhook.midtrans'), $payload)->assertOk();
        $this->postJson(route('webhook.midtrans'), $payload)->assertOk();

        Event::assertDispatchedTimes(PaymentSettled::class, 1);
    }

    /**
     * Midtrans guarantees no ordering, so a `pending` can arrive after the
     * `settlement` it precedes. Applying it would un-pay a paid order.
     */
    public function test_a_late_pending_cannot_reverse_a_settlement(): void
    {
        $order = $this->makeOrder();
        $payment = $this->makePayment($order);

        $this->postJson(route('webhook.midtrans'), $this->notification($payment))->assertOk();

        $this->postJson(route('webhook.midtrans'), $this->notification($payment, [
            'transaction_status' => 'pending',
            'status_code' => '201',
        ]))->assertOk();

        $this->assertSame(TransactionStatus::Settlement, $payment->refresh()->transaction_status);
        $this->assertSame(OrderStatus::Confirmed, $order->refresh()->status);
    }

    /**
     * These two values are absent from the original schema's ENUM. Under MySQL
     * strict mode an unknown value raises error 1265 rather than truncating,
     * which would 500 the webhook into an endless retry loop.
     */
    public function test_authorize_and_partial_refund_are_accepted(): void
    {
        foreach (['authorize', 'partial_refund'] as $status) {
            $payment = $this->makePayment($this->makeOrder());

            $this->postJson(route('webhook.midtrans'), $this->notification($payment, [
                'transaction_status' => $status,
                'payment_type' => 'credit_card',
            ]))->assertOk();

            $this->assertSame($status, $payment->refresh()->transaction_status->value);
        }
    }

    /**
     * A captured card held for manual fraud review is not yet revenue.
     */
    public function test_a_challenged_capture_does_not_confirm_the_order(): void
    {
        $order = $this->makeOrder();
        $payment = $this->makePayment($order);

        $this->postJson(route('webhook.midtrans'), $this->notification($payment, [
            'transaction_status' => 'capture',
            'fraud_status' => 'challenge',
            'payment_type' => 'credit_card',
        ]))->assertOk();

        $this->assertSame(FraudStatus::Challenge, $payment->refresh()->fraud_status);
        $this->assertSame(OrderStatus::AwaitingPayment, $order->refresh()->status);
    }

    public function test_an_expiry_cancels_an_unpaid_order(): void
    {
        $order = $this->makeOrder();
        $payment = $this->makePayment($order);

        $this->postJson(route('webhook.midtrans'), $this->notification($payment, [
            'transaction_status' => 'expire',
            'status_code' => '407',
            'fraud_status' => null,
        ]))->assertOk();

        $this->assertSame(OrderStatus::Cancelled, $order->refresh()->status);
    }

    public function test_a_mismatched_amount_is_rejected(): void
    {
        $order = $this->makeOrder(70000);
        $payment = $this->makePayment($order);

        $payload = $this->notification($payment, ['gross_amount' => '1000.00']);

        $this->postJson(route('webhook.midtrans'), $payload)->assertNotFound();

        $this->assertSame(OrderStatus::AwaitingPayment, $order->refresh()->status);
    }

    public function test_an_unknown_order_returns_404_rather_than_500(): void
    {
        // A 500 would make Midtrans retry a notification that can never succeed.
        $payload = [
            'order_id' => 'BP-20260101-9999-1',
            'status_code' => '200',
            'gross_amount' => '10000.00',
            'transaction_status' => 'settlement',
        ];
        $payload['signature_key'] = hash(
            'sha512',
            $payload['order_id'].$payload['status_code'].$payload['gross_amount'].self::SERVER_KEY,
        );

        $this->postJson(route('webhook.midtrans'), $payload)->assertNotFound();
    }

    /**
     * Midtrans sends bare WIB timestamps with no offset. Parsing them as UTC
     * would shift every payment time by seven hours.
     */
    public function test_timestamps_are_parsed_as_jakarta_time(): void
    {
        config(['app.timezone' => 'Asia/Jakarta']);

        $payment = $this->makePayment($this->makeOrder());

        $this->postJson(route('webhook.midtrans'), $this->notification($payment, [
            'settlement_time' => '2026-07-22 10:16:30',
        ]))->assertOk();

        $this->assertSame(
            '2026-07-22 10:16:30',
            $payment->refresh()->settlement_time->format('Y-m-d H:i:s'),
        );
    }

    public function test_the_webhook_is_exempt_from_csrf(): void
    {
        // Midtrans posts server-to-server with no session cookie; a CSRF-
        // protected endpoint would reject every notification with a 419.
        $payment = $this->makePayment($this->makeOrder());

        $this->post(route('webhook.midtrans'), $this->notification($payment))
            ->assertOk();
    }
}
