<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Product;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<OrderItem>
 */
class OrderItemFactory extends Factory
{
    protected $model = OrderItem::class;

    /**
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        $quantity = fake()->numberBetween(1, 5);
        $unitPrice = fake()->numberBetween(15, 60) * 1000;

        return [
            'order_id' => Order::factory(),
            'product_id' => Product::factory(),
            'product_name' => 'Bakcang '.fake()->word(),
            'unit_price' => $unitPrice,
            'quantity' => $quantity,
            'line_total' => $unitPrice * $quantity,
        ];
    }

    /**
     * Snapshots name and price from a real product, the way checkout does.
     */
    public function forProduct(Product $product, int $quantity = 1): static
    {
        return $this->state(fn (): array => [
            'product_id' => $product->id,
            'product_name' => $product->name,
            'unit_price' => $product->price,
            'quantity' => $quantity,
            'line_total' => (float) $product->price * $quantity,
        ]);
    }
}
