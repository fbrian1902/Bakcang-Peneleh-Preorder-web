<?php

declare(strict_types=1);

namespace App\Repositories\Eloquent;

use App\Models\Product;
use App\Repositories\Contracts\ProductRepositoryInterface;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Storage;

class ProductRepository implements ProductRepositoryInterface
{
    public function paginateForAdmin(?string $search, int $perPage): LengthAwarePaginator
    {
        return Product::query()
            ->search($search)
            ->latest('id')
            ->paginate($perPage)
            ->withQueryString();
    }

    public function availableForCatalog(): Collection
    {
        return Product::query()
            ->available()
            ->orderBy('name')
            ->get();
    }

    public function findAvailableByIds(array $ids): Collection
    {
        if ($ids === []) {
            return collect();
        }

        return Product::query()
            ->available()
            ->whereIn('id', $ids)
            ->get()
            ->keyBy('id');
    }

    public function create(array $attributes): Product
    {
        return Product::create($attributes);
    }

    public function update(Product $product, array $attributes): Product
    {
        $product->update($attributes);

        return $product->refresh();
    }

    /**
     * Checked rather than attempted: order_items.product_id is ON DELETE
     * RESTRICT, so deleting a referenced product would raise a raw integrity
     * error the UI cannot explain. The image is removed only after the row
     * is gone, so a failed delete never orphans the file.
     */
    public function delete(Product $product): bool
    {
        if (! $product->isDeletable()) {
            return false;
        }

        $imagePath = $product->image_path;

        $product->delete();

        if (filled($imagePath)) {
            Storage::disk(config('bakcang.images.disk'))->delete($imagePath);
        }

        return true;
    }

    public function popular(int $limit): Collection
    {
        return DB::table('order_items')
            ->join('orders', 'orders.id', '=', 'order_items.order_id')
            // Cancelled orders were never fulfilled, so counting them would
            // overstate demand.
            ->where('orders.status', '!=', 'cancelled')
            ->select([
                'order_items.product_id',
                DB::raw('MAX(order_items.product_name) as product_name'),
                DB::raw('SUM(order_items.quantity) as total_quantity'),
                DB::raw('SUM(order_items.line_total) as total_revenue'),
            ])
            ->groupBy('order_items.product_id')
            ->orderByDesc('total_quantity')
            ->limit($limit)
            ->get();
    }
}
