<!DOCTYPE html>
<html lang="{{ str_replace('_', '-', app()->getLocale()) }}">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="{{ csrf_token() }}">

    <title>@yield('title', config('bakcang.store.name'))</title>
    <meta name="description" content="@yield('description', 'Pre-order bakcang dari Peneleh, Surabaya.')">

    @vite(['resources/css/app.css', 'resources/js/app.js'])
    @stack('head')
</head>
<body class="min-h-screen">
    <x-toast />

    <header class="border-b border-zinc-200">
        <div class="mx-auto flex max-w-5xl items-center justify-between gap-4 px-4 py-3">
            <a href="{{ route('landing') }}" class="text-base font-semibold">
                {{ config('bakcang.store.name') }}
            </a>

            @php($cartCount = app(\App\Services\Cart\CartService::class)->count())
            <a href="{{ route('checkout.show') }}" class="btn-secondary">
                Keranjang{{ $cartCount > 0 ? " ({$cartCount})" : '' }}
            </a>
        </div>
    </header>

    <main class="mx-auto max-w-5xl px-4 py-10">
        {{ $slot }}
    </main>

    <footer class="mt-16 border-t border-zinc-200">
        <div class="mx-auto max-w-5xl px-4 py-6 text-sm text-zinc-500">
            <p>{{ config('bakcang.store.name') }} — {{ config('bakcang.store.address') }}</p>
            <p class="mt-1">
                {{ config('bakcang.store.phone') }} ·
                Buka {{ config('bakcang.fulfillment.pickup_open') }}–{{ config('bakcang.fulfillment.pickup_close') }} WIB
            </p>
        </div>
    </footer>

    @stack('scripts')
</body>
</html>
