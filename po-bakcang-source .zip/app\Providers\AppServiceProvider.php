<?php

declare(strict_types=1);

namespace App\Providers;

use App\Models\User;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Support\Facades\Gate;
use Illuminate\Support\Facades\URL;
use Illuminate\Support\ServiceProvider;

class AppServiceProvider extends ServiceProvider
{
    public function register(): void
    {
        //
    }

    public function boot(): void
    {
        // Turns a typo'd attribute or a missing eager-load into a loud failure
        // during development instead of a silently wrong page in production.
        Model::shouldBeStrict(! app()->isProduction());

        // Midtrans will not call an http:// notification URL, and mixed-content
        // rules would block Snap.js behind an ngrok tunnel.
        if (app()->isProduction() || str_starts_with((string) config('app.url'), 'https://')) {
            URL::forceScheme('https');
        }

        $this->registerGates();
    }

    /**
     * A single privileged role, expressed as one gate rather than a permission
     * package and its five extra tables.
     */
    private function registerGates(): void
    {
        Gate::define('access-admin', static fn (User $user): bool => $user->isAdmin());

        // Grants every ability to admins, so policies only need to encode
        // rules that differ from "an admin may do this".
        Gate::before(static fn (User $user): ?bool => $user->isAdmin() ? true : null);
    }
}
