<?php

declare(strict_types=1);

namespace App\Exports;

use App\Repositories\Contracts\ProductRepositoryInterface;
use Illuminate\Support\Collection;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

/**
 * Product performance, ranked by units sold.
 */
class ProductsExport implements FromCollection, ShouldAutoSize, WithHeadings, WithMapping, WithStyles
{
    public function __construct(
        private readonly ProductRepositoryInterface $products,
    ) {}

    public function collection(): Collection
    {
        return $this->products->popular(limit: 1000);
    }

    /**
     * @return array<int, string>
     */
    public function headings(): array
    {
        return ['Produk', 'Terjual (pcs)', 'Pendapatan'];
    }

    /**
     * @param  object{product_name: string, total_quantity: int, total_revenue: float}  $row
     * @return array<int, mixed>
     */
    public function map($row): array
    {
        return [
            $row->product_name,
            (int) $row->total_quantity,
            (float) $row->total_revenue,
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function styles(Worksheet $sheet): array
    {
        return [
            1 => ['font' => ['bold' => true]],
        ];
    }
}
