<?php

declare(strict_types=1);

namespace App\Exports;

use App\Models\Payment;
use App\Repositories\Contracts\PaymentRepositoryInterface;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class PaymentsExport implements FromCollection, ShouldAutoSize, WithHeadings, WithMapping, WithStyles
{
    /**
     * @param  array{search?: string|null, status?: string|null, from?: string|null, to?: string|null}  $filters
     */
    public function __construct(
        private readonly PaymentRepositoryInterface $payments,
        private readonly array $filters = [],
    ) {}

    public function collection()
    {
        return $this->payments->forExport($this->filters);
    }

    /**
     * @return array<int, string>
     */
    public function headings(): array
    {
        return [
            'Midtrans Order ID',
            'Nomor Pesanan',
            'Transaction ID',
            'Metode',
            'Nominal',
            'Status',
            'Fraud',
            'Waktu Transaksi',
            'Waktu Settlement',
        ];
    }

    /**
     * @param  Payment  $payment
     * @return array<int, mixed>
     */
    public function map($payment): array
    {
        return [
            $payment->midtrans_order_id,
            $payment->order?->order_number,
            $payment->transaction_id,
            $payment->channelLabel(),
            (float) $payment->gross_amount,
            $payment->transaction_status->label(),
            $payment->fraud_status?->label(),
            $payment->transaction_time?->format('Y-m-d H:i'),
            $payment->settlement_time?->format('Y-m-d H:i'),
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function styles(Worksheet $sheet): array
    {
        return [
            1 => ['font' => ['bold' => true]],
        ];
    }
}
