<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\Product;
use App\Services\Cart\CartService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class CartServiceTest extends TestCase
{
    use RefreshDatabase;

    private CartService $cart;

    protected function setUp(): void
    {
        parent::setUp();

        $this->cart = $this->app->make(CartService::class);
    }

    /**
     * order_items carries UNIQUE (order_id, product_id). If the cart appended
     * instead of merging, checkout would abort on an integrity violation.
     */
    public function test_adding_the_same_product_twice_merges_into_one_line(): void
    {
        $product = Product::factory()->create(['price' => 30000]);

        $this->cart->add($product->id, 2);
        $this->cart->add($product->id, 3);

        $this->assertCount(1, $this->cart->items());
        $this->assertSame(5, $this->cart->count());
        $this->assertSame(150000.0, $this->cart->subtotal());
    }

    public function test_unavailable_products_cannot_be_added(): void
    {
        $product = Product::factory()->unavailable()->create();

        $this->cart->add($product->id);

        $this->assertTrue($this->cart->isEmpty());
    }

    /**
     * A cart can sit in a session for days while an admin edits the catalogue,
     * so prices must be re-read rather than trusted from the session.
     */
    public function test_reconcile_reprices_against_the_current_catalogue(): void
    {
        $product = Product::factory()->create(['price' => 20000]);
        $this->cart->add($product->id, 2);

        $product->update(['price' => 25000]);

        $this->assertSame(50000.0, $this->cart->reconcile()->sum(fn ($i) => $i->lineTotal()));
    }

    public function test_reconcile_drops_products_that_became_unavailable(): void
    {
        $available = Product::factory()->create();
        $delisted = Product::factory()->create();

        $this->cart->add($available->id);
        $this->cart->add($delisted->id);

        $delisted->update(['is_available' => false]);

        $items = $this->cart->reconcile();

        $this->assertCount(1, $items);
        $this->assertSame($available->id, $items->first()->productId);
    }

    public function test_quantity_is_clamped_to_the_configured_maximum(): void
    {
        config(['bakcang.cart.max_quantity_per_item' => 10]);

        $product = Product::factory()->create();
        $this->cart->add($product->id, 999);

        $this->assertSame(10, $this->cart->count());
    }

    public function test_updating_quantity_to_zero_removes_the_line(): void
    {
        $product = Product::factory()->create();
        $this->cart->add($product->id, 3);

        $this->cart->updateQuantity($product->id, 0);

        $this->assertTrue($this->cart->isEmpty());
    }
}
