<?php

declare(strict_types=1);

namespace App\Exceptions;

use RuntimeException;

class CheckoutException extends RuntimeException
{
    public static function emptyCart(): self
    {
        return new self('Keranjang belanja masih kosong.');
    }

    public static function productUnavailable(string $name): self
    {
        return new self("Produk \"{$name}\" sedang tidak tersedia.");
    }

    public static function orderNumberExhausted(int $attempts): self
    {
        return new self(
            "Gagal membuat nomor pesanan setelah {$attempts} percobaan. Silakan coba lagi.",
        );
    }

    public static function notPayable(string $orderNumber): self
    {
        return new self("Pesanan {$orderNumber} tidak dapat dibayar lagi.");
    }
}
