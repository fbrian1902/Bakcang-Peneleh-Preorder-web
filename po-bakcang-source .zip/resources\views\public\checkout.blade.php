@php
    use App\Enums\FulfillmentType;
    use App\Support\Money;
@endphp

<x-layouts.public>
    @section('title', 'Checkout — '.config('bakcang.store.name'))

    <h1 class="text-xl font-semibold">Checkout</h1>
    <p class="mt-1 text-sm text-zinc-500">Tanpa perlu membuat akun.</p>

    <form method="POST" action="{{ route('checkout.store') }}"
          x-data="{ type: '{{ old('fulfillment_type', FulfillmentType::Pickup->value) }}' }"
          class="mt-6 grid gap-6 lg:grid-cols-[1fr_320px] lg:items-start">
        @csrf

        <div class="space-y-6">
            <section class="card p-5">
                <h2 class="text-sm font-medium">Data pemesan</h2>

                <div class="mt-4 grid gap-4 sm:grid-cols-2">
                    <div>
                        <label for="customer_name" class="label">Nama lengkap</label>
                        <input id="customer_name" name="customer_name" type="text" required
                               value="{{ old('customer_name') }}" class="field">
                        @error('customer_name')<p class="mt-1 text-sm text-red-700">{{ $message }}</p>@enderror
                    </div>

                    <div>
                        <label for="customer_phone" class="label">Nomor WhatsApp</label>
                        <input id="customer_phone" name="customer_phone" type="tel" required
                               inputmode="numeric" placeholder="081234567890"
                               value="{{ old('customer_phone') }}" class="field">
                        @error('customer_phone')<p class="mt-1 text-sm text-red-700">{{ $message }}</p>@enderror
                    </div>

                    <div class="sm:col-span-2">
                        <label for="customer_email" class="label">
                            Email <span class="font-normal text-zinc-400">— opsional, untuk struk</span>
                        </label>
                        <input id="customer_email" name="customer_email" type="email"
                               value="{{ old('customer_email') }}" class="field">
                        @error('customer_email')<p class="mt-1 text-sm text-red-700">{{ $message }}</p>@enderror
                    </div>
                </div>
            </section>

            <section class="card p-5">
                <h2 class="text-sm font-medium">Pengambilan</h2>

                <div class="mt-4 grid gap-2 sm:grid-cols-2">
                    @foreach (FulfillmentType::cases() as $option)
                        <label class="flex cursor-pointer items-start gap-2.5 rounded border border-zinc-200 p-3">
                            <input type="radio" name="fulfillment_type" value="{{ $option->value }}"
                                   x-model="type"
                                   class="mt-0.5 border-zinc-300 text-accent-600 focus:ring-accent-600">
                            <span class="text-sm">
                                <span class="block font-medium">{{ $option->label() }}</span>
                                <span class="mt-0.5 block text-zinc-500">
                                    {{ $option->incursDeliveryFee()
                                        ? '+ '.Money::format($deliveryFee)
                                        : 'Gratis' }}
                                </span>
                            </span>
                        </label>
                    @endforeach
                </div>

                <div x-show="type === '{{ FulfillmentType::Delivery->value }}'" x-cloak class="mt-4">
                    <label for="address" class="label">Alamat pengiriman</label>
                    <textarea id="address" name="address" rows="3"
                              placeholder="Nama jalan, nomor rumah, kecamatan, patokan"
                              class="field">{{ old('address') }}</textarea>
                    @error('address')<p class="mt-1 text-sm text-red-700">{{ $message }}</p>@enderror
                </div>

                <div class="mt-4 grid gap-4 sm:grid-cols-2">
                    <div>
                        <label for="fulfillment_date" class="label">Tanggal</label>
                        <input id="fulfillment_date" name="fulfillment_date" type="date" required
                               min="{{ now()->addDays((int) config('bakcang.fulfillment.min_lead_days'))->toDateString() }}"
                               max="{{ now()->addDays((int) config('bakcang.fulfillment.max_lead_days'))->toDateString() }}"
                               value="{{ old('fulfillment_date', now()->addDays((int) config('bakcang.fulfillment.min_lead_days'))->toDateString()) }}"
                               class="field">
                        @error('fulfillment_date')<p class="mt-1 text-sm text-red-700">{{ $message }}</p>@enderror
                    </div>

                    <div>
                        <label for="fulfillment_time" class="label">Jam</label>
                        <input id="fulfillment_time" name="fulfillment_time" type="time" required
                               min="{{ config('bakcang.fulfillment.pickup_open') }}"
                               max="{{ config('bakcang.fulfillment.pickup_close') }}"
                               value="{{ old('fulfillment_time', config('bakcang.fulfillment.pickup_open')) }}"
                               class="field">
                        @error('fulfillment_time')<p class="mt-1 text-sm text-red-700">{{ $message }}</p>@enderror
                    </div>
                </div>

                <div class="mt-4">
                    <label for="notes" class="label">
                        Catatan <span class="font-normal text-zinc-400">— opsional</span>
                    </label>
                    <textarea id="notes" name="notes" rows="2" maxlength="500" class="field">{{ old('notes') }}</textarea>
                </div>
            </section>
        </div>

        <aside class="card p-5">
            <h2 class="text-sm font-medium">Ringkasan</h2>

            <ul class="mt-4 divide-y divide-zinc-200 text-sm">
                @foreach ($items as $item)
                    <li class="flex items-start justify-between gap-3 py-2">
                        <div class="min-w-0">
                            <p class="truncate">{{ $item->name }}</p>
                            <p class="mt-0.5 text-xs text-zinc-500">
                                {{ $item->quantity }} × {{ Money::format($item->unitPrice) }}
                            </p>
                        </div>
                        <p class="shrink-0 tabular-nums">{{ Money::format($item->lineTotal()) }}</p>
                    </li>
                @endforeach
            </ul>

            <dl class="mt-4 space-y-1.5 border-t border-zinc-200 pt-4 text-sm">
                <div class="flex justify-between">
                    <dt class="text-zinc-500">Subtotal</dt>
                    <dd class="tabular-nums">{{ Money::format($subtotal) }}</dd>
                </div>
                <div class="flex justify-between">
                    <dt class="text-zinc-500">Ongkos kirim</dt>
                    <dd class="tabular-nums"
                        x-text="type === '{{ FulfillmentType::Delivery->value }}'
                            ? '{{ Money::format($deliveryFee) }}' : 'Gratis'"></dd>
                </div>
                <div class="flex justify-between border-t border-zinc-200 pt-2 font-semibold">
                    <dt>Total</dt>
                    <dd class="tabular-nums"
                        x-text="type === '{{ FulfillmentType::Delivery->value }}'
                            ? '{{ Money::format($subtotal + $deliveryFee) }}'
                            : '{{ Money::format($subtotal) }}'"></dd>
                </div>
            </dl>

            <button type="submit" class="btn-primary mt-5 w-full">Buat pesanan</button>

            <p class="mt-2 text-center text-xs text-zinc-500">
                Pembayaran diproses lewat Midtrans.
            </p>
        </aside>
    </form>
</x-layouts.public>
