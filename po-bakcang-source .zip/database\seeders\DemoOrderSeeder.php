<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Enums\OrderStatus;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Payment;
use App\Models\Product;
use Illuminate\Database\Seeder;
use Illuminate\Support\Carbon;
use Illuminate\Support\Collection;

/**
 * Populates the dashboard and reports with plausible history.
 *
 * Not run by default — invoke with `php artisan db:seed --class=DemoOrderSeeder`.
 */
class DemoOrderSeeder extends Seeder
{
    public function run(): void
    {
        $products = Product::query()->get();

        if ($products->isEmpty()) {
            $this->call(ProductSeeder::class);
            $products = Product::query()->get();
        }

        $sequence = 1;

        // Spread orders across the last 30 days so the revenue and
        // orders-per-day charts have a real distribution to draw.
        for ($daysAgo = 29; $daysAgo >= 0; $daysAgo--) {
            $date = Carbon::today()->subDays($daysAgo);

            foreach (range(1, random_int(1, 5)) as $ignored) {
                $status = $this->statusForAge($daysAgo);

                $order = Order::factory()
                    ->{random_int(0, 1) === 1 ? 'delivery' : 'pickup'}()
                    ->status($status)
                    ->create([
                        'order_number' => sprintf(
                            '%s-%s-%04d',
                            config('bakcang.order.prefix'),
                            $date->format('Ymd'),
                            $sequence++,
                        ),
                        'created_at' => $date->copy()->addHours(random_int(8, 19)),
                        'updated_at' => $date->copy()->addHours(random_int(8, 19)),
                        'fulfillment_date' => $date->copy()->addDays(random_int(1, 3)),
                    ]);

                $this->attachItems($order, $products);
                $this->attachPayment($order, $status, $date);
            }
        }
    }

    /**
     * Older orders have had time to reach a terminal state; recent ones are
     * still moving through the kitchen.
     */
    private function statusForAge(int $daysAgo): OrderStatus
    {
        return match (true) {
            $daysAgo > 7 => Arr_random_weighted([
                OrderStatus::Completed->value => 85,
                OrderStatus::Cancelled->value => 15,
            ]),
            $daysAgo > 2 => Arr_random_weighted([
                OrderStatus::Completed->value => 60,
                OrderStatus::Ready->value => 20,
                OrderStatus::Cancelled->value => 20,
            ]),
            default => Arr_random_weighted([
                OrderStatus::AwaitingPayment->value => 30,
                OrderStatus::Confirmed->value => 30,
                OrderStatus::Preparing->value => 25,
                OrderStatus::Ready->value => 15,
            ]),
        };
    }

    /**
     * @param  Collection<int, Product>  $products
     */
    private function attachItems(Order $order, $products): void
    {
        // random() without replacement respects UNIQUE (order_id, product_id):
        // a product may appear at most once per order.
        $chosen = $products->random(min(random_int(1, 3), $products->count()));
        $subtotal = 0;

        foreach (collect([$chosen])->flatten() as $product) {
            $quantity = random_int(1, 4);
            $lineTotal = (float) $product->price * $quantity;
            $subtotal += $lineTotal;

            OrderItem::factory()->create([
                'order_id' => $order->id,
                'product_id' => $product->id,
                'product_name' => $product->name,
                'unit_price' => $product->price,
                'quantity' => $quantity,
                'line_total' => $lineTotal,
            ]);
        }

        $order->forceFill([
            'subtotal' => $subtotal,
            'total' => $subtotal + (float) $order->delivery_fee,
        ])->save();
    }

    private function attachPayment(Order $order, OrderStatus $status, Carbon $date): void
    {
        $attributes = [
            'order_id' => $order->id,
            'midtrans_order_id' => $order->order_number.'-1',
            'gross_amount' => $order->total,
            'created_at' => $order->created_at,
            'updated_at' => $order->created_at,
        ];

        $factory = Payment::factory();

        $factory = match ($status) {
            OrderStatus::AwaitingPayment => $factory,
            OrderStatus::Cancelled => $factory->expired(),
            default => $factory->settled(
                fake()->randomElement(['qris', 'gopay', 'bank_transfer', 'credit_card']),
            ),
        };

        $payment = $factory->create($attributes);

        // Settlement drives revenue reporting, so it must fall on the day the
        // order was placed rather than on "now".
        if ($payment->settlement_time !== null) {
            $payment->forceFill([
                'transaction_time' => $order->created_at,
                'settlement_time' => $order->created_at->copy()->addMinutes(random_int(1, 90)),
            ])->save();
        }
    }
}

/**
 * Picks a key from a weight map. Declared here rather than as a helper because
 * it exists purely to shape demo data.
 *
 * @param  array<string, int>  $weights
 */
function Arr_random_weighted(array $weights): OrderStatus
{
    $roll = random_int(1, array_sum($weights));
    $cursor = 0;

    foreach ($weights as $value => $weight) {
        $cursor += $weight;

        if ($roll <= $cursor) {
            return OrderStatus::from($value);
        }
    }

    return OrderStatus::from(array_key_first($weights));
}
