<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * Mirrors the `payments.fraud_status` ENUM.
 *
 * Only ever populated for card transactions; other channels leave it NULL.
 */
enum FraudStatus: string
{
    case Accept = 'accept';
    case Challenge = 'challenge';
    case Deny = 'deny';

    public function label(): string
    {
        return match ($this) {
            self::Accept => 'Diterima',
            self::Challenge => 'Perlu Ditinjau',
            self::Deny => 'Ditolak',
        };
    }

    /**
     * A `capture` paired with `challenge` is money held pending manual review
     * in the Midtrans dashboard, not money received — so it must not confirm
     * the order.
     */
    public function isCleared(): bool
    {
        return $this === self::Accept;
    }
}
