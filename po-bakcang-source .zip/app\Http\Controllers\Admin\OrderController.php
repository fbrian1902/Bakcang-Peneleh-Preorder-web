<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\UpdateOrderStatusRequest;
use App\Models\Order;
use App\Repositories\Contracts\OrderRepositoryInterface;
use App\Services\Order\OrderStatusService;
use App\Services\Report\InvoiceService;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class OrderController extends Controller
{
    public function __construct(
        private readonly OrderRepositoryInterface $orders,
        private readonly OrderStatusService $statuses,
    ) {}

    public function index(Request $request): View
    {
        $filters = $this->filters($request);

        return view('admin.orders.index', [
            'orders' => $this->orders->paginateForAdmin($filters, perPage: 15),
            'filters' => $filters,
        ]);
    }

    public function show(Order $order): View
    {
        $order->load([
            'items.product',
            'payments' => fn ($query) => $query->latest('id'),
        ]);

        return view('admin.orders.show', ['order' => $order]);
    }

    public function updateStatus(UpdateOrderStatusRequest $request, Order $order): RedirectResponse
    {
        // The service owns the state machine and throws a ValidationException
        // on an illegal transition, which Laravel renders back onto the form.
        $this->statuses->transition($order, $request->status());

        return back()->with('success', 'Status pesanan diperbarui.');
    }

    public function invoice(Order $order, InvoiceService $invoices): Response
    {
        return $invoices->generate($order)->download($invoices->filename($order));
    }

    /**
     * @return array{search: string|null, status: string|null, from: string|null, to: string|null}
     */
    private function filters(Request $request): array
    {
        return [
            'search' => $request->string('search')->toString() ?: null,
            'status' => $request->string('status')->toString() ?: null,
            'from' => $request->date('from')?->toDateString(),
            'to' => $request->date('to')?->toDateString(),
        ];
    }
}
