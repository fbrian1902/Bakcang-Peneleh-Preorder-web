<?php

declare(strict_types=1);

namespace App\Notifications;

use App\Enums\OrderStatus;
use App\Models\Order;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class OrderStatusChangedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(
        public readonly Order $order,
        public readonly OrderStatus $status,
    ) {}

    /**
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject("Update Pesanan {$this->order->order_number} — {$this->status->label()}")
            ->greeting("Halo {$this->order->customer_name},")
            ->line($this->body())
            ->action('Lihat Pesanan', route('order.show', $this->order->order_number));
    }

    private function body(): string
    {
        return match ($this->status) {
            OrderStatus::Preparing => 'Pesanan Anda sedang kami siapkan di dapur.',
            OrderStatus::Ready => $this->order->fulfillment_type->requiresAddress()
                ? 'Pesanan Anda sudah siap dan segera dikirim.'
                : 'Pesanan Anda sudah siap untuk diambil.',
            OrderStatus::Completed => 'Pesanan Anda telah selesai. Terima kasih!',
            OrderStatus::Cancelled => 'Mohon maaf, pesanan Anda telah dibatalkan.',
            default => "Status pesanan Anda kini: {$this->status->label()}.",
        };
    }
}
