<?php

declare(strict_types=1);

namespace App\Notifications;

use App\Models\Order;
use App\Models\Payment;
use App\Support\Money;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class PaymentReceivedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(
        public readonly Order $order,
        public readonly Payment $payment,
    ) {}

    /**
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        $schedule = $this->order->fulfillment_date?->translatedFormat('l, d F Y');

        return (new MailMessage)
            ->subject("Pembayaran Diterima — {$this->order->order_number}")
            ->greeting("Halo {$this->order->customer_name},")
            ->line('Pembayaran Anda sudah kami terima. Pesanan segera kami siapkan.')
            ->line("Nomor Pesanan: **{$this->order->order_number}**")
            ->line('Total Dibayar: '.Money::format($this->payment->gross_amount))
            ->line('Metode: '.$this->payment->channelLabel())
            ->when($schedule !== null, fn (MailMessage $mail): MailMessage => $mail->line(
                sprintf(
                    '%s: %s',
                    $this->order->fulfillment_type->label(),
                    $schedule,
                ),
            ))
            ->action('Lihat Status Pesanan', route('order.show', $this->order->order_number))
            ->line('Terima kasih telah memesan di '.config('bakcang.store.name').'.');
    }
}
