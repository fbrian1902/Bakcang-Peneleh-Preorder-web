<?php

declare(strict_types=1);

use App\Http\Controllers\Admin\DashboardController;
use App\Http\Controllers\Admin\OrderController as AdminOrderController;
use App\Http\Controllers\Admin\PaymentController;
use App\Http\Controllers\Admin\ProductController;
use App\Http\Controllers\Admin\ReportController;
use App\Http\Controllers\ProfileController;
use App\Http\Controllers\Public\CartController;
use App\Http\Controllers\Public\CheckoutController;
use App\Http\Controllers\Public\LandingController;
use App\Http\Controllers\Public\OrderController;
use App\Http\Controllers\Public\PaymentReturnController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Public — no authentication
|--------------------------------------------------------------------------
*/

Route::get('/', LandingController::class)->name('landing');

Route::controller(CartController::class)
    ->prefix('keranjang')
    ->name('cart.')
    ->middleware('throttle:cart')
    ->group(function (): void {
        Route::post('tambah/{product}', 'add')->name('add');
        Route::patch('{product}', 'update')->name('update');
        Route::delete('{product}', 'remove')->name('remove');
    });

Route::controller(CheckoutController::class)->group(function (): void {
    Route::get('checkout', 'show')->name('checkout.show');
    Route::post('checkout', 'store')->name('checkout.store')->middleware('throttle:checkout');
});

// Bound on order_number, not id — sequential ids would let anyone enumerate
// other customers' orders.
Route::controller(OrderController::class)->group(function (): void {
    Route::get('pesanan/{order}', 'show')->name('order.show');
    Route::post('pesanan/{order}/bayar', 'pay')->name('order.pay')->middleware('throttle:payment');
});

// Fallback landing point for the Finish / Unfinish / Error redirects set in the
// Midtrans dashboard. Reads order_id only to pick a destination — it never
// treats the redirect's status parameters as proof of payment.
Route::get('pembayaran/selesai', PaymentReturnController::class)
    ->name('payment.return');

/*
|--------------------------------------------------------------------------
| Admin — authenticated, admin-only
|--------------------------------------------------------------------------
*/

// Breeze redirects here after login; the admin panel is the only destination
// this application has for an authenticated user.
Route::get('/dashboard', fn () => redirect()->route('admin.dashboard'))
    ->middleware(['auth', 'verified'])
    ->name('dashboard');

Route::middleware(['auth', 'verified', 'admin'])
    ->prefix('admin')
    ->name('admin.')
    ->group(function (): void {
        Route::get('/', DashboardController::class)->name('dashboard');

        Route::resource('products', ProductController::class)->except('show');

        Route::controller(AdminOrderController::class)
            ->prefix('orders')
            ->name('orders.')
            ->group(function (): void {
                Route::get('/', 'index')->name('index');
                Route::get('{order}', 'show')->name('show');
                Route::patch('{order}/status', 'updateStatus')->name('status');
                Route::get('{order}/invoice', 'invoice')->name('invoice');
            });

        Route::controller(PaymentController::class)
            ->prefix('payments')
            ->name('payments.')
            ->group(function (): void {
                Route::get('/', 'index')->name('index');
                Route::post('{payment}/sync', 'sync')->name('sync');
            });

        Route::controller(ReportController::class)
            ->prefix('reports')
            ->name('reports.')
            ->group(function (): void {
                Route::get('/', 'index')->name('index');
                Route::get('pdf', 'pdf')->name('pdf');
                Route::get('export/{type}/{format}', 'export')
                    ->whereIn('type', ['orders', 'payments', 'products'])
                    ->whereIn('format', ['xlsx', 'csv'])
                    ->name('export');
            });
    });

/*
|--------------------------------------------------------------------------
| Profile — Breeze
|--------------------------------------------------------------------------
*/

Route::middleware('auth')->group(function (): void {
    Route::get('/profile', [ProfileController::class, 'edit'])->name('profile.edit');
    Route::patch('/profile', [ProfileController::class, 'update'])->name('profile.update');
    Route::delete('/profile', [ProfileController::class, 'destroy'])->name('profile.destroy');
});

require __DIR__.'/auth.php';
