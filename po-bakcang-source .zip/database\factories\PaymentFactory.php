<?php

declare(strict_types=1);

namespace Database\Factories;

use App\Enums\FraudStatus;
use App\Enums\TransactionStatus;
use App\Models\Order;
use App\Models\Payment;
use Illuminate\Database\Eloquent\Factories\Factory;

/**
 * @extends Factory<Payment>
 */
class PaymentFactory extends Factory
{
    protected $model = Payment::class;

    /**
     * @return array<string, mixed>
     */
    public function definition(): array
    {
        return [
            'order_id' => Order::factory(),
            'midtrans_order_id' => fake()->unique()->bothify('BP-########-####-#'),
            'snap_token' => fake()->uuid(),
            'redirect_url' => 'https://app.sandbox.midtrans.com/snap/v3/redirection/'.fake()->uuid(),
            'transaction_id' => null,
            'payment_type' => null,
            'gross_amount' => fake()->numberBetween(15, 300) * 1000,
            'transaction_status' => TransactionStatus::Pending,
            'fraud_status' => null,
            'transaction_time' => null,
            'settlement_time' => null,
            'expiry_time' => now()->addDay(),
            'raw_notification' => null,
        ];
    }

    public function settled(?string $paymentType = 'qris'): static
    {
        return $this->state(fn (): array => [
            'transaction_id' => fake()->unique()->uuid(),
            'payment_type' => $paymentType,
            'transaction_status' => TransactionStatus::Settlement,
            'fraud_status' => FraudStatus::Accept,
            'transaction_time' => now()->subMinutes(5),
            'settlement_time' => now(),
        ]);
    }

    /**
     * Captured but held for manual fraud review — deliberately not revenue.
     */
    public function challenged(): static
    {
        return $this->state(fn (): array => [
            'transaction_id' => fake()->unique()->uuid(),
            'payment_type' => 'credit_card',
            'transaction_status' => TransactionStatus::Capture,
            'fraud_status' => FraudStatus::Challenge,
            'transaction_time' => now()->subMinutes(5),
        ]);
    }

    public function expired(): static
    {
        return $this->state(fn (): array => [
            'transaction_status' => TransactionStatus::Expire,
            'expiry_time' => now()->subHour(),
        ]);
    }

    public function status(TransactionStatus $status): static
    {
        return $this->state(fn (): array => ['transaction_status' => $status]);
    }
}
