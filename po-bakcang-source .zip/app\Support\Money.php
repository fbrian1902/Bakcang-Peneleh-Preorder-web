<?php

declare(strict_types=1);

namespace App\Support;

/**
 * Rupiah formatting helpers.
 *
 * Amounts are stored as DECIMAL and cast to string by Eloquent to avoid the
 * precision loss of binary floats. IDR has no sub-unit in practice, so values
 * are normalised to whole rupiah before display or transmission — Midtrans in
 * particular rejects a `gross_amount` carrying decimals.
 */
final class Money
{
    public static function format(int|float|string|null $amount): string
    {
        return 'Rp '.number_format((float) ($amount ?? 0), 0, ',', '.');
    }

    /**
     * Whole rupiah, for Midtrans payloads and arithmetic.
     */
    public static function toInt(int|float|string|null $amount): int
    {
        return (int) round((float) ($amount ?? 0));
    }
}
