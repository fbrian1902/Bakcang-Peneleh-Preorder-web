@php use App\Support\Money; @endphp

<x-layouts.admin :title="$order->order_number">
    <x-slot:actions>
        <a href="{{ route('admin.orders.invoice', $order) }}" class="btn-secondary">Unduh invoice</a>
    </x-slot:actions>

    <div class="grid gap-6 lg:grid-cols-[1fr_300px] lg:items-start">
        <div class="space-y-6">
            <section class="card p-5">
                <h2 class="text-sm font-medium">Rincian pesanan</h2>

                <ul class="mt-3 divide-y divide-zinc-200 text-sm">
                    @foreach ($order->items as $item)
                        <li class="flex items-start justify-between gap-3 py-2">
                            <div class="min-w-0">
                                <p>{{ $item->product_name }}</p>
                                <p class="mt-0.5 text-xs text-zinc-500">
                                    {{ $item->quantity }} × {{ Money::format($item->unit_price) }}
                                    @if ($item->product === null)
                                        · produk sudah dihapus
                                    @endif
                                </p>
                            </div>
                            <p class="shrink-0 tabular-nums">{{ Money::format($item->line_total) }}</p>
                        </li>
                    @endforeach
                </ul>

                <dl class="mt-3 space-y-1.5 border-t border-zinc-200 pt-3 text-sm">
                    <div class="flex justify-between">
                        <dt class="text-zinc-500">Subtotal</dt>
                        <dd class="tabular-nums">{{ Money::format($order->subtotal) }}</dd>
                    </div>
                    <div class="flex justify-between">
                        <dt class="text-zinc-500">Ongkos kirim</dt>
                        <dd class="tabular-nums">{{ Money::format($order->delivery_fee) }}</dd>
                    </div>
                    <div class="flex justify-between border-t border-zinc-200 pt-2 font-semibold">
                        <dt>Total</dt>
                        <dd class="tabular-nums">{{ Money::format($order->total) }}</dd>
                    </div>
                </dl>
            </section>

            {{-- One row per attempt: Midtrans refuses to reuse an order_id
                 after a failure. --}}
            <section class="card p-5">
                <h2 class="text-sm font-medium">Riwayat pembayaran</h2>

                @if ($order->payments->isEmpty())
                    <x-empty-state title="Belum ada percobaan pembayaran"
                        description="Pelanggan belum membuka halaman pembayaran Midtrans." />
                @else
                    <ul class="mt-3 divide-y divide-zinc-200">
                        @foreach ($order->payments as $payment)
                            <li class="py-3 text-sm">
                                <div class="flex flex-wrap items-start justify-between gap-2">
                                    <div class="min-w-0">
                                        <p class="font-mono text-xs">{{ $payment->midtrans_order_id }}</p>
                                        <p class="mt-0.5 text-xs text-zinc-500">
                                            {{ $payment->channelLabel() }} · {{ Money::format($payment->gross_amount) }}
                                        </p>
                                    </div>
                                    <span class="badge {{ $payment->transaction_status->badgeClasses() }}">
                                        {{ $payment->transaction_status->label() }}
                                    </span>
                                </div>

                                <dl class="mt-2 grid gap-x-4 text-xs text-zinc-500 sm:grid-cols-2">
                                    @if ($payment->transaction_id)
                                        <div class="flex gap-1.5">
                                            <dt>Transaction ID:</dt>
                                            <dd class="truncate font-mono">{{ $payment->transaction_id }}</dd>
                                        </div>
                                    @endif
                                    @if ($payment->fraud_status)
                                        <div class="flex gap-1.5"><dt>Fraud:</dt><dd>{{ $payment->fraud_status->label() }}</dd></div>
                                    @endif
                                    @if ($payment->settlement_time)
                                        <div class="flex gap-1.5">
                                            <dt>Settlement:</dt>
                                            <dd>{{ $payment->settlement_time->format('d M Y, H:i') }}</dd>
                                        </div>
                                    @endif
                                </dl>

                                <form method="POST" action="{{ route('admin.payments.sync', $payment) }}" class="mt-2">
                                    @csrf
                                    <button type="submit" class="text-xs text-accent-700 hover:underline">
                                        Sinkronkan dari Midtrans
                                    </button>
                                </form>
                            </li>
                        @endforeach
                    </ul>
                @endif
            </section>
        </div>

        <div class="space-y-6">
            <section class="card p-5">
                <h2 class="text-sm font-medium">Status</h2>

                <span class="badge mt-2 {{ $order->status->badgeClasses() }}">{{ $order->status->label() }}</span>

                @php $transitions = $order->status->allowedTransitions(); @endphp

                @if ($transitions === [])
                    <p class="mt-3 text-sm text-zinc-500">
                        {{ $order->status->isTerminal()
                            ? 'Pesanan sudah final dan tidak dapat diubah.'
                            : 'Tidak ada perubahan status yang tersedia.' }}
                    </p>
                @else
                    <form method="POST" action="{{ route('admin.orders.status', $order) }}" class="mt-3 space-y-2">
                        @csrf
                        @method('PATCH')

                        <label for="status" class="label">Ubah ke</label>
                        <select id="status" name="status" class="field">
                            @foreach ($transitions as $target)
                                <option value="{{ $target->value }}">{{ $target->label() }}</option>
                            @endforeach
                        </select>

                        @error('status')<p class="text-sm text-red-700">{{ $message }}</p>@enderror

                        <button type="submit" class="btn-primary w-full">Simpan status</button>
                    </form>
                @endif

                @if ($order->isAwaitingPayment())
                    <p class="mt-3 text-xs text-zinc-500">
                        Pesanan hanya bisa dikonfirmasi oleh notifikasi Midtrans, bukan manual.
                    </p>
                @endif
            </section>

            <section class="card p-5">
                <h2 class="text-sm font-medium">Pelanggan</h2>
                <dl class="mt-3 space-y-2.5 text-sm">
                    <div>
                        <dt class="text-xs text-zinc-500">Nama</dt>
                        <dd>{{ $order->customer_name }}</dd>
                    </div>
                    <div>
                        <dt class="text-xs text-zinc-500">WhatsApp</dt>
                        <dd>
                            <a href="https://wa.me/{{ preg_replace('/\D/', '', $order->customer_phone) }}"
                               class="text-accent-700 hover:underline">{{ $order->customer_phone }}</a>
                        </dd>
                    </div>
                    @if ($order->customer_email)
                        <div>
                            <dt class="text-xs text-zinc-500">Email</dt>
                            <dd class="break-all">{{ $order->customer_email }}</dd>
                        </div>
                    @endif
                    <div>
                        <dt class="text-xs text-zinc-500">{{ $order->fulfillment_type->label() }}</dt>
                        <dd>
                            {{ $order->fulfillment_date?->translatedFormat('l, d F Y') }}
                            @if ($order->fulfillment_time)
                                · {{ substr($order->fulfillment_time, 0, 5) }}
                            @endif
                        </dd>
                    </div>
                    @if ($order->address)
                        <div>
                            <dt class="text-xs text-zinc-500">Alamat</dt>
                            <dd>{{ $order->address }}</dd>
                        </div>
                    @endif
                    @if ($order->notes)
                        <div>
                            <dt class="text-xs text-zinc-500">Catatan</dt>
                            <dd>{{ $order->notes }}</dd>
                        </div>
                    @endif
                </dl>
            </section>
        </div>
    </div>
</x-layouts.admin>
