@props([
    'label',
    'value',
    'hint' => null,
])

<div {{ $attributes->merge(['class' => 'card p-4']) }}>
    <p class="text-xs text-zinc-500">{{ $label }}</p>
    <p class="mt-1 text-xl font-semibold tabular-nums">{{ $value }}</p>
    @if ($hint)
        <p class="mt-0.5 text-xs text-zinc-400">{{ $hint }}</p>
    @endif
</div>
