@php
    use App\Enums\TransactionStatus;
    use App\Support\Money;
@endphp

<x-layouts.admin title="Pembayaran">
    <form method="GET" class="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <div class="lg:col-span-2">
            <label for="search" class="label">Cari</label>
            <input id="search" name="search" type="search" value="{{ $filters['search'] }}"
                   placeholder="Order ID, transaction ID, nomor pesanan" class="field">
        </div>

        <div>
            <label for="status" class="label">Status</label>
            <select id="status" name="status" class="field">
                <option value="">Semua</option>
                @foreach (TransactionStatus::options() as $value => $label)
                    <option value="{{ $value }}" @selected($filters['status'] === $value)>{{ $label }}</option>
                @endforeach
            </select>
        </div>

        <div>
            <label for="from" class="label">Settle dari</label>
            <input id="from" name="from" type="date" value="{{ $filters['from'] }}" class="field">
        </div>

        <div>
            <label for="to" class="label">Sampai</label>
            <input id="to" name="to" type="date" value="{{ $filters['to'] }}" class="field">
        </div>

        <div class="flex items-end gap-2 sm:col-span-2 lg:col-span-5">
            <button type="submit" class="btn-secondary">Terapkan</button>
            <a href="{{ route('admin.payments.index') }}" class="btn-ghost">Atur ulang</a>
        </div>
    </form>

    @if ($payments->isEmpty())
        <x-empty-state class="card mt-6"
            title="Tidak ada pembayaran"
            description="Belum ada transaksi yang cocok dengan filter ini.">
            <a href="{{ route('admin.payments.index') }}" class="btn-secondary">Hapus filter</a>
        </x-empty-state>
    @else
        <div class="card mt-6 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="border-b border-zinc-200 bg-zinc-50 text-left text-xs text-zinc-500">
                        <tr>
                            <th scope="col" class="px-4 py-2 font-medium">Midtrans Order ID</th>
                            <th scope="col" class="px-4 py-2 font-medium">Pesanan</th>
                            <th scope="col" class="px-4 py-2 font-medium">Metode</th>
                            <th scope="col" class="px-4 py-2 text-right font-medium">Nominal</th>
                            <th scope="col" class="px-4 py-2 font-medium">Status</th>
                            <th scope="col" class="px-4 py-2 font-medium">Settlement</th>
                            <th scope="col" class="px-4 py-2"><span class="sr-only">Aksi</span></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-zinc-200">
                        @foreach ($payments as $payment)
                            <tr class="hover:bg-zinc-50">
                                <td class="px-4 py-2.5 font-mono text-xs">{{ $payment->midtrans_order_id }}</td>
                                <td class="px-4 py-2.5">
                                    @if ($payment->order)
                                        <a href="{{ route('admin.orders.show', $payment->order) }}"
                                           class="text-accent-700 hover:underline">{{ $payment->order->order_number }}</a>
                                    @else
                                        <span class="text-zinc-400">—</span>
                                    @endif
                                </td>
                                <td class="px-4 py-2.5">{{ $payment->channelLabel() }}</td>
                                <td class="px-4 py-2.5 text-right tabular-nums">
                                    {{ Money::format($payment->gross_amount) }}
                                </td>
                                <td class="px-4 py-2.5">
                                    <span class="badge {{ $payment->transaction_status->badgeClasses() }}">
                                        {{ $payment->transaction_status->label() }}
                                    </span>
                                    @if ($payment->fraud_status?->value === 'challenge')
                                        <p class="mt-0.5 text-xs text-amber-700">Perlu ditinjau</p>
                                    @endif
                                </td>
                                <td class="px-4 py-2.5 text-xs text-zinc-500">
                                    {{ $payment->settlement_time?->format('d M Y, H:i') ?? '—' }}
                                </td>
                                <td class="px-4 py-2.5 text-right">
                                    <form method="POST" action="{{ route('admin.payments.sync', $payment) }}">
                                        @csrf
                                        <button type="submit" class="text-xs text-accent-700 hover:underline">
                                            Sinkronkan
                                        </button>
                                    </form>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        <div class="mt-6">{{ $payments->links() }}</div>
    @endif
</x-layouts.admin>
