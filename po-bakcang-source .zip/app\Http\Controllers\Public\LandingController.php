<?php

declare(strict_types=1);

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use App\Repositories\Contracts\ProductRepositoryInterface;
use Illuminate\Contracts\View\View;

class LandingController extends Controller
{
    public function __invoke(ProductRepositoryInterface $products): View
    {
        return view('public.landing', [
            'products' => $products->availableForCatalog(),
        ]);
    }
}
