<?php

declare(strict_types=1);

namespace App\DataTransferObjects;

use App\Enums\FulfillmentType;

/**
 * Validated checkout input.
 *
 * Carries no monetary fields on purpose — subtotal, delivery fee and total are
 * derived server-side in OrderService from the cart and configuration, so a
 * tampered request cannot influence what the customer is charged.
 */
final readonly class CheckoutData
{
    public function __construct(
        public string $customerName,
        public string $customerPhone,
        public ?string $customerEmail,
        public FulfillmentType $fulfillmentType,
        public ?string $address,
        public ?string $fulfillmentDate,
        public ?string $fulfillmentTime,
        public ?string $notes,
    ) {}

    /**
     * @param  array<string, mixed>  $validated
     */
    public static function fromArray(array $validated): self
    {
        $type = FulfillmentType::from((string) $validated['fulfillment_type']);

        return new self(
            customerName: trim((string) $validated['customer_name']),
            customerPhone: trim((string) $validated['customer_phone']),
            customerEmail: filled($validated['customer_email'] ?? null)
                ? trim((string) $validated['customer_email'])
                : null,
            fulfillmentType: $type,
            // Address is meaningless for pickup; dropping it here keeps stale
            // input from a toggled radio button out of the database.
            address: $type->requiresAddress() ? trim((string) $validated['address']) : null,
            fulfillmentDate: $validated['fulfillment_date'] ?? null,
            fulfillmentTime: $validated['fulfillment_time'] ?? null,
            notes: filled($validated['notes'] ?? null) ? trim((string) $validated['notes']) : null,
        );
    }
}
