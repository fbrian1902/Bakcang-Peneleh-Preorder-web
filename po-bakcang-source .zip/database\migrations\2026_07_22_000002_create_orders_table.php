<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('orders', function (Blueprint $table): void {
            $table->id();
            $table->string('order_number', 20);
            $table->string('customer_name', 100);
            $table->string('customer_phone', 20);
            $table->string('customer_email', 150)->nullable();
            $table->enum('fulfillment_type', ['delivery', 'pickup']);

            // Delivery only. Conditional presence cannot be expressed in the
            // schema, so StoreOrderRequest enforces it with required_if.
            $table->string('address', 255)->nullable();

            // Renamed from pickup_date/pickup_time: the original schema gave
            // delivery orders no scheduled date at all, leaving the kitchen
            // unable to produce a "due tomorrow" list for them. Both
            // fulfillment types now schedule through these columns.
            $table->date('fulfillment_date')->nullable();
            $table->time('fulfillment_time')->nullable();

            $table->enum('status', [
                'awaiting_payment',
                'confirmed',
                'preparing',
                'ready',
                'completed',
                'cancelled',
            ])->default('awaiting_payment');

            $table->decimal('subtotal', 12, 2)->default(0);
            $table->decimal('delivery_fee', 10, 2)->default(0);
            $table->decimal('total', 12, 2)->default(0);
            $table->string('notes', 500)->nullable();
            $table->timestamps();

            $table->unique('order_number', 'uq_orders_number');
            $table->index('status', 'ix_orders_status');
            $table->index('customer_phone', 'ix_orders_phone');
            $table->index('created_at', 'ix_orders_created');

            // Supports the kitchen's daily production queue, which filters by
            // scheduled date and then splits by fulfillment type.
            $table->index(['fulfillment_date', 'fulfillment_type'], 'ix_orders_fulfillment');
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('orders');
    }
};
