<?php

declare(strict_types=1);

namespace App\Services\Order;

use App\DataTransferObjects\CartItemData;
use App\DataTransferObjects\CheckoutData;
use App\Enums\OrderStatus;
use App\Events\OrderCreated;
use App\Exceptions\CheckoutException;
use App\Models\Order;
use App\Repositories\Contracts\OrderRepositoryInterface;
use App\Services\Cart\CartService;
use Illuminate\Database\QueryException;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class OrderService
{
    public function __construct(
        private readonly OrderRepositoryInterface $orders,
        private readonly CartService $cart,
    ) {}

    /**
     * Turns the current cart into a persisted order.
     *
     * Everything monetary is computed here from the reconciled cart and
     * configuration — nothing is taken from the request — so the customer is
     * charged what the catalogue says regardless of what was posted.
     */
    public function createFromCart(CheckoutData $data): Order
    {
        $items = $this->cart->reconcile();

        if ($items->isEmpty()) {
            throw CheckoutException::emptyCart();
        }

        $order = $this->createWithUniqueNumber($data, $items);

        $this->cart->clear();

        OrderCreated::dispatch($order);

        return $order;
    }

    /**
     * Retries on a duplicate order_number.
     *
     * The daily sequence is read outside any lock, so two simultaneous
     * checkouts can compute the same value. The UNIQUE index rejects the
     * loser, which lands here as a QueryException with SQLSTATE 23000; the
     * next pass reads a now-higher sequence. This is cheaper than serialising
     * all checkouts behind a lock to prevent a rare collision.
     *
     * @param  Collection<int, CartItemData>  $items
     */
    private function createWithUniqueNumber(CheckoutData $data, Collection $items): Order
    {
        $maxAttempts = (int) config('bakcang.order.max_number_attempts');

        for ($attempt = 1; $attempt <= $maxAttempts; $attempt++) {
            try {
                return DB::transaction(function () use ($data, $items): Order {
                    $order = $this->persistOrder($data, $items);

                    $this->persistItems($order, $items);

                    return $order->load('items');
                });
            } catch (QueryException $exception) {
                if (! $this->isDuplicateOrderNumber($exception) || $attempt === $maxAttempts) {
                    throw $exception;
                }
            }
        }

        throw CheckoutException::orderNumberExhausted($maxAttempts);
    }

    /**
     * @param  Collection<int, CartItemData>  $items
     */
    private function persistOrder(CheckoutData $data, Collection $items): Order
    {
        $subtotal = (float) $items->sum(static fn (CartItemData $item): float => $item->lineTotal());

        $deliveryFee = $data->fulfillmentType->incursDeliveryFee()
            ? (float) config('bakcang.fulfillment.delivery_fee')
            : 0.0;

        return $this->orders->create([
            'order_number' => $this->generateOrderNumber(),
            'customer_name' => $data->customerName,
            'customer_phone' => $data->customerPhone,
            'customer_email' => $data->customerEmail,
            'fulfillment_type' => $data->fulfillmentType,
            'address' => $data->address,
            'fulfillment_date' => $data->fulfillmentDate,
            'fulfillment_time' => $data->fulfillmentTime,
            'status' => OrderStatus::AwaitingPayment,
            'subtotal' => $subtotal,
            'delivery_fee' => $deliveryFee,
            'total' => $subtotal + $deliveryFee,
            'notes' => $data->notes,
        ]);
    }

    /**
     * Writes one row per product. CartService has already merged repeat
     * additions, so UNIQUE (order_id, product_id) is satisfied by
     * construction. Name and price are snapshotted so later catalogue edits
     * cannot rewrite the customer's receipt.
     *
     * @param  Collection<int, CartItemData>  $items
     */
    private function persistItems(Order $order, Collection $items): void
    {
        $order->items()->createMany(
            $items->map(static fn (CartItemData $item): array => [
                'product_id' => $item->productId,
                'product_name' => $item->name,
                'unit_price' => $item->unitPrice,
                'quantity' => $item->quantity,
                'line_total' => $item->lineTotal(),
            ])->all(),
        );
    }

    /**
     * BP-YYYYMMDD-0001, resetting daily.
     */
    private function generateOrderNumber(): string
    {
        $prefix = (string) config('bakcang.order.prefix');
        $padding = (int) config('bakcang.order.sequence_padding');
        $datePrefix = $prefix.'-'.now()->format('Ymd');

        $sequence = $this->orders->nextDailySequence($datePrefix);

        return $datePrefix.'-'.str_pad((string) $sequence, $padding, '0', STR_PAD_LEFT);
    }

    private function isDuplicateOrderNumber(QueryException $exception): bool
    {
        return $exception->getCode() === '23000'
            && str_contains($exception->getMessage(), 'uq_orders_number');
    }
}
