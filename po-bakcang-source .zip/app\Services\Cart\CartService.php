<?php

declare(strict_types=1);

namespace App\Services\Cart;

use App\DataTransferObjects\CartItemData;
use App\Repositories\Contracts\ProductRepositoryInterface;
use Illuminate\Contracts\Session\Session;
use Illuminate\Support\Collection;

/**
 * Session-backed guest cart.
 *
 * Two rules shape this class:
 *
 *  1. Prices are always re-read from the catalogue, never taken from the
 *     request or trusted from the session, so a tampered payload cannot
 *     change what the customer is charged.
 *
 *  2. Adding a product already in the cart increments the existing line
 *     instead of appending a second one. `order_items` carries
 *     UNIQUE (order_id, product_id), so a duplicated line would abort
 *     checkout with an integrity error at the worst possible moment.
 */
class CartService
{
    public function __construct(
        private readonly ProductRepositoryInterface $products,
        private readonly Session $session,
    ) {}

    /**
     * @return Collection<int, CartItemData>
     */
    public function items(): Collection
    {
        $raw = $this->session->get($this->key(), []);

        return collect($raw)
            ->map(static fn (array $item): CartItemData => CartItemData::fromArray($item))
            ->values();
    }

    public function add(int $productId, int $quantity = 1): void
    {
        $product = $this->products->findAvailableByIds([$productId])->get($productId);

        if ($product === null) {
            return;
        }

        $items = $this->rawItems();
        $existing = $items[$productId]['quantity'] ?? 0;

        $items[$productId] = CartItemData::fromProduct(
            $product,
            $this->clampQuantity($existing + $quantity),
        )->toArray();

        $this->persist($items);
    }

    public function updateQuantity(int $productId, int $quantity): void
    {
        if ($quantity < 1) {
            $this->remove($productId);

            return;
        }

        $items = $this->rawItems();

        if (! isset($items[$productId])) {
            return;
        }

        $items[$productId]['quantity'] = $this->clampQuantity($quantity);

        $this->persist($items);
    }

    public function remove(int $productId): void
    {
        $items = $this->rawItems();

        unset($items[$productId]);

        $this->persist($items);
    }

    public function clear(): void
    {
        $this->session->forget($this->key());
    }

    public function isEmpty(): bool
    {
        return $this->rawItems() === [];
    }

    public function count(): int
    {
        return (int) $this->items()->sum('quantity');
    }

    public function subtotal(): float
    {
        return (float) $this->items()->sum(
            static fn (CartItemData $item): float => $item->lineTotal(),
        );
    }

    /**
     * Drops lines whose product has since been delisted or deleted, and
     * re-prices the survivors against the current catalogue.
     *
     * Called before checkout because a cart can sit in a session for days
     * while an admin edits the catalogue underneath it.
     *
     * @return Collection<int, CartItemData> the surviving, re-priced lines
     */
    public function reconcile(): Collection
    {
        $items = $this->rawItems();

        if ($items === []) {
            return collect();
        }

        $products = $this->products->findAvailableByIds(array_keys($items));
        $fresh = [];

        foreach ($items as $productId => $item) {
            $product = $products->get($productId);

            if ($product === null) {
                continue;
            }

            $fresh[$productId] = CartItemData::fromProduct(
                $product,
                $this->clampQuantity((int) $item['quantity']),
            )->toArray();
        }

        $this->persist($fresh);

        return $this->items();
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    private function rawItems(): array
    {
        return $this->session->get($this->key(), []);
    }

    /**
     * @param  array<int, array<string, mixed>>  $items
     */
    private function persist(array $items): void
    {
        if ($items === []) {
            $this->session->forget($this->key());

            return;
        }

        $this->session->put($this->key(), $items);
    }

    private function clampQuantity(int $quantity): int
    {
        $max = (int) config('bakcang.cart.max_quantity_per_item');

        return max(1, min($quantity, $max));
    }

    private function key(): string
    {
        return (string) config('bakcang.cart.session_key');
    }
}
