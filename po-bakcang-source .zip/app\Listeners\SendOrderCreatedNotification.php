<?php

declare(strict_types=1);

namespace App\Listeners;

use App\Events\OrderCreated;
use App\Notifications\OrderCreatedNotification;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Support\Facades\Notification;

class SendOrderCreatedNotification implements ShouldQueue
{
    public function handle(OrderCreated $event): void
    {
        // Email is optional at checkout, so there is often no one to notify.
        if (blank($event->order->customer_email)) {
            return;
        }

        Notification::route('mail', $event->order->customer_email)
            ->notify(new OrderCreatedNotification($event->order));
    }
}
