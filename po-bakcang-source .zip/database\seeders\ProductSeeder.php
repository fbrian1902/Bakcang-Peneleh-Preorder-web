<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\Product;
use Illuminate\Database\Seeder;

class ProductSeeder extends Seeder
{
    /**
     * The real Bakcang Peneleh catalogue.
     *
     * Keyed by name and upserted so re-running the seeder refreshes prices
     * without creating duplicates or orphaning order_items that reference
     * these ids under an ON DELETE RESTRICT constraint.
     */
    public function run(): void
    {
        $products = [
            ['name' => 'Bakcang Babi Original', 'price' => 35000, 'is_available' => true],
            ['name' => 'Bakcang Ayam Jamur', 'price' => 32000, 'is_available' => true],
            ['name' => 'Bakcang Ayam Spesial', 'price' => 38000, 'is_available' => true],
            ['name' => 'Bakcang Udang Ebi', 'price' => 42000, 'is_available' => true],
            ['name' => 'Bakcang Vegetarian', 'price' => 28000, 'is_available' => true],
            ['name' => 'Kicang (Bakcang Manis)', 'price' => 22000, 'is_available' => true],
            ['name' => 'Bakcang Jumbo Komplit', 'price' => 55000, 'is_available' => true],
            ['name' => 'Paket Isi 5 Campur', 'price' => 160000, 'is_available' => true],
        ];

        foreach ($products as $product) {
            Product::updateOrCreate(
                ['name' => $product['name']],
                $product,
            );
        }
    }
}
