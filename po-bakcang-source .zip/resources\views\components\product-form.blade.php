@props(['product' => null])

<div class="card max-w-xl p-5">
    @csrf
    @if ($product)
        @method('PUT')
    @endif

    <div class="space-y-4">
        <div>
            <label for="name" class="label">Nama produk</label>
            <input id="name" name="name" type="text" required maxlength="100"
                   value="{{ old('name', $product?->name) }}" class="field">
            @error('name')<p class="mt-1 text-sm text-red-700">{{ $message }}</p>@enderror
        </div>

        <div>
            <label for="price" class="label">Harga (Rp)</label>
            <input id="price" name="price" type="number" required min="0" step="500"
                   value="{{ old('price', $product ? (int) $product->price : '') }}" class="field">
            @error('price')<p class="mt-1 text-sm text-red-700">{{ $message }}</p>@enderror
        </div>

        <div>
            <label for="image" class="label">
                Gambar
                <span class="font-normal text-zinc-400">
                    — maks {{ (int) (config('bakcang.images.max_kilobytes') / 1024) }} MB,
                    minimal {{ config('bakcang.images.min_width') }}×{{ config('bakcang.images.min_height') }} px
                </span>
            </label>

            {{-- Previewed in the same 4:3 frame the catalogue uses, so what is
                 shown here is what the shop will actually crop to. --}}
            @if ($product?->imageUrl())
                <div class="relative mb-2 aspect-[4/3] w-40 overflow-hidden rounded border border-zinc-200 bg-zinc-50">
                    <img src="{{ $product->imageUrl() }}" alt=""
                         class="absolute inset-0 h-full w-full object-cover object-center">
                </div>
            @endif

            <input id="image" name="image" type="file"
                   accept="{{ collect(config('bakcang.images.mimes'))->map(fn ($m) => 'image/'.$m)->implode(',') }}"
                   class="block w-full text-sm text-zinc-600
                          file:mr-3 file:rounded file:border file:border-zinc-300 file:bg-white
                          file:px-3 file:py-1.5 file:text-sm file:text-zinc-800">
            @error('image')<p class="mt-1 text-sm text-red-700">{{ $message }}</p>@enderror

            @if ($product?->image_path)
                <p class="mt-1 text-xs text-zinc-400">Biarkan kosong untuk mempertahankan gambar saat ini.</p>
            @endif
        </div>

        <label class="flex items-start gap-2.5 text-sm">
            <input type="checkbox" name="is_available" value="1"
                   @checked(old('is_available', $product?->is_available ?? true))
                   class="mt-0.5 rounded border-zinc-300 text-accent-600 focus:ring-accent-600">
            <span>
                <span class="block font-medium">Tampilkan di katalog</span>
                <span class="mt-0.5 block text-zinc-500">
                    Nonaktifkan untuk menyembunyikan produk tanpa menghapus riwayat pesanannya.
                </span>
            </span>
        </label>
    </div>

    <div class="mt-5 flex items-center gap-2 border-t border-zinc-200 pt-5">
        <button type="submit" class="btn-primary">
            {{ $product ? 'Simpan perubahan' : 'Tambah produk' }}
        </button>
        <a href="{{ route('admin.products.index') }}" class="btn-ghost">Batal</a>
    </div>
</div>
