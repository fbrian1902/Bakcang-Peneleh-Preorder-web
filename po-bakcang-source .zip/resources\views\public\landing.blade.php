@php use App\Support\Money; @endphp

<x-layouts.public>
    @section('title', config('bakcang.store.name').' — Pre-Order Bakcang')

    <div class="flex flex-wrap items-baseline justify-between gap-2">
        <h1 class="text-xl font-semibold">Menu</h1>
        <p class="text-sm text-zinc-500">
            Pesan minimal H+{{ config('bakcang.fulfillment.min_lead_days') }}
        </p>
    </div>

    @if ($products->isEmpty())
        <x-empty-state
            class="card mt-6"
            title="Menu sedang kosong"
            description="Dapur belum membuka pesanan untuk periode ini.">
            <a href="https://wa.me/{{ preg_replace('/\D/', '', config('bakcang.store.phone')) }}" class="btn-secondary">
                Hubungi via WhatsApp
            </a>
        </x-empty-state>
    @else
        <div class="mt-6 grid gap-4 sm:grid-cols-2 lg:grid-cols-3">
            @foreach ($products as $product)
                <article class="card flex flex-col overflow-hidden">
                    {{-- The frame owns the size, never the photo. `relative` +
                         an absolutely positioned image keeps the picture out of
                         the flow entirely, so a tall or wide upload cannot
                         stretch the card — it is cropped to the 4:3 frame
                         instead. `shrink-0` stops flex from squashing it. --}}
                    <div class="relative aspect-[4/3] w-full shrink-0 overflow-hidden border-b border-zinc-200 bg-zinc-50">
                        @if ($product->imageUrl())
                            <img src="{{ $product->imageUrl() }}" alt="{{ $product->name }}"
                                 loading="lazy"
                                 class="absolute inset-0 h-full w-full object-cover object-center">
                        @endif
                    </div>

                    <div class="flex flex-1 flex-col p-4">
                        <h2 class="line-clamp-2 text-sm font-medium">{{ $product->name }}</h2>
                        <p class="mt-1 text-base font-semibold">{{ Money::format($product->price) }}</p>

                        {{-- mt-auto pins the control to the bottom so buttons
                             line up across cards even when names wrap. --}}
                        <form method="POST" action="{{ route('cart.add', $product) }}" class="mt-auto flex gap-2 pt-4">
                            @csrf
                            <label class="sr-only" for="qty-{{ $product->id }}">
                                Jumlah {{ $product->name }}
                            </label>
                            <input id="qty-{{ $product->id }}" type="number" name="quantity"
                                   value="1" min="1"
                                   max="{{ config('bakcang.cart.max_quantity_per_item') }}"
                                   class="field w-16 text-center">
                            <button type="submit" class="btn-primary flex-1">Tambah</button>
                        </form>
                    </div>
                </article>
            @endforeach
        </div>
    @endif
</x-layouts.public>
