<?php

declare(strict_types=1);

namespace App\Models;

use Database\Factories\ProductFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Support\Facades\Storage;

/**
 * @property int $id
 * @property string $name
 * @property string $price
 * @property string|null $image_path
 * @property bool $is_available
 */
class Product extends Model
{
    /** @use HasFactory<ProductFactory> */
    use HasFactory;

    protected $fillable = [
        'name',
        'price',
        'image_path',
        'is_available',
    ];

    protected function casts(): array
    {
        return [
            'price' => 'decimal:2',
            'is_available' => 'boolean',
        ];
    }

    /**
     * @return HasMany<OrderItem, $this>
     */
    public function orderItems(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    /**
     * @param  Builder<$this>  $query
     */
    public function scopeAvailable(Builder $query): void
    {
        $query->where('is_available', true);
    }

    /**
     * @param  Builder<$this>  $query
     */
    public function scopeSearch(Builder $query, ?string $term): void
    {
        $query->when(
            filled($term),
            fn (Builder $q) => $q->where('name', 'like', '%'.trim((string) $term).'%'),
        );
    }

    public function imageUrl(): ?string
    {
        if (blank($this->image_path)) {
            return null;
        }

        return Storage::disk(config('bakcang.images.disk'))->url($this->image_path);
    }

    /**
     * The order_items foreign key is ON DELETE RESTRICT and products carry no
     * soft-delete column, so any product that has ever been ordered is
     * permanently undeletable. Callers check this to report the reason rather
     * than surfacing a raw integrity-constraint error.
     */
    public function isDeletable(): bool
    {
        return ! $this->orderItems()->exists();
    }
}
