<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Http\Requests\Admin\StoreProductRequest;
use App\Models\Product;
use App\Repositories\Contracts\ProductRepositoryInterface;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Storage;

class ProductController extends Controller
{
    public function __construct(
        private readonly ProductRepositoryInterface $products,
    ) {}

    public function index(Request $request): View
    {
        return view('admin.products.index', [
            'products' => $this->products->paginateForAdmin(
                $request->string('search')->toString(),
                perPage: 12,
            ),
            'search' => $request->string('search')->toString(),
        ]);
    }

    public function create(): View
    {
        return view('admin.products.create');
    }

    public function store(StoreProductRequest $request): RedirectResponse
    {
        $attributes = $request->safe()->except('image');

        if ($request->hasFile('image')) {
            $attributes['image_path'] = $this->storeImage($request);
        }

        $this->products->create($attributes);

        return redirect()
            ->route('admin.products.index')
            ->with('success', 'Produk berhasil ditambahkan.');
    }

    public function edit(Product $product): View
    {
        return view('admin.products.edit', ['product' => $product]);
    }

    public function update(StoreProductRequest $request, Product $product): RedirectResponse
    {
        $attributes = $request->safe()->except('image');

        if ($request->hasFile('image')) {
            $attributes['image_path'] = $this->storeImage($request);

            // Replaced only after the new upload succeeded, so a failed write
            // never leaves the product with no image at all.
            if (filled($product->image_path)) {
                Storage::disk(config('bakcang.images.disk'))->delete($product->image_path);
            }
        }

        $this->products->update($product, $attributes);

        return redirect()
            ->route('admin.products.index')
            ->with('success', 'Produk berhasil diperbarui.');
    }

    /**
     * order_items.product_id is ON DELETE RESTRICT and products carry no soft
     * delete, so a product that has ever been ordered is permanently
     * undeletable. The repository reports that rather than letting a raw
     * integrity error surface.
     */
    public function destroy(Product $product): RedirectResponse
    {
        if (! $this->products->delete($product)) {
            return back()->with(
                'error',
                'Produk ini sudah pernah dipesan sehingga tidak dapat dihapus. Nonaktifkan ketersediaannya saja.',
            );
        }

        return redirect()
            ->route('admin.products.index')
            ->with('success', 'Produk berhasil dihapus.');
    }

    /**
     * Stored with a generated name: a user-supplied filename could carry a
     * path traversal sequence or a double extension.
     */
    private function storeImage(StoreProductRequest $request): string
    {
        return $request->file('image')->store(
            config('bakcang.images.directory'),
            config('bakcang.images.disk'),
        );
    }
}
