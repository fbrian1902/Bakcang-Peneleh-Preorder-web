<?php

declare(strict_types=1);

return [

    /*
    |--------------------------------------------------------------------------
    | API Credentials
    |--------------------------------------------------------------------------
    |
    | Obtained from the Midtrans dashboard under Settings > Access Keys. The
    | server key doubles as the webhook signature secret and must never be
    | exposed to the browser; only the client key is safe in Blade or JS.
    |
    */

    'merchant_id' => env('MIDTRANS_MERCHANT_ID'),
    'client_key' => env('MIDTRANS_CLIENT_KEY'),
    'server_key' => env('MIDTRANS_SERVER_KEY'),

    /*
    |--------------------------------------------------------------------------
    | Environment
    |--------------------------------------------------------------------------
    */

    'is_production' => (bool) env('MIDTRANS_IS_PRODUCTION', false),
    'is_sanitized' => (bool) env('MIDTRANS_IS_SANITIZED', true),
    'is_3ds' => (bool) env('MIDTRANS_IS_3DS', true),

    /*
    |--------------------------------------------------------------------------
    | Snap.js Asset URL
    |--------------------------------------------------------------------------
    |
    | Resolved from the environment flag so the Blade layout never has to
    | branch on sandbox versus production itself.
    |
    */

    'snap_url' => env('MIDTRANS_IS_PRODUCTION', false)
        ? 'https://app.midtrans.com/snap/snap.js'
        : 'https://app.sandbox.midtrans.com/snap/snap.js',

    /*
    |--------------------------------------------------------------------------
    | Transaction Expiry
    |--------------------------------------------------------------------------
    |
    | How long a Snap payment page stays payable. Keep this at or below the
    | pre-order lead time so an unpaid order expires before the kitchen would
    | otherwise have had to start preparing it.
    |
    */

    'expiry' => [
        'unit' => env('MIDTRANS_EXPIRY_UNIT', 'hours'),
        'duration' => (int) env('MIDTRANS_EXPIRY_DURATION', 24),
    ],

    /*
    |--------------------------------------------------------------------------
    | Enabled Payment Channels
    |--------------------------------------------------------------------------
    |
    | Passed to Snap as `enabled_payments`. Leave empty to show every channel
    | activated on the merchant account.
    |
    */

    'enabled_payments' => [
        'qris',
        'gopay',
        'shopeepay',
        'bank_transfer',
        'echannel',
        'permata_va',
        'bca_va',
        'bni_va',
        'bri_va',
        'other_va',
        'credit_card',
    ],

    /*
    |--------------------------------------------------------------------------
    | Webhook
    |--------------------------------------------------------------------------
    |
    | The notification URL itself is registered in the Midtrans dashboard, not
    | sent in the payload, so nothing here configures where Midtrans posts. To
    | expose a local machine, point APP_URL at the tunnel — that is what
    | route() uses to build the Snap finish callback and the invoice QR code.
    |
    | `verify_status_with_api` re-queries the Midtrans status endpoint before
    | acting on a notification. The signature proves the payload was not
    | forged; re-querying proves it still reflects reality. Keep this on in
    | production — it is the difference between trusting a message and
    | trusting the source of truth.
    |
    */

    'webhook' => [
        'path' => 'webhook/midtrans',
        'verify_status_with_api' => (bool) env('MIDTRANS_VERIFY_STATUS_WITH_API', true),
    ],

    /*
    |--------------------------------------------------------------------------
    | HTTP
    |--------------------------------------------------------------------------
    */

    'timeout' => (int) env('MIDTRANS_TIMEOUT', 30),

];
