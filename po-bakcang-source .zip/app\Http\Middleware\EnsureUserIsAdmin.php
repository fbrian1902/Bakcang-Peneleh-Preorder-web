<?php

declare(strict_types=1);

namespace App\Http\Middleware;

use Closure;
use Illuminate\Http\Request;
use Symfony\Component\HttpFoundation\Response;

class EnsureUserIsAdmin
{
    /**
     * @param  Closure(Request): Response  $next
     */
    public function handle(Request $request, Closure $next): Response
    {
        // 404 rather than 403: a signed-in non-admin should not learn that the
        // admin panel exists at this path.
        abort_unless($request->user()?->isAdmin() === true, 404);

        return $next($request);
    }
}
