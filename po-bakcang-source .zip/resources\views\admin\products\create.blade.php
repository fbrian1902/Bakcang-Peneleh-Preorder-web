<x-layouts.admin title="Tambah produk">
    <form method="POST" action="{{ route('admin.products.store') }}" enctype="multipart/form-data">
        <x-product-form />
    </form>
</x-layouts.admin>
