<?php

declare(strict_types=1);

namespace App\Http\Requests;

use App\Enums\FulfillmentType;
use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;
use Illuminate\Validation\Rules\Enum;

class StoreOrderRequest extends FormRequest
{
    public function authorize(): bool
    {
        return true;
    }

    /**
     * No monetary field is accepted. Subtotal, delivery fee and total are
     * derived server-side from the cart, so there is nothing here for a
     * tampered payload to influence.
     *
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        $minDate = now()->addDays((int) config('bakcang.fulfillment.min_lead_days'))->toDateString();
        $maxDate = now()->addDays((int) config('bakcang.fulfillment.max_lead_days'))->toDateString();

        return [
            'customer_name' => ['required', 'string', 'max:100'],

            // Indonesian mobile numbers, accepting 08…, 628… and +628… forms.
            'customer_phone' => ['required', 'string', 'max:20', 'regex:/^(\+?62|0)8[1-9][0-9]{6,11}$/'],

            'customer_email' => ['nullable', 'email:rfc,dns', 'max:150'],
            'fulfillment_type' => ['required', new Enum(FulfillmentType::class)],

            // The schema leaves address nullable because it cannot express a
            // conditional; the rule supplies what the column cannot.
            'address' => [
                Rule::requiredIf(fn (): bool => $this->input('fulfillment_type') === FulfillmentType::Delivery->value),
                'nullable',
                'string',
                'max:255',
            ],

            'fulfillment_date' => ['required', 'date', "after_or_equal:{$minDate}", "before_or_equal:{$maxDate}"],
            'fulfillment_time' => [
                'required',
                'date_format:H:i',
                'after_or_equal:'.config('bakcang.fulfillment.pickup_open'),
                'before_or_equal:'.config('bakcang.fulfillment.pickup_close'),
            ],

            'notes' => ['nullable', 'string', 'max:500'],
        ];
    }

    /**
     * @return array<string, string>
     */
    public function messages(): array
    {
        return [
            'customer_phone.regex' => 'Nomor WhatsApp tidak valid. Contoh: 081234567890.',
            'address.required' => 'Alamat wajib diisi untuk pengiriman.',
            'fulfillment_date.after_or_equal' => 'Tanggal pesanan minimal H+'
                .config('bakcang.fulfillment.min_lead_days').' dari hari ini.',
            'fulfillment_date.before_or_equal' => 'Tanggal pesanan terlalu jauh ke depan.',
            'fulfillment_time.after_or_equal' => 'Jam layanan mulai pukul '
                .config('bakcang.fulfillment.pickup_open').'.',
            'fulfillment_time.before_or_equal' => 'Jam layanan berakhir pukul '
                .config('bakcang.fulfillment.pickup_close').'.',
        ];
    }

    /**
     * @return array<string, string>
     */
    public function attributes(): array
    {
        return [
            'customer_name' => 'nama',
            'customer_phone' => 'nomor WhatsApp',
            'customer_email' => 'email',
            'fulfillment_type' => 'metode pengambilan',
            'address' => 'alamat',
            'fulfillment_date' => 'tanggal',
            'fulfillment_time' => 'jam',
            'notes' => 'catatan',
        ];
    }
}
