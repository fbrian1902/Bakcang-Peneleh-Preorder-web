@php use App\Support\Money; @endphp

<x-layouts.admin title="Produk">
    <x-slot:actions>
        <a href="{{ route('admin.products.create') }}" class="btn-primary">Tambah produk</a>
    </x-slot:actions>

    <form method="GET" class="flex flex-wrap items-end gap-2">
        <div class="min-w-48 flex-1">
            <label for="search" class="label">Cari produk</label>
            <input id="search" name="search" type="search" value="{{ $search }}"
                   placeholder="Nama produk" class="field">
        </div>
        <button type="submit" class="btn-secondary">Cari</button>
        @if ($search)
            <a href="{{ route('admin.products.index') }}" class="btn-ghost">Atur ulang</a>
        @endif
    </form>

    @if ($products->isEmpty())
        <x-empty-state class="card mt-6"
            title="{{ $search ? 'Produk tidak ditemukan' : 'Belum ada produk' }}"
            description="{{ $search
                ? 'Tidak ada produk yang cocok dengan pencarian ini.'
                : 'Tambahkan produk pertama agar pelanggan bisa memesan.' }}">
            <a href="{{ route('admin.products.create') }}" class="btn-primary">Tambah produk</a>
        </x-empty-state>
    @else
        <div class="card mt-6 overflow-hidden">
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="border-b border-zinc-200 bg-zinc-50 text-left text-xs text-zinc-500">
                        <tr>
                            <th scope="col" class="px-4 py-2 font-medium">Produk</th>
                            <th scope="col" class="px-4 py-2 text-right font-medium">Harga</th>
                            <th scope="col" class="px-4 py-2 font-medium">Status</th>
                            <th scope="col" class="px-4 py-2"><span class="sr-only">Aksi</span></th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-zinc-200">
                        @foreach ($products as $product)
                            <tr>
                                <td class="px-4 py-2.5">
                                    <div class="flex items-center gap-3">
                                        <div class="relative h-10 w-10 shrink-0 overflow-hidden rounded border border-zinc-200 bg-zinc-50">
                                            @if ($product->imageUrl())
                                                <img src="{{ $product->imageUrl() }}" alt=""
                                                     class="absolute inset-0 h-full w-full object-cover object-center">
                                            @endif
                                        </div>
                                        <span>{{ $product->name }}</span>
                                    </div>
                                </td>
                                <td class="px-4 py-2.5 text-right tabular-nums">
                                    {{ Money::format($product->price) }}
                                </td>
                                <td class="px-4 py-2.5">
                                    <span class="badge {{ $product->is_available
                                        ? 'border-accent-100 bg-accent-50 text-accent-800'
                                        : 'border-zinc-200 bg-zinc-50 text-zinc-600' }}">
                                        {{ $product->is_available ? 'Tampil' : 'Nonaktif' }}
                                    </span>
                                </td>
                                <td class="px-4 py-2.5 text-right">
                                    <div class="flex items-center justify-end gap-3">
                                        <a href="{{ route('admin.products.edit', $product) }}"
                                           class="text-accent-700 hover:underline">Ubah</a>

                                        {{-- order_items.product_id is ON DELETE RESTRICT,
                                             so an ordered product cannot be removed. --}}
                                        @if ($product->isDeletable())
                                            <form method="POST" action="{{ route('admin.products.destroy', $product) }}"
                                                  onsubmit="return confirm('Hapus {{ $product->name }}?')">
                                                @csrf
                                                @method('DELETE')
                                                <button type="submit" class="text-red-700 hover:underline">Hapus</button>
                                            </form>
                                        @else
                                            <span class="text-zinc-400" title="Sudah pernah dipesan">Terkunci</span>
                                        @endif
                                    </div>
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        <div class="mt-6">{{ $products->links() }}</div>
    @endif
</x-layouts.admin>
