<?php

declare(strict_types=1);

namespace App\Models;

use App\Enums\FulfillmentType;
use App\Enums\OrderStatus;
use App\Enums\TransactionStatus;
use Database\Factories\OrderFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsToMany;
use Illuminate\Database\Eloquent\Relations\HasMany;
use Illuminate\Database\Eloquent\Relations\HasOne;
use Illuminate\Support\Carbon;

/**
 * @property int $id
 * @property string $order_number
 * @property string $customer_name
 * @property string $customer_phone
 * @property string|null $customer_email
 * @property FulfillmentType $fulfillment_type
 * @property string|null $address
 * @property Carbon|null $fulfillment_date
 * @property string|null $fulfillment_time
 * @property OrderStatus $status
 * @property string $subtotal
 * @property string $delivery_fee
 * @property string $total
 * @property string|null $notes
 */
class Order extends Model
{
    /** @use HasFactory<OrderFactory> */
    use HasFactory;

    protected $fillable = [
        'order_number',
        'customer_name',
        'customer_phone',
        'customer_email',
        'fulfillment_type',
        'address',
        'fulfillment_date',
        'fulfillment_time',
        'status',
        'subtotal',
        'delivery_fee',
        'total',
        'notes',
    ];

    protected function casts(): array
    {
        return [
            'fulfillment_type' => FulfillmentType::class,
            'status' => OrderStatus::class,
            'fulfillment_date' => 'date',
            'subtotal' => 'decimal:2',
            'delivery_fee' => 'decimal:2',
            'total' => 'decimal:2',
        ];
    }

    /**
     * Public order tracking is keyed by order_number, never by the
     * auto-increment id — sequential ids would let anyone enumerate other
     * customers' orders.
     */
    public function getRouteKeyName(): string
    {
        return 'order_number';
    }

    /**
     * @return HasMany<OrderItem, $this>
     */
    public function items(): HasMany
    {
        return $this->hasMany(OrderItem::class);
    }

    /**
     * @return HasMany<Payment, $this>
     */
    public function payments(): HasMany
    {
        return $this->hasMany(Payment::class);
    }

    /**
     * The attempt whose state the customer is currently looking at.
     *
     * @return HasOne<Payment, $this>
     */
    public function latestPayment(): HasOne
    {
        return $this->hasOne(Payment::class)->latestOfMany();
    }

    /**
     * The attempt that actually collected money, if any.
     *
     * Paid-ness is not a column on orders — it is the existence of a payment
     * in `settlement` or `capture`. `status = confirmed` is the business
     * mirror of this fact, written by the webhook.
     *
     * @return HasOne<Payment, $this>
     */
    public function successfulPayment(): HasOne
    {
        return $this->hasOne(Payment::class)
            ->whereIn('transaction_status', [
                TransactionStatus::Settlement->value,
                TransactionStatus::Capture->value,
            ])
            ->latestOfMany();
    }

    /**
     * @return BelongsToMany<Product, $this>
     */
    public function products(): BelongsToMany
    {
        return $this->belongsToMany(Product::class, 'order_items')
            ->withPivot(['product_name', 'unit_price', 'quantity', 'line_total']);
    }

    /**
     * @param  Builder<$this>  $query
     */
    public function scopeStatus(Builder $query, OrderStatus|string|null $status): void
    {
        $query->when(
            filled($status),
            fn (Builder $q) => $q->where(
                'status',
                $status instanceof OrderStatus ? $status->value : $status,
            ),
        );
    }

    /**
     * @param  Builder<$this>  $query
     */
    public function scopeSearch(Builder $query, ?string $term): void
    {
        $query->when(filled($term), function (Builder $q) use ($term): void {
            $like = '%'.trim((string) $term).'%';

            $q->where(function (Builder $inner) use ($like): void {
                $inner->where('order_number', 'like', $like)
                    ->orWhere('customer_name', 'like', $like)
                    ->orWhere('customer_phone', 'like', $like)
                    ->orWhere('customer_email', 'like', $like);
            });
        });
    }

    /**
     * @param  Builder<$this>  $query
     */
    public function scopeCreatedBetween(Builder $query, ?string $from, ?string $to): void
    {
        $query->when(filled($from), fn (Builder $q) => $q->whereDate('created_at', '>=', $from))
            ->when(filled($to), fn (Builder $q) => $q->whereDate('created_at', '<=', $to));
    }

    public function isPaid(): bool
    {
        return $this->successfulPayment()->exists();
    }

    public function isAwaitingPayment(): bool
    {
        return $this->status === OrderStatus::AwaitingPayment;
    }

    /**
     * A customer may retry payment only while the order is unpaid and has not
     * been cancelled.
     */
    public function isPayable(): bool
    {
        return $this->status === OrderStatus::AwaitingPayment && ! $this->isPaid();
    }

    public function itemCount(): int
    {
        return (int) $this->items->sum('quantity');
    }
}
