<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * Mirrors the `payments.transaction_status` ENUM.
 *
 * `authorize` and `partial_refund` were added to the original schema because
 * Midtrans genuinely emits them — `authorize` for a credit card charged with
 * `capture: false`, `partial_refund` when only part of an order is refunded.
 * Under MySQL strict mode an out-of-range ENUM write raises error 1265 rather
 * than truncating, which would 500 the webhook and leave Midtrans retrying
 * the same notification indefinitely while the order sat unpaid.
 */
enum TransactionStatus: string
{
    case Pending = 'pending';
    case Settlement = 'settlement';
    case Capture = 'capture';
    case Authorize = 'authorize';
    case Deny = 'deny';
    case Cancel = 'cancel';
    case Expire = 'expire';
    case Refund = 'refund';
    case PartialRefund = 'partial_refund';
    case Failure = 'failure';

    public function label(): string
    {
        return match ($this) {
            self::Pending => 'Menunggu',
            self::Settlement => 'Lunas',
            self::Capture => 'Berhasil',
            self::Authorize => 'Terotorisasi',
            self::Deny => 'Ditolak',
            self::Cancel => 'Dibatalkan',
            self::Expire => 'Kedaluwarsa',
            self::Refund => 'Dikembalikan',
            self::PartialRefund => 'Dikembalikan Sebagian',
            self::Failure => 'Gagal',
        };
    }

    public function badgeClasses(): string
    {
        return match ($this) {
            self::Settlement, self::Capture => 'border-accent-100 bg-accent-50 text-accent-800',
            self::Pending, self::Authorize => 'border-amber-200 bg-amber-50 text-amber-800',
            self::Deny, self::Cancel, self::Expire, self::Failure => 'border-red-200 bg-red-50 text-red-800',
            self::Refund, self::PartialRefund => 'border-zinc-200 bg-zinc-50 text-zinc-700',
        };
    }

    /**
     * Ranks how far a transaction has progressed.
     *
     * Midtrans does not guarantee notification ordering and retries on any
     * non-2xx response, so a `pending` can legitimately arrive *after* the
     * `settlement` for the same transaction. Comparing precedence lets the
     * webhook ignore stale notifications instead of regressing a paid order
     * back to unpaid. Refunds outrank settlement because they are the later
     * real-world event.
     */
    public function precedence(): int
    {
        return match ($this) {
            self::Pending => 10,
            self::Authorize => 20,
            self::Deny, self::Cancel, self::Expire, self::Failure => 30,
            self::Capture => 40,
            self::Settlement => 50,
            self::PartialRefund => 60,
            self::Refund => 70,
        };
    }

    /**
     * Whether a notification carrying this status should overwrite one that
     * is already stored.
     */
    public function supersedes(?self $current): bool
    {
        return $current === null || $this->precedence() > $current->precedence();
    }

    /**
     * Money has actually been received.
     *
     * `capture` only counts when the accompanying fraud status is `accept`,
     * which is why PaymentNotificationService checks both — a captured but
     * challenged card is not yet revenue.
     */
    public function isPaid(): bool
    {
        return in_array($this, [self::Settlement, self::Capture], strict: true);
    }

    /**
     * No further customer action is possible on this attempt.
     */
    public function isFailed(): bool
    {
        return in_array(
            $this,
            [self::Deny, self::Cancel, self::Expire, self::Failure],
            strict: true,
        );
    }

    public function isPending(): bool
    {
        return in_array($this, [self::Pending, self::Authorize], strict: true);
    }

    public function isRefunded(): bool
    {
        return in_array($this, [self::Refund, self::PartialRefund], strict: true);
    }

    /**
     * @return array<string, string>
     */
    public static function options(): array
    {
        return array_reduce(
            self::cases(),
            static fn (array $carry, self $case): array => $carry + [$case->value => $case->label()],
            [],
        );
    }
}
