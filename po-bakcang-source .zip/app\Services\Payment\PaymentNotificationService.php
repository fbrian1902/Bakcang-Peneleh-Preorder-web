<?php

declare(strict_types=1);

namespace App\Services\Payment;

use App\DataTransferObjects\MidtransNotificationData;
use App\Events\PaymentSettled;
use App\Exceptions\PaymentException;
use App\Models\Payment;
use App\Repositories\Contracts\PaymentRepositoryInterface;
use App\Services\Order\OrderStatusService;
use App\Support\Money;
use Illuminate\Support\Facades\DB;
use Illuminate\Support\Facades\Log;

/**
 * Applies Midtrans payment state to a payment and its order.
 *
 * Two entry points, differing only in how authenticity is established:
 *
 *   handle()          — a pushed webhook. Anyone can POST to the endpoint, so
 *                       the payload must prove it came from Midtrans via its
 *                       signature before anything is trusted.
 *
 *   syncFromGateway() — a pull we initiated over an authenticated TLS call to
 *                       Midtrans. Authenticity comes from the channel, so
 *                       there is no signature to check.
 *
 * Beyond that both share the same protections: a row lock to serialise
 * concurrent deliveries, an amount check, and a precedence comparison that
 * refuses to move a payment backwards — Midtrans guarantees no ordering, so a
 * `pending` can legitimately arrive after the `settlement` it precedes.
 */
class PaymentNotificationService
{
    public function __construct(
        private readonly PaymentRepositoryInterface $payments,
        private readonly MidtransService $midtrans,
        private readonly OrderStatusService $orderStatus,
    ) {}

    /**
     * Handles a pushed webhook notification.
     *
     * @param  array<string, mixed>  $payload
     */
    public function handle(array $payload): Payment
    {
        $notification = MidtransNotificationData::fromArray($payload);

        $this->assertSignature($notification);

        return $this->apply($this->reconcileWithGateway($notification));
    }

    /**
     * Pulls current state from Midtrans and applies it.
     *
     * Used to reconcile without a public webhook URL — local development
     * behind no tunnel, or after downtime once Midtrans has given up retrying.
     */
    public function syncFromGateway(string $midtransOrderId): Payment
    {
        $status = $this->midtrans->getStatus($midtransOrderId);

        if ($status === null || blank($status['transaction_status'] ?? null)) {
            throw PaymentException::gatewayFailure(
                "Tidak dapat mengambil status untuk {$midtransOrderId}.",
            );
        }

        return $this->apply(MidtransNotificationData::fromArray($status));
    }

    /**
     * The shared write path. Callers must have already established that the
     * data genuinely came from Midtrans.
     */
    private function apply(MidtransNotificationData $notification): Payment
    {
        return DB::transaction(function () use ($notification): Payment {
            $payment = $this->payments->lockByMidtransOrderId($notification->orderId);

            if ($payment === null) {
                throw PaymentException::unknownOrder($notification->orderId);
            }

            $this->assertAmountMatches($payment, $notification);

            if (! $notification->transactionStatus->supersedes($payment->transaction_status)) {
                // Stale or duplicate. The payload is still recorded for audit,
                // but no state moves — this is what stops a late `pending`
                // from un-paying an order that has already settled.
                Log::info('Ignoring superseded Midtrans notification', [
                    'midtrans_order_id' => $notification->orderId,
                    'incoming' => $notification->transactionStatus->value,
                    'current' => $payment->transaction_status->value,
                ]);

                $payment->update(['raw_notification' => $notification->raw]);

                return $payment;
            }

            $wasSuccessful = $payment->isSuccessful();

            $payment->update([
                'transaction_id' => $notification->transactionId ?? $payment->transaction_id,
                'payment_type' => $notification->paymentType ?? $payment->payment_type,
                'transaction_status' => $notification->transactionStatus,
                'fraud_status' => $notification->fraudStatus,
                'transaction_time' => $notification->transactionTime ?? $payment->transaction_time,
                'settlement_time' => $notification->settlementTime ?? $payment->settlement_time,
                'expiry_time' => $notification->expiryTime ?? $payment->expiry_time,
                'raw_notification' => $notification->raw,
            ]);

            $this->syncOrder($payment->refresh(), $wasSuccessful);

            return $payment;
        });
    }

    private function assertSignature(MidtransNotificationData $notification): void
    {
        $valid = $this->midtrans->verifySignature(
            $notification->orderId,
            $notification->statusCode,
            $notification->grossAmount,
            $notification->signatureKey,
        );

        if (! $valid) {
            Log::warning('Rejected Midtrans notification with invalid signature', [
                'midtrans_order_id' => $notification->orderId,
            ]);

            throw PaymentException::invalidSignature($notification->orderId);
        }
    }

    /**
     * Replaces a verified payload with a fresh reading from the status API.
     *
     * A valid signature proves the message was authentic when minted — not
     * that it is still current. Re-querying closes the replay gap. A failed
     * lookup falls back to the original payload rather than rejecting the
     * delivery, since a rejection would simply be retried forever.
     */
    private function reconcileWithGateway(MidtransNotificationData $notification): MidtransNotificationData
    {
        if (! config('midtrans.webhook.verify_status_with_api')) {
            return $notification;
        }

        $fresh = $this->midtrans->getStatus($notification->orderId);

        if ($fresh === null || blank($fresh['transaction_status'] ?? null)) {
            return $notification;
        }

        return MidtransNotificationData::fromArray($fresh);
    }

    /**
     * The stored gross_amount must equal what Midtrans reports, or this
     * notification belongs to a transaction the order did not create.
     */
    private function assertAmountMatches(Payment $payment, MidtransNotificationData $notification): void
    {
        $expected = Money::toInt($payment->gross_amount);
        $received = Money::toInt($notification->grossAmount);

        if ($expected !== $received) {
            throw PaymentException::amountMismatch((string) $expected, (string) $received);
        }
    }

    /**
     * Propagates the payment outcome to the order.
     *
     * `$wasSuccessful` prevents re-firing PaymentSettled when Midtrans
     * redelivers a settlement already processed — the listener emails a
     * receipt, and duplicates would be visible to the customer.
     */
    private function syncOrder(Payment $payment, bool $wasSuccessful): void
    {
        $order = $payment->order;

        if ($order === null) {
            return;
        }

        if ($payment->isSuccessful()) {
            $this->orderStatus->markConfirmed($order);

            if (! $wasSuccessful) {
                PaymentSettled::dispatch($order->refresh(), $payment);
            }

            return;
        }

        if ($payment->transaction_status->isFailed()) {
            $this->orderStatus->markCancelledIfUnpaid($order);
        }
    }
}
