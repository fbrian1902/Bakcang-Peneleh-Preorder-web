@php
    use App\Enums\OrderStatus;
    use App\Support\Money;
@endphp

<x-layouts.admin title="Pesanan">
    <form method="GET" class="grid gap-3 sm:grid-cols-2 lg:grid-cols-5">
        <div class="lg:col-span-2">
            <label for="search" class="label">Cari</label>
            <input id="search" name="search" type="search" value="{{ $filters['search'] }}"
                   placeholder="Nomor, nama, telepon, email" class="field">
        </div>

        <div>
            <label for="status" class="label">Status</label>
            <select id="status" name="status" class="field">
                <option value="">Semua</option>
                @foreach (OrderStatus::options() as $value => $label)
                    <option value="{{ $value }}" @selected($filters['status'] === $value)>{{ $label }}</option>
                @endforeach
            </select>
        </div>

        <div>
            <label for="from" class="label">Dari</label>
            <input id="from" name="from" type="date" value="{{ $filters['from'] }}" class="field">
        </div>

        <div>
            <label for="to" class="label">Sampai</label>
            <input id="to" name="to" type="date" value="{{ $filters['to'] }}" class="field">
        </div>

        <div class="flex items-end gap-2 sm:col-span-2 lg:col-span-5">
            <button type="submit" class="btn-secondary">Terapkan</button>
            <a href="{{ route('admin.orders.index') }}" class="btn-ghost">Atur ulang</a>
        </div>
    </form>

    @if ($orders->isEmpty())
        <x-empty-state class="card mt-6"
            title="Tidak ada pesanan"
            description="Belum ada pesanan yang cocok dengan filter ini.">
            <a href="{{ route('admin.orders.index') }}" class="btn-secondary">Hapus filter</a>
        </x-empty-state>
    @else
        {{-- Table on wide screens, list on narrow — a horizontally scrolling
             table is unusable on the phone staff actually read this on. --}}
        <div class="card mt-6 hidden overflow-hidden md:block">
            <div class="overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="border-b border-zinc-200 bg-zinc-50 text-left text-xs text-zinc-500">
                        <tr>
                            <th scope="col" class="px-4 py-2 font-medium">Pesanan</th>
                            <th scope="col" class="px-4 py-2 font-medium">Pelanggan</th>
                            <th scope="col" class="px-4 py-2 font-medium">Jadwal</th>
                            <th scope="col" class="px-4 py-2 text-right font-medium">Total</th>
                            <th scope="col" class="px-4 py-2 font-medium">Status</th>
                            <th scope="col" class="px-4 py-2 font-medium">Bayar</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-zinc-200">
                        @foreach ($orders as $order)
                            <tr class="hover:bg-zinc-50">
                                <td class="px-4 py-2.5">
                                    <a href="{{ route('admin.orders.show', $order) }}"
                                       class="text-accent-700 hover:underline">{{ $order->order_number }}</a>
                                    <p class="mt-0.5 text-xs text-zinc-500">
                                        {{ $order->created_at?->format('d M, H:i') }} · {{ $order->items_count }} item
                                    </p>
                                </td>
                                <td class="px-4 py-2.5">
                                    {{ $order->customer_name }}
                                    <p class="mt-0.5 text-xs text-zinc-500">{{ $order->customer_phone }}</p>
                                </td>
                                <td class="px-4 py-2.5">
                                    {{ $order->fulfillment_date?->format('d M Y') }}
                                    <p class="mt-0.5 text-xs text-zinc-500">{{ $order->fulfillment_type->label() }}</p>
                                </td>
                                <td class="px-4 py-2.5 text-right tabular-nums">{{ Money::format($order->total) }}</td>
                                <td class="px-4 py-2.5">
                                    <span class="badge {{ $order->status->badgeClasses() }}">
                                        {{ $order->status->label() }}
                                    </span>
                                </td>
                                <td class="px-4 py-2.5">
                                    @if ($order->latestPayment)
                                        <span class="badge {{ $order->latestPayment->transaction_status->badgeClasses() }}">
                                            {{ $order->latestPayment->transaction_status->label() }}
                                        </span>
                                    @else
                                        <span class="text-xs text-zinc-400">—</span>
                                    @endif
                                </td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        </div>

        <ul class="mt-6 space-y-2 md:hidden">
            @foreach ($orders as $order)
                <li class="card p-4">
                    <a href="{{ route('admin.orders.show', $order) }}" class="block text-sm">
                        <div class="flex items-start justify-between gap-3">
                            <div class="min-w-0">
                                <p class="text-accent-700">{{ $order->order_number }}</p>
                                <p class="mt-0.5 truncate">{{ $order->customer_name }}</p>
                            </div>
                            <p class="shrink-0 tabular-nums">{{ Money::format($order->total) }}</p>
                        </div>
                        <div class="mt-2 flex flex-wrap items-center gap-2">
                            <span class="badge {{ $order->status->badgeClasses() }}">{{ $order->status->label() }}</span>
                            <span class="text-xs text-zinc-500">
                                {{ $order->fulfillment_date?->format('d M') }} · {{ $order->fulfillment_type->label() }}
                            </span>
                        </div>
                    </a>
                </li>
            @endforeach
        </ul>

        <div class="mt-6">{{ $orders->links() }}</div>
    @endif
</x-layouts.admin>
