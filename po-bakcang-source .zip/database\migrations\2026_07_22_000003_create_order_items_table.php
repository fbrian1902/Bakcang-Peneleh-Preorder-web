<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('order_items', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('order_id');
            $table->foreignId('product_id');

            // Snapshots. A later price edit or rename must never rewrite what
            // the customer actually agreed to pay.
            $table->string('product_name', 100);
            $table->decimal('unit_price', 10, 2);

            $table->unsignedInteger('quantity');
            $table->decimal('line_total', 12, 2);

            // Intentionally no timestamps() — the source schema defines none.
            // OrderItem sets $timestamps = false to match.

            // One line per product per order. CartService merges repeat
            // additions rather than appending, which this enforces.
            $table->unique(['order_id', 'product_id'], 'uq_orderitem');
            $table->index('product_id', 'ix_orderitem_product');

            $table->foreign('order_id', 'fk_orderitem_order')
                ->references('id')->on('orders')
                ->cascadeOnDelete();

            // RESTRICT: a product that has ever been ordered can never be
            // hard-deleted. ProductRepository checks this before attempting
            // a delete so the UI reports it instead of hitting error 1451.
            $table->foreign('product_id', 'fk_orderitem_product')
                ->references('id')->on('products')
                ->restrictOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('order_items');
    }
};
