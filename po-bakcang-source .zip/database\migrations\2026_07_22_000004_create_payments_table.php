<?php

declare(strict_types=1);

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

return new class extends Migration
{
    public function up(): void
    {
        Schema::create('payments', function (Blueprint $table): void {
            $table->id();
            $table->foreignId('order_id');

            // Midtrans rejects reuse of an order_id, so each retry gets its
            // own: {order_number}-{attempt}, e.g. BP-20260722-0001-2.
            $table->string('midtrans_order_id', 50);

            $table->string('snap_token', 100)->nullable();
            $table->string('redirect_url', 255)->nullable();
            $table->string('transaction_id', 100)->nullable();
            $table->string('payment_type', 50)->nullable();

            // Must equal orders.total. MidtransService asserts this before
            // creating the Snap transaction.
            $table->decimal('gross_amount', 12, 2);

            // `authorize` and `partial_refund` extend the original schema —
            // Midtrans emits both, and MySQL strict mode raises error 1265
            // rather than truncating an unknown ENUM value, which would 500
            // the webhook into an endless Midtrans retry loop.
            $table->enum('transaction_status', [
                'pending',
                'settlement',
                'capture',
                'authorize',
                'deny',
                'cancel',
                'expire',
                'refund',
                'partial_refund',
                'failure',
            ])->default('pending');

            $table->enum('fraud_status', ['accept', 'challenge', 'deny'])->nullable();

            $table->timestamp('transaction_time')->nullable();
            $table->timestamp('settlement_time')->nullable();
            $table->timestamp('expiry_time')->nullable();

            $table->json('raw_notification')->nullable();
            $table->timestamps();

            $table->unique('midtrans_order_id', 'uq_pay_midtrans_order');

            // Nullable + unique is deliberate: MySQL permits unlimited NULLs
            // in a unique index, so many not-yet-paid attempts coexist while
            // real transaction IDs stay unique.
            $table->unique('transaction_id', 'uq_pay_txn');

            $table->index('order_id', 'ix_pay_order');
            $table->index('transaction_status', 'ix_pay_status');

            // Revenue reporting aggregates on settlement_time, not on
            // orders.created_at, so that unpaid orders never count as income.
            $table->index('settlement_time', 'ix_pay_settlement');

            $table->foreign('order_id', 'fk_pay_order')
                ->references('id')->on('orders')
                ->cascadeOnDelete();
        });
    }

    public function down(): void
    {
        Schema::dropIfExists('payments');
    }
};
