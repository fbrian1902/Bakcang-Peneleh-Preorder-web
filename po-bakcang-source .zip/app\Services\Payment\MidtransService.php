<?php

declare(strict_types=1);

namespace App\Services\Payment;

use App\Enums\TransactionStatus;
use App\Exceptions\CheckoutException;
use App\Exceptions\PaymentException;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Payment;
use App\Repositories\Contracts\PaymentRepositoryInterface;
use App\Support\Money;
use Exception;
use Illuminate\Support\Carbon;
use Illuminate\Support\Facades\Log;
use Midtrans\Config as MidtransConfig;
use Midtrans\Snap;
use Midtrans\Transaction;

class MidtransService
{
    public function __construct(
        private readonly PaymentRepositoryInterface $payments,
    ) {}

    /**
     * Creates a fresh Snap transaction for an order and records the attempt.
     *
     * Reuses the existing attempt when its Snap token is still valid, so a
     * customer refreshing the payment page does not accumulate dead rows.
     */
    public function createTransaction(Order $order): Payment
    {
        if (! $order->isPayable()) {
            throw CheckoutException::notPayable($order->order_number);
        }

        $existing = $order->latestPayment;

        if ($existing?->hasUsableSnapToken()) {
            return $existing;
        }

        $payment = $this->payments->create([
            'order_id' => $order->id,
            'midtrans_order_id' => $this->nextMidtransOrderId($order),
            'gross_amount' => $order->total,
            'transaction_status' => TransactionStatus::Pending,
            'expiry_time' => $this->expiresAt(),
        ]);

        $snap = $this->createSnapToken($order, $payment);

        $payment->update([
            'snap_token' => $snap['token'],
            'redirect_url' => $snap['redirect_url'],
        ]);

        return $payment->refresh();
    }

    /**
     * Requests a Snap token from Midtrans.
     *
     * @return array{token: string, redirect_url: string|null}
     */
    public function createSnapToken(Order $order, Payment $payment): array
    {
        $this->configure();

        try {
            $response = Snap::createTransaction($this->buildPayload($order, $payment));
        } catch (Exception $exception) {
            Log::error('Midtrans Snap transaction failed', [
                'order_number' => $order->order_number,
                'midtrans_order_id' => $payment->midtrans_order_id,
                'message' => $exception->getMessage(),
            ]);

            throw PaymentException::gatewayFailure($exception->getMessage());
        }

        return [
            'token' => $response->token,
            'redirect_url' => $response->redirect_url ?? null,
        ];
    }

    /**
     * Queries the authoritative status of a transaction.
     *
     * The webhook calls this before acting so it trusts the gateway rather
     * than the message body, which protects against a replayed notification
     * whose signature is genuine but whose content is stale.
     *
     * @return array<string, mixed>|null
     */
    public function getStatus(string $midtransOrderId): ?array
    {
        $this->configure();

        try {
            return (array) json_decode(
                json_encode(Transaction::status($midtransOrderId)) ?: '{}',
                associative: true,
            );
        } catch (Exception $exception) {
            Log::warning('Midtrans status lookup failed', [
                'midtrans_order_id' => $midtransOrderId,
                'message' => $exception->getMessage(),
            ]);

            return null;
        }
    }

    public function cancel(string $midtransOrderId): bool
    {
        return $this->call(
            fn () => Transaction::cancel($midtransOrderId),
            'cancel',
            $midtransOrderId,
        );
    }

    public function expire(string $midtransOrderId): bool
    {
        return $this->call(
            fn () => Transaction::expire($midtransOrderId),
            'expire',
            $midtransOrderId,
        );
    }

    /**
     * Verifies a notification's signature.
     *
     * sha512(order_id + status_code + gross_amount + server_key). The
     * gross_amount must be the exact string Midtrans transmitted — re-deriving
     * it from the order total would produce "150000.00" where Midtrans sent
     * "150000.00" only by luck, and any mismatch fails verification.
     */
    public function verifySignature(
        string $orderId,
        string $statusCode,
        string $grossAmount,
        ?string $signatureKey,
    ): bool {
        if (blank($signatureKey)) {
            return false;
        }

        $expected = hash('sha512', $orderId.$statusCode.$grossAmount.$this->serverKey());

        return hash_equals($expected, $signatureKey);
    }

    /**
     * Each attempt needs its own id: Midtrans permanently rejects reuse of an
     * order_id, so a retry after a failed payment cannot reuse the first one.
     */
    private function nextMidtransOrderId(Order $order): string
    {
        return $order->order_number.'-'.($this->payments->attemptCountFor($order) + 1);
    }

    /**
     * @return array<string, mixed>
     */
    private function buildPayload(Order $order, Payment $payment): array
    {
        $items = $this->itemDetails($order);

        return [
            'transaction_details' => [
                'order_id' => $payment->midtrans_order_id,
                // Midtrans rejects decimals on gross_amount and requires it to
                // equal the sum of item_details exactly.
                'gross_amount' => Money::toInt($order->total),
            ],
            'item_details' => $items,
            'customer_details' => [
                'first_name' => $order->customer_name,
                'phone' => $order->customer_phone,
                'email' => $order->customer_email,
                'shipping_address' => filled($order->address) ? [
                    'first_name' => $order->customer_name,
                    'phone' => $order->customer_phone,
                    'address' => $order->address,
                ] : null,
            ],
            'enabled_payments' => config('midtrans.enabled_payments'),
            'expiry' => [
                'unit' => config('midtrans.expiry.unit'),
                'duration' => (int) config('midtrans.expiry.duration'),
            ],
            'callbacks' => [
                'finish' => route('order.show', $order->order_number),
            ],
        ];
    }

    /**
     * The delivery fee rides along as its own line so the item totals
     * reconcile to gross_amount; Midtrans rejects the transaction otherwise.
     *
     * @return array<int, array<string, mixed>>
     */
    private function itemDetails(Order $order): array
    {
        $items = $order->items
            ->map(static fn (OrderItem $item): array => [
                'id' => (string) $item->product_id,
                'name' => mb_substr($item->product_name, 0, 50),
                'price' => Money::toInt($item->unit_price),
                'quantity' => $item->quantity,
            ])
            ->values()
            ->all();

        if (Money::toInt($order->delivery_fee) > 0) {
            $items[] = [
                'id' => 'DELIVERY',
                'name' => 'Ongkos Kirim',
                'price' => Money::toInt($order->delivery_fee),
                'quantity' => 1,
            ];
        }

        return $items;
    }

    private function expiresAt(): Carbon
    {
        $duration = (int) config('midtrans.expiry.duration');

        return match ((string) config('midtrans.expiry.unit')) {
            'minute', 'minutes' => now()->addMinutes($duration),
            'day', 'days' => now()->addDays($duration),
            default => now()->addHours($duration),
        };
    }

    private function call(callable $callback, string $action, string $midtransOrderId): bool
    {
        $this->configure();

        try {
            $callback();

            return true;
        } catch (Exception $exception) {
            Log::warning("Midtrans {$action} failed", [
                'midtrans_order_id' => $midtransOrderId,
                'message' => $exception->getMessage(),
            ]);

            return false;
        }
    }

    private function configure(): void
    {
        MidtransConfig::$serverKey = $this->serverKey();
        MidtransConfig::$clientKey = (string) config('midtrans.client_key');
        MidtransConfig::$isProduction = (bool) config('midtrans.is_production');
        MidtransConfig::$isSanitized = (bool) config('midtrans.is_sanitized');
        MidtransConfig::$is3ds = (bool) config('midtrans.is_3ds');
        // The SDK's option merging (SnapApiRequestor::remoteCall) reads
        // Config::$curlOptions[CURLOPT_HTTPHEADER] as soon as the array is
        // non-empty, without checking the key exists — and its else-branch
        // leaves $headerOptions undefined. So setting any curl option without
        // also supplying a NON-EMPTY header array crashes the request with
        // "Undefined array key 10023". A User-Agent is the least intrusive
        // header that satisfies it, and it makes our traffic identifiable in
        // Midtrans' logs.
        MidtransConfig::$curlOptions = [
            CURLOPT_TIMEOUT => (int) config('midtrans.timeout'),
            CURLOPT_CONNECTTIMEOUT => 10,
            CURLOPT_HTTPHEADER => ['User-Agent: BakcangPeneleh/1.0 (Laravel)'],
        ];
    }

    private function serverKey(): string
    {
        $key = (string) config('midtrans.server_key');

        if (blank($key)) {
            throw PaymentException::missingCredentials();
        }

        return $key;
    }
}
