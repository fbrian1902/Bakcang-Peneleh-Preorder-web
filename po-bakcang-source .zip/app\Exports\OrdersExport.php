<?php

declare(strict_types=1);

namespace App\Exports;

use App\Models\Order;
use App\Repositories\Contracts\OrderRepositoryInterface;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\ShouldAutoSize;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Concerns\WithMapping;
use Maatwebsite\Excel\Concerns\WithStyles;
use PhpOffice\PhpSpreadsheet\Worksheet\Worksheet;

class OrdersExport implements FromCollection, ShouldAutoSize, WithHeadings, WithMapping, WithStyles
{
    /**
     * @param  array{search?: string|null, status?: string|null, from?: string|null, to?: string|null}  $filters
     */
    public function __construct(
        private readonly OrderRepositoryInterface $orders,
        private readonly array $filters = [],
    ) {}

    public function collection()
    {
        return $this->orders->forExport($this->filters);
    }

    /**
     * @return array<int, string>
     */
    public function headings(): array
    {
        return [
            'Nomor Pesanan',
            'Tanggal Pesan',
            'Pelanggan',
            'Telepon',
            'Email',
            'Metode',
            'Alamat',
            'Jadwal',
            'Status',
            'Item',
            'Subtotal',
            'Ongkir',
            'Total',
            'Status Bayar',
        ];
    }

    /**
     * @param  Order  $order
     * @return array<int, mixed>
     */
    public function map($order): array
    {
        return [
            $order->order_number,
            $order->created_at?->format('Y-m-d H:i'),
            $order->customer_name,
            $order->customer_phone,
            $order->customer_email,
            $order->fulfillment_type->label(),
            $order->address,
            $order->fulfillment_date?->format('Y-m-d').' '.substr((string) $order->fulfillment_time, 0, 5),
            $order->status->label(),
            $order->items->sum('quantity'),
            (float) $order->subtotal,
            (float) $order->delivery_fee,
            (float) $order->total,
            $order->successfulPayment !== null ? 'Lunas' : 'Belum Lunas',
        ];
    }

    /**
     * @return array<int, array<string, mixed>>
     */
    public function styles(Worksheet $sheet): array
    {
        return [
            1 => ['font' => ['bold' => true]],
        ];
    }
}
