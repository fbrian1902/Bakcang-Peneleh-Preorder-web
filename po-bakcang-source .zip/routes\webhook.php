<?php

declare(strict_types=1);

use App\Http\Controllers\Webhook\MidtransWebhookController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Webhook Routes
|--------------------------------------------------------------------------
|
| Loaded by bootstrap/app.php under the `webhook` middleware group, which
| deliberately omits session and CSRF handling: Midtrans posts server-to-server
| with no cookie, so a CSRF-protected endpoint would reject every notification.
|
| Register the full URL in the Midtrans dashboard under
| Settings > Configuration > Payment Notification URL.
|
*/

Route::post('webhook/midtrans', MidtransWebhookController::class)
    ->name('webhook.midtrans');
