<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Http\Controllers\Controller;
use App\Models\Payment;
use App\Repositories\Contracts\PaymentRepositoryInterface;
use App\Services\Payment\PaymentNotificationService;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;
use Throwable;

class PaymentController extends Controller
{
    public function __construct(
        private readonly PaymentRepositoryInterface $payments,
    ) {}

    public function index(Request $request): View
    {
        $filters = [
            'search' => $request->string('search')->toString() ?: null,
            'status' => $request->string('status')->toString() ?: null,
            'from' => $request->date('from')?->toDateString(),
            'to' => $request->date('to')?->toDateString(),
        ];

        return view('admin.payments.index', [
            'payments' => $this->payments->paginateForAdmin($filters, perPage: 15),
            'filters' => $filters,
        ]);
    }

    /**
     * Pulls the authoritative status from Midtrans and applies it.
     *
     * Exists so payments can be reconciled without a public webhook URL —
     * during local development behind no tunnel, or after downtime when
     * Midtrans has exhausted its retries. It funnels through the same
     * notification service as the webhook, so signature, locking and
     * precedence rules all still apply.
     */
    public function sync(
        Payment $payment,
        PaymentNotificationService $notifications,
    ): RedirectResponse {
        try {
            $notifications->syncFromGateway($payment->midtrans_order_id);
        } catch (Throwable $exception) {
            return back()->with('error', $exception->getMessage());
        }

        return back()->with('success', 'Status pembayaran disinkronkan dari Midtrans.');
    }
}
