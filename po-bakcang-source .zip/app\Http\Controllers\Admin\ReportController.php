<?php

declare(strict_types=1);

namespace App\Http\Controllers\Admin;

use App\Exports\OrdersExport;
use App\Exports\PaymentsExport;
use App\Exports\ProductsExport;
use App\Http\Controllers\Controller;
use App\Repositories\Contracts\OrderRepositoryInterface;
use App\Repositories\Contracts\PaymentRepositoryInterface;
use App\Repositories\Contracts\ProductRepositoryInterface;
use App\Services\Report\ReportService;
use Barryvdh\DomPDF\Facade\Pdf;
use Illuminate\Contracts\View\View;
use Illuminate\Http\Request;
use Maatwebsite\Excel\Excel;
use Maatwebsite\Excel\Facades\Excel as ExcelFacade;
use Symfony\Component\HttpFoundation\BinaryFileResponse;
use Symfony\Component\HttpFoundation\Response;

class ReportController extends Controller
{
    public function __construct(
        private readonly OrderRepositoryInterface $orders,
        private readonly PaymentRepositoryInterface $payments,
        private readonly ProductRepositoryInterface $products,
    ) {}

    public function index(Request $request, ReportService $reports): View
    {
        $filters = $this->filters($request);

        return view('admin.reports.index', [
            'filters' => $filters,
            'revenue' => $this->payments->revenueBetween($filters['from'], $filters['to']),
            'orders' => $this->orders->forExport($filters),
            'popular' => $this->products->popular(10),
            'series' => $reports->revenueSeries(30),
        ]);
    }

    /**
     * Excel and CSV share one export class — Laravel Excel switches writer by
     * the requested format, so there is no duplicate mapping to keep in sync.
     */
    public function export(Request $request, string $type, string $format): BinaryFileResponse
    {
        $filters = $this->filters($request);

        [$export, $name] = match ($type) {
            'payments' => [new PaymentsExport($this->payments, $filters), 'pembayaran'],
            'products' => [new ProductsExport($this->products), 'produk'],
            default => [new OrdersExport($this->orders, $filters), 'pesanan'],
        };

        [$writer, $extension] = match ($format) {
            'csv' => [Excel::CSV, 'csv'],
            default => [Excel::XLSX, 'xlsx'],
        };

        $filename = sprintf('laporan-%s-%s.%s', $name, now()->format('Ymd-His'), $extension);

        return ExcelFacade::download($export, $filename, $writer);
    }

    public function pdf(Request $request): Response
    {
        $filters = $this->filters($request);

        $pdf = Pdf::loadView('pdf.report-orders', [
            'orders' => $this->orders->forExport($filters),
            'revenue' => $this->payments->revenueBetween($filters['from'], $filters['to']),
            'filters' => $filters,
            'store' => config('bakcang.store'),
        ])->setPaper('a4', 'landscape');

        return $pdf->download('laporan-pesanan-'.now()->format('Ymd-His').'.pdf');
    }

    /**
     * @return array{search: string|null, status: string|null, from: string|null, to: string|null}
     */
    private function filters(Request $request): array
    {
        return [
            'search' => $request->string('search')->toString() ?: null,
            'status' => $request->string('status')->toString() ?: null,
            'from' => $request->date('from')?->toDateString() ?? today()->startOfMonth()->toDateString(),
            'to' => $request->date('to')?->toDateString() ?? today()->toDateString(),
        ];
    }
}
