<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Enums\FulfillmentType;
use App\Enums\OrderStatus;
use App\Events\OrderCreated;
use App\Models\Order;
use App\Models\Product;
use App\Services\Cart\CartService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Illuminate\Support\Facades\Event;
use Tests\TestCase;

class CheckoutTest extends TestCase
{
    use RefreshDatabase;

    private function fillCart(Product $product, int $quantity = 2): void
    {
        $this->app->make(CartService::class)->add($product->id, $quantity);
    }

    /**
     * @return array<string, mixed>
     */
    private function validPayload(array $overrides = []): array
    {
        return array_merge([
            'customer_name' => 'Siti Rahayu',
            'customer_phone' => '081234567890',
            'customer_email' => null,
            'fulfillment_type' => FulfillmentType::Pickup->value,
            'fulfillment_date' => now()->addDays(2)->toDateString(),
            'fulfillment_time' => '10:00',
        ], $overrides);
    }

    public function test_guest_can_place_a_pickup_order(): void
    {
        Event::fake([OrderCreated::class]);

        $product = Product::factory()->create(['price' => 35000]);
        $this->fillCart($product, 2);

        $response = $this->post(route('checkout.store'), $this->validPayload());

        $order = Order::query()->firstOrFail();

        $response->assertRedirect(route('order.show', $order->order_number));

        $this->assertSame(OrderStatus::AwaitingPayment, $order->status);
        $this->assertSame('70000.00', $order->subtotal);
        $this->assertSame('0.00', $order->delivery_fee);
        $this->assertSame('70000.00', $order->total);
        $this->assertNull($order->address);

        Event::assertDispatched(OrderCreated::class);
    }

    public function test_delivery_order_adds_the_configured_flat_fee(): void
    {
        config(['bakcang.fulfillment.delivery_fee' => 15000]);

        $product = Product::factory()->create(['price' => 40000]);
        $this->fillCart($product, 1);

        $this->post(route('checkout.store'), $this->validPayload([
            'fulfillment_type' => FulfillmentType::Delivery->value,
            'address' => 'Jl. Peneleh 12, Surabaya',
        ]));

        $order = Order::query()->firstOrFail();

        $this->assertSame('40000.00', $order->subtotal);
        $this->assertSame('15000.00', $order->delivery_fee);
        $this->assertSame('55000.00', $order->total);
    }

    public function test_delivery_requires_an_address(): void
    {
        $product = Product::factory()->create();
        $this->fillCart($product);

        $this->post(route('checkout.store'), $this->validPayload([
            'fulfillment_type' => FulfillmentType::Delivery->value,
        ]))->assertSessionHasErrors('address');

        $this->assertDatabaseCount('orders', 0);
    }

    /**
     * Totals must come from the catalogue, never from the request, or a
     * tampered payload could set its own price.
     */
    public function test_posted_price_fields_are_ignored(): void
    {
        $product = Product::factory()->create(['price' => 50000]);
        $this->fillCart($product, 1);

        $this->post(route('checkout.store'), $this->validPayload([
            'subtotal' => 1,
            'total' => 1,
            'delivery_fee' => 0,
        ]));

        $this->assertSame('50000.00', Order::query()->firstOrFail()->total);
    }

    public function test_checkout_is_rejected_when_the_cart_is_empty(): void
    {
        $this->post(route('checkout.store'), $this->validPayload())
            ->assertRedirect();

        $this->assertDatabaseCount('orders', 0);
    }

    public function test_order_number_follows_the_daily_format(): void
    {
        $product = Product::factory()->create();
        $this->fillCart($product);

        $this->post(route('checkout.store'), $this->validPayload());

        $this->assertMatchesRegularExpression(
            '/^BP-'.now()->format('Ymd').'-\d{4}$/',
            Order::query()->firstOrFail()->order_number,
        );
    }

    public function test_the_daily_sequence_increments(): void
    {
        $product = Product::factory()->create();

        foreach (range(1, 3) as $ignored) {
            $this->fillCart($product);
            $this->post(route('checkout.store'), $this->validPayload());
        }

        $numbers = Order::query()->orderBy('id')->pluck('order_number')->all();

        $this->assertSame([
            'BP-'.now()->format('Ymd').'-0001',
            'BP-'.now()->format('Ymd').'-0002',
            'BP-'.now()->format('Ymd').'-0003',
        ], $numbers);
    }

    public function test_the_cart_is_emptied_after_a_successful_checkout(): void
    {
        $product = Product::factory()->create();
        $this->fillCart($product);

        $this->post(route('checkout.store'), $this->validPayload());

        $this->assertTrue($this->app->make(CartService::class)->isEmpty());
    }

    public function test_a_date_inside_the_lead_time_is_rejected(): void
    {
        config(['bakcang.fulfillment.min_lead_days' => 2]);

        $product = Product::factory()->create();
        $this->fillCart($product);

        $this->post(route('checkout.store'), $this->validPayload([
            'fulfillment_date' => now()->toDateString(),
        ]))->assertSessionHasErrors('fulfillment_date');
    }
}
