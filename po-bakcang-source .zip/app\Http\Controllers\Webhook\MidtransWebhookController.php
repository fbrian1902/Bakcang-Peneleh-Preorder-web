<?php

declare(strict_types=1);

namespace App\Http\Controllers\Webhook;

use App\Exceptions\PaymentException;
use App\Http\Controllers\Controller;
use App\Services\Payment\PaymentNotificationService;
use Illuminate\Http\JsonResponse;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Log;
use Throwable;

class MidtransWebhookController extends Controller
{
    public function __construct(
        private readonly PaymentNotificationService $notifications,
    ) {}

    /**
     * Receives Midtrans payment notifications.
     *
     * Response codes are chosen for how Midtrans reacts to them:
     *
     *   200 — accepted, stop retrying.
     *   403 — bad signature; a forged or corrupted payload will never become
     *         valid, so retrying is pointless.
     *   404 — unknown order; likewise permanent.
     *   500 — genuine server fault. This is the only case where a retry can
     *         help, so it is reserved for it. Returning 500 for the other
     *         cases would put Midtrans into an unbounded retry loop.
     */
    public function __invoke(Request $request): JsonResponse
    {
        $payload = $request->all();

        try {
            $payment = $this->notifications->handle($payload);
        } catch (PaymentException $exception) {
            Log::warning('Midtrans notification rejected', [
                'reason' => $exception->reason,
                'message' => $exception->getMessage(),
                'order_id' => $payload['order_id'] ?? null,
            ]);

            return response()->json(
                ['message' => $exception->getMessage()],
                $exception->httpStatus(),
            );
        } catch (Throwable $exception) {
            Log::error('Midtrans notification failed', [
                'message' => $exception->getMessage(),
                'order_id' => $payload['order_id'] ?? null,
                'exception' => $exception,
            ]);

            return response()->json(['message' => 'Internal error.'], 500);
        }

        return response()->json([
            'message' => 'Notification processed.',
            'order_id' => $payment->midtrans_order_id,
            'transaction_status' => $payment->transaction_status->value,
        ]);
    }
}
