<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Payment;
use App\Models\Product;
use App\Models\User;
use App\Services\Report\ReportService;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class AdminDashboardTest extends TestCase
{
    use RefreshDatabase;

    public function test_the_dashboard_renders_with_no_data(): void
    {
        // Every chart divides by a maximum; an empty series must not blow up.
        $this->actingAs(User::factory()->admin()->create())
            ->get(route('admin.dashboard'))
            ->assertOk()
            ->assertSee('Dasbor');
    }

    public function test_the_dashboard_reports_settled_revenue(): void
    {
        $product = Product::factory()->create(['price' => 30000]);
        $order = Order::factory()->pickup()->status(OrderStatus::Confirmed)
            ->create(['subtotal' => 60000, 'total' => 60000]);
        OrderItem::factory()->forProduct($product, 2)->create(['order_id' => $order->id]);

        Payment::factory()->settled()->create([
            'order_id' => $order->id,
            'midtrans_order_id' => $order->order_number.'-1',
            'gross_amount' => 60000,
            'settlement_time' => now(),
        ]);

        $this->actingAs(User::factory()->admin()->create())
            ->get(route('admin.dashboard'))
            ->assertOk()
            ->assertSee('Rp 60.000')
            ->assertSee($product->name);
    }

    /**
     * Revenue must come from settlement, not from order totals, or unpaid
     * orders would be reported as income.
     */
    public function test_unpaid_orders_are_not_counted_as_revenue(): void
    {
        Order::factory()->pickup()->status(OrderStatus::AwaitingPayment)
            ->create(['subtotal' => 999000, 'total' => 999000]);

        // Asserted against the reported figure rather than the page text: the
        // recent-orders panel legitimately displays the order's own total, so
        // "the amount is absent from the page" would be the wrong claim.
        $revenue = $this->app->make(ReportService::class)->dashboard()['revenue'];

        $this->assertSame(0.0, $revenue['today']);
        $this->assertSame(0.0, $revenue['all_time']);

        $this->actingAs(User::factory()->admin()->create())
            ->get(route('admin.dashboard'))
            ->assertOk();
    }

    public function test_the_reports_page_and_exports_respond(): void
    {
        $admin = User::factory()->admin()->create();

        $this->actingAs($admin)->get(route('admin.reports.index'))->assertOk();

        $this->actingAs($admin)
            ->get(route('admin.reports.export', ['type' => 'orders', 'format' => 'csv']))
            ->assertOk();

        $this->actingAs($admin)
            ->get(route('admin.reports.pdf'))
            ->assertOk()
            ->assertHeader('content-type', 'application/pdf');
    }

    public function test_the_payments_index_renders(): void
    {
        $this->actingAs(User::factory()->admin()->create())
            ->get(route('admin.payments.index'))
            ->assertOk();
    }
}
