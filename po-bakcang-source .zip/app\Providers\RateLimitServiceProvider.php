<?php

declare(strict_types=1);

namespace App\Providers;

use Illuminate\Cache\RateLimiting\Limit;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\RateLimiter;
use Illuminate\Support\ServiceProvider;

class RateLimitServiceProvider extends ServiceProvider
{
    public function boot(): void
    {
        // Guest checkout has no account to throttle against, so limits key on
        // IP. Kept generous enough that a family sharing a connection is not
        // blocked, tight enough to stop scripted order spam.
        RateLimiter::for('checkout', static fn (Request $request): Limit => Limit::perMinute(5)->by($request->ip()));

        RateLimiter::for('cart', static fn (Request $request): Limit => Limit::perMinute(60)->by($request->ip()));

        // Each attempt creates a Midtrans transaction, so this is the tightest.
        RateLimiter::for('payment', static fn (Request $request): Limit => Limit::perMinute(10)->by($request->ip()));

        // Midtrans retries aggressively and may deliver several notifications
        // for one order in quick succession. Keyed by order_id rather than IP
        // so a burst about one order cannot starve notifications about others.
        RateLimiter::for('midtrans-webhook', static fn (Request $request): Limit => Limit::perMinute(120)
            ->by((string) ($request->input('order_id') ?? $request->ip())));
    }
}
