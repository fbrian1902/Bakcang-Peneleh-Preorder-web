<?php

declare(strict_types=1);

namespace App\Http\Controllers\Public;

use App\Exceptions\CheckoutException;
use App\Exceptions\PaymentException;
use App\Http\Controllers\Controller;
use App\Models\Order;
use App\Services\Payment\MidtransService;
use Illuminate\Contracts\View\View;
use Illuminate\Http\RedirectResponse;

class OrderController extends Controller
{
    /**
     * Public order tracking.
     *
     * Route-model bound on order_number rather than id: sequential ids would
     * let anyone walk the list and read other customers' orders.
     */
    public function show(Order $order): View
    {
        $order->load(['items', 'payments' => fn ($query) => $query->latest('id')]);

        return view('public.order-status', [
            'order' => $order,
            'payment' => $order->latestPayment,
        ]);
    }

    /**
     * Issues (or reissues) a Snap token so the customer can pay.
     */
    public function pay(Order $order, MidtransService $midtrans): RedirectResponse
    {
        try {
            $payment = $midtrans->createTransaction($order->load('items'));
        } catch (CheckoutException|PaymentException $exception) {
            return back()->with('error', $exception->getMessage());
        }

        return back()->with('snapToken', $payment->snap_token);
    }
}
