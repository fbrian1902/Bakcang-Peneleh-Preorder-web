<?php

declare(strict_types=1);

namespace App\Repositories\Eloquent;

use App\Models\Order;
use App\Models\Payment;
use App\Repositories\Contracts\PaymentRepositoryInterface;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;
use Illuminate\Support\Facades\DB;

class PaymentRepository implements PaymentRepositoryInterface
{
    public function paginateForAdmin(array $filters, int $perPage): LengthAwarePaginator
    {
        return $this->filtered($filters)
            ->with('order')
            ->latest('id')
            ->paginate($perPage)
            ->withQueryString();
    }

    public function findByMidtransOrderId(string $midtransOrderId): ?Payment
    {
        return Payment::query()
            ->where('midtrans_order_id', $midtransOrderId)
            ->first();
    }

    /**
     * Midtrans retries a notification until it receives a 2xx, and does not
     * wait for the previous attempt to finish. Without this row lock two
     * concurrent deliveries could both read the old status, both decide they
     * supersede it, and both write — double-firing the PaymentSettled event.
     */
    public function lockByMidtransOrderId(string $midtransOrderId): ?Payment
    {
        return Payment::query()
            ->where('midtrans_order_id', $midtransOrderId)
            ->lockForUpdate()
            ->first();
    }

    public function create(array $attributes): Payment
    {
        return Payment::create($attributes);
    }

    public function attemptCountFor(Order $order): int
    {
        return $order->payments()->count();
    }

    public function revenueBetween(?string $from, ?string $to): float
    {
        return (float) Payment::query()
            ->paid()
            ->settledBetween($from, $to)
            ->sum('gross_amount');
    }

    public function revenuePerDay(int $days): Collection
    {
        return Payment::query()
            ->paid()
            ->whereNotNull('settlement_time')
            ->whereDate('settlement_time', '>=', today()->subDays($days - 1))
            ->selectRaw('DATE(settlement_time) as day, SUM(gross_amount) as revenue, COUNT(*) as transactions')
            ->groupBy('day')
            ->orderBy('day')
            ->get();
    }

    /**
     * Deliberately the query builder rather than Eloquent: the model casts
     * transaction_status to a TransactionStatus, and this contract promises
     * the raw string that callers pass to TransactionStatus::from().
     */
    public function statusBreakdown(): Collection
    {
        return DB::table('payments')
            ->selectRaw('transaction_status, COUNT(*) as total')
            ->groupBy('transaction_status')
            ->get();
    }

    public function forExport(array $filters): Collection
    {
        return $this->filtered($filters)
            ->with('order')
            ->latest('id')
            ->get();
    }

    /**
     * @param  array{search?: string|null, status?: string|null, from?: string|null, to?: string|null}  $filters
     * @return Builder<Payment>
     */
    private function filtered(array $filters)
    {
        return Payment::query()
            ->status($filters['status'] ?? null)
            ->when(filled($filters['search'] ?? null), function ($query) use ($filters): void {
                $like = '%'.trim((string) $filters['search']).'%';

                $query->where(function ($inner) use ($like): void {
                    $inner->where('midtrans_order_id', 'like', $like)
                        ->orWhere('transaction_id', 'like', $like)
                        ->orWhereHas('order', fn ($o) => $o->where('order_number', 'like', $like));
                });
            })
            ->when(
                filled($filters['from'] ?? null) || filled($filters['to'] ?? null),
                fn ($query) => $query->settledBetween($filters['from'] ?? null, $filters['to'] ?? null),
            );
    }
}
