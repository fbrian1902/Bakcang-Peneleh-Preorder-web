@props([
    'series' => collect(),
    'format' => 'number',
    'label' => '',
])

@php
    use App\Support\Money;

    $values = collect($series)->pluck('value');
    // Guarded against an all-zero series, which would divide by zero and
    // render every bar at full height.
    $max = max((float) $values->max(), 1);
@endphp

<figure {{ $attributes }}>
    @if ($label)
        <figcaption class="sr-only">{{ $label }}</figcaption>
    @endif

    <div class="flex h-32 items-stretch gap-px" role="img" aria-label="{{ $label }}">
        @foreach ($series as $point)
            @php
                $height = max(($point['value'] / $max) * 100, $point['value'] > 0 ? 3 : 1);
                $display = $format === 'currency'
                    ? Money::format($point['value'])
                    : number_format($point['value']);
            @endphp
            <div class="group relative flex flex-1 flex-col justify-end">
                <div class="bg-accent-600" style="height: {{ $height }}%"></div>

                {{-- Reachable by keyboard as well as pointer. --}}
                <div tabindex="0" class="absolute inset-0 focus:outline-none focus-visible:ring-2 focus-visible:ring-accent-600"
                     aria-label="{{ $point['label'] }}: {{ $display }}"></div>

                <div class="pointer-events-none absolute -top-1 left-1/2 z-10 -translate-x-1/2 -translate-y-full
                            whitespace-nowrap rounded border border-zinc-200 bg-white px-2 py-1 text-xs
                            opacity-0 group-hover:opacity-100 group-focus-within:opacity-100">
                    {{ $point['label'] }} · {{ $display }}
                </div>
            </div>
        @endforeach
    </div>

    <div class="mt-1.5 flex justify-between text-xs text-zinc-400">
        <span>{{ $series->first()['label'] ?? '' }}</span>
        <span>{{ $series->last()['label'] ?? '' }}</span>
    </div>
</figure>
