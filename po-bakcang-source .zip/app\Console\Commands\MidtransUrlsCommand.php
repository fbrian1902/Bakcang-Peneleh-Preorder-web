<?php

declare(strict_types=1);

namespace App\Console\Commands;

use Illuminate\Console\Command;
use Illuminate\Support\Facades\Http;
use Throwable;

/**
 * Prints the URLs to paste into the Midtrans dashboard.
 *
 * Free ngrok hostnames change on every restart, so these have to be re-entered
 * often. Reading the host from ngrok's local API removes the transcription step
 * where a typo silently costs you an afternoon of "why isn't the webhook
 * firing".
 */
class MidtransUrlsCommand extends Command
{
    protected $signature = 'bakcang:midtrans-urls';

    protected $description = 'Show the Payment Notification and Finish Redirect URLs for the Midtrans dashboard';

    public function handle(): int
    {
        $host = $this->tunnelHost();
        $source = 'ngrok';

        if ($host === null) {
            $host = rtrim((string) config('app.url'), '/');
            $source = 'APP_URL';
        }

        $this->newLine();
        $this->line("  Host from <options=bold>{$source}</>: {$host}");
        $this->newLine();

        $this->line('  <fg=bright-green;options=bold>Payment Notification URL</>  — Settings › Configuration');
        $this->line("  <options=bold>{$host}/webhook/midtrans</>");
        $this->newLine();

        $this->line('  <fg=bright-green;options=bold>Finish / Unfinish / Error URL</> — Settings › Snap Preference');
        $this->line("  <options=bold>{$host}/pembayaran/selesai</>");
        $this->newLine();

        if ($source === 'ngrok') {
            $this->components->info('Set APP_URL to this host too, then run: php artisan config:clear');

            return self::SUCCESS;
        }

        if (! str_starts_with($host, 'https://')) {
            $this->components->warn(
                'This is an http:// address. Midtrans will not deliver notifications to it — '
                .'start ngrok and re-run this command.'
            );
        }

        return self::SUCCESS;
    }

    /**
     * ngrok exposes its active tunnels on a local API while running.
     */
    private function tunnelHost(): ?string
    {
        try {
            $response = Http::timeout(2)->get('http://127.0.0.1:4040/api/tunnels');
        } catch (Throwable) {
            return null;
        }

        if (! $response->successful()) {
            return null;
        }

        foreach ((array) $response->json('tunnels', []) as $tunnel) {
            $url = $tunnel['public_url'] ?? null;

            // Only the HTTPS tunnel is usable: Midtrans refuses plain http.
            if (is_string($url) && str_starts_with($url, 'https://')) {
                return $url;
            }
        }

        return null;
    }
}
