<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Models\Order;
use App\Models\OrderItem;
use App\Models\Payment;
use App\Models\Product;
use App\Models\User;
use App\Services\Report\InvoiceService;
use Barryvdh\DomPDF\PDF;
use Endroid\QrCode\Builder\Builder;
use Endroid\QrCode\Writer\PngWriter;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class InvoiceTest extends TestCase
{
    use RefreshDatabase;

    private function orderWithItems(): Order
    {
        $order = Order::factory()->pickup()->create(['subtotal' => 70000, 'total' => 70000]);
        $product = Product::factory()->create(['name' => 'Bakcang Babi Original', 'price' => 35000]);

        OrderItem::factory()->forProduct($product, 2)->create(['order_id' => $order->id]);

        return $order->refresh();
    }

    public function test_an_admin_can_download_an_invoice(): void
    {
        $order = $this->orderWithItems();

        $response = $this->actingAs(User::factory()->admin()->create())
            ->get(route('admin.orders.invoice', $order));

        $response->assertOk();
        $response->assertHeader('content-type', 'application/pdf');
        $this->assertStringContainsString(
            "invoice-{$order->order_number}.pdf",
            $response->headers->get('content-disposition'),
        );
    }

    public function test_the_generated_pdf_is_a_real_pdf(): void
    {
        $pdf = $this->app->make(InvoiceService::class)->generate($this->orderWithItems());

        // %PDF- is the format's magic number; anything else means DomPDF
        // returned an error page rather than a document.
        $this->assertStringStartsWith('%PDF-', $pdf->output());
    }

    /**
     * endroid/qr-code must produce a PNG data URI: DomPDF's SVG support is
     * partial and renders QR modules unreliably.
     */
    public function test_the_invoice_embeds_a_png_qr_code(): void
    {
        $order = $this->orderWithItems();

        $html = view('pdf.invoice', [
            'order' => $order->load('items'),
            'payment' => null,
            'store' => config('bakcang.store'),
            'qrCode' => $this->app->make(InvoiceService::class)
                ->generate($order) instanceof PDF
                    ? (new Builder(
                        writer: new PngWriter,
                        data: route('order.show', $order->order_number),
                    ))->build()->getDataUri()
                    : '',
        ])->render();

        $this->assertStringContainsString('data:image/png;base64,', $html);
    }

    public function test_a_paid_invoice_is_stamped_lunas(): void
    {
        $order = $this->orderWithItems();

        Payment::factory()->settled()->create([
            'order_id' => $order->id,
            'midtrans_order_id' => $order->order_number.'-1',
            'gross_amount' => $order->total,
        ]);

        $html = view('pdf.invoice', [
            'order' => $order->refresh()->load('items'),
            'payment' => $order->successfulPayment,
            'store' => config('bakcang.store'),
            'qrCode' => 'data:image/png;base64,AAAA',
        ])->render();

        $this->assertStringContainsString('LUNAS', $html);
        $this->assertStringNotContainsString('BELUM DIBAYAR', $html);
    }

    public function test_an_unpaid_invoice_is_stamped_unpaid(): void
    {
        $html = view('pdf.invoice', [
            'order' => $this->orderWithItems()->load('items'),
            'payment' => null,
            'store' => config('bakcang.store'),
            'qrCode' => 'data:image/png;base64,AAAA',
        ])->render();

        $this->assertStringContainsString('BELUM DIBAYAR', $html);
    }

    public function test_guests_cannot_download_invoices(): void
    {
        $this->get(route('admin.orders.invoice', $this->orderWithItems()))
            ->assertRedirect(route('login'));
    }
}
