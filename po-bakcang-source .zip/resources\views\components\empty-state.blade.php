@props([
    'title' => 'Belum ada data',
    'description' => null,
])

{{-- An empty screen is an invitation to act, so the slot carries the action. --}}
<div {{ $attributes->merge(['class' => 'px-4 py-12 text-center']) }}>
    <h3 class="text-sm font-medium text-zinc-900">{{ $title }}</h3>

    @if ($description)
        <p class="mx-auto mt-1 max-w-sm text-sm text-zinc-500">{{ $description }}</p>
    @endif

    @if (trim($slot) !== '')
        <div class="mt-4">{{ $slot }}</div>
    @endif
</div>
