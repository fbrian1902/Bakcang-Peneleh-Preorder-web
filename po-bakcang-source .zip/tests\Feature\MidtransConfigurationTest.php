<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Exceptions\PaymentException;
use App\Services\Payment\MidtransService;
use Midtrans\Config as MidtransConfig;
use ReflectionMethod;
use Tests\TestCase;

/**
 * Guards the shape of Config::$curlOptions.
 *
 * This asserts an implementation detail on purpose. The Midtrans SDK's option
 * merging (SnapApiRequestor::remoteCall, ApiRequestor::remoteCall) reads
 * Config::$curlOptions[CURLOPT_HTTPHEADER] the moment the array is non-empty,
 * without checking the key exists, and its else-branch leaves $headerOptions
 * undefined. Setting any curl option without a non-empty header array
 * therefore kills every payment with "Undefined array key 10023" — a failure
 * that only appears against the live API and is invisible to mocked tests.
 */
class MidtransConfigurationTest extends TestCase
{
    private function configure(): void
    {
        $method = new ReflectionMethod(MidtransService::class, 'configure');
        $method->invoke($this->app->make(MidtransService::class));
    }

    protected function setUp(): void
    {
        parent::setUp();

        config([
            'midtrans.server_key' => 'SB-Mid-server-test',
            'midtrans.client_key' => 'SB-Mid-client-test',
        ]);
    }

    public function test_curl_options_always_carry_a_non_empty_header_array(): void
    {
        $this->configure();

        $this->assertArrayHasKey(
            CURLOPT_HTTPHEADER,
            MidtransConfig::$curlOptions,
            'Missing CURLOPT_HTTPHEADER makes the SDK fail with "Undefined array key 10023".',
        );

        $this->assertNotEmpty(
            MidtransConfig::$curlOptions[CURLOPT_HTTPHEADER],
            'An empty header array sends the SDK down a branch that leaves $headerOptions undefined.',
        );
    }

    public function test_a_request_timeout_is_configured(): void
    {
        $this->configure();

        // curl defaults to waiting forever; a hung gateway must not hang a
        // customer's checkout request.
        $this->assertArrayHasKey(CURLOPT_TIMEOUT, MidtransConfig::$curlOptions);
        $this->assertGreaterThan(0, MidtransConfig::$curlOptions[CURLOPT_TIMEOUT]);
    }

    public function test_credentials_and_environment_are_applied(): void
    {
        config(['midtrans.is_production' => false]);

        $this->configure();

        $this->assertSame('SB-Mid-server-test', MidtransConfig::$serverKey);
        $this->assertSame('SB-Mid-client-test', MidtransConfig::$clientKey);
        $this->assertFalse(MidtransConfig::$isProduction);
    }

    public function test_a_missing_server_key_is_reported_clearly(): void
    {
        config(['midtrans.server_key' => '']);

        $this->expectException(PaymentException::class);

        $this->configure();
    }
}
