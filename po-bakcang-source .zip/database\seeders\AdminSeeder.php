<?php

declare(strict_types=1);

namespace Database\Seeders;

use App\Models\User;
use Illuminate\Database\Seeder;
use Illuminate\Support\Facades\Hash;

class AdminSeeder extends Seeder
{
    public function run(): void
    {
        $email = (string) env('ADMIN_EMAIL', 'admin@bakcangpeneleh.test');

        $user = User::firstOrNew(['email' => $email]);

        $user->name = (string) env('ADMIN_NAME', 'Administrator');
        $user->email_verified_at = now();

        // Only set a password when creating, so re-seeding never silently
        // resets a password the operator has since changed.
        if (! $user->exists) {
            $user->password = Hash::make((string) env('ADMIN_PASSWORD', 'password'));
        }

        // Assigned directly rather than through create(): is_admin is excluded
        // from the fillable list to block privilege escalation via registration.
        $user->is_admin = true;

        $user->save();
    }
}
