<?php

declare(strict_types=1);

namespace App\Http\Requests\Admin;

use Illuminate\Foundation\Http\FormRequest;
use Illuminate\Validation\Rule;

class StoreProductRequest extends FormRequest
{
    public function authorize(): bool
    {
        return $this->user()?->isAdmin() === true;
    }

    /**
     * @return array<string, mixed>
     */
    public function rules(): array
    {
        return [
            'name' => [
                'required',
                'string',
                'max:100',
                Rule::unique('products', 'name')->ignore($this->route('product')),
            ],
            'price' => ['required', 'numeric', 'min:0', 'max:99999999.99'],
            'is_available' => ['boolean'],
            'image' => $this->imageRules(),
        ];
    }

    /**
     * Validated by decoded image content rather than by filename: `mimes`
     * inspects the real MIME type, and `dimensions` only succeeds on a file
     * the image library can actually parse — so a renamed script cannot pass.
     *
     * @return array<int, mixed>
     */
    private function imageRules(): array
    {
        return [
            $this->isMethod('POST') ? 'nullable' : 'nullable',
            'image',
            'mimes:'.implode(',', config('bakcang.images.mimes')),
            'max:'.config('bakcang.images.max_kilobytes'),
            'dimensions:min_width='.config('bakcang.images.min_width')
                .',min_height='.config('bakcang.images.min_height'),
        ];
    }

    protected function prepareForValidation(): void
    {
        $this->merge([
            'is_available' => $this->boolean('is_available'),
        ]);
    }

    /**
     * @return array<string, string>
     */
    public function attributes(): array
    {
        return [
            'name' => 'nama produk',
            'price' => 'harga',
            'image' => 'gambar',
            'is_available' => 'ketersediaan',
        ];
    }
}
