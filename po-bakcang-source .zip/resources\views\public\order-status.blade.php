@php
    use App\Enums\OrderStatus;
    use App\Support\Money;

    $timeline = [
        OrderStatus::AwaitingPayment,
        OrderStatus::Confirmed,
        OrderStatus::Preparing,
        OrderStatus::Ready,
        OrderStatus::Completed,
    ];
    $isCancelled = $order->status === OrderStatus::Cancelled;
    $currentStep = $isCancelled ? -1 : array_search($order->status, $timeline, true);
@endphp

<x-layouts.public>
    @section('title', 'Pesanan '.$order->order_number)

    <div class="flex flex-wrap items-start justify-between gap-3">
        <div>
            <h1 class="text-xl font-semibold">{{ $order->order_number }}</h1>
            <p class="mt-1 text-sm text-zinc-500">
                Dibuat {{ $order->created_at?->translatedFormat('d F Y, H:i') }} WIB
            </p>
        </div>
        <span class="badge {{ $order->status->badgeClasses() }}">{{ $order->status->label() }}</span>
    </div>

    @if ($order->isPayable())
        <section class="card mt-6 p-5">
            <h2 class="text-sm font-medium">Menunggu pembayaran</h2>
            <p class="mt-1 text-sm text-zinc-600">
                Selesaikan pembayaran dalam {{ config('midtrans.expiry.duration') }}
                {{ config('midtrans.expiry.unit') }}, atau pesanan dibatalkan otomatis.
            </p>
            <form method="POST" action="{{ route('order.pay', $order->order_number) }}" class="mt-4">
                @csrf
                <button type="submit" class="btn-primary">
                    Bayar {{ Money::format($order->total) }}
                </button>
            </form>
        </section>
    @elseif ($order->isPaid())
        <section class="card mt-6 p-5">
            <h2 class="text-sm font-medium">Pembayaran diterima</h2>
            <p class="mt-1 text-sm text-zinc-600">
                {{ $order->successfulPayment?->channelLabel() }} ·
                {{ $order->successfulPayment?->settlement_time?->translatedFormat('d F Y, H:i') }} WIB
            </p>
        </section>
    @endif

    {{-- Derived from the order's own status: with one status column, this is
         the honest representation. --}}
    <section class="card mt-6 p-5">
        <h2 class="text-sm font-medium">Status</h2>

        @if ($isCancelled)
            <p class="mt-3 text-sm text-red-800">Pesanan ini dibatalkan.</p>
        @else
            <ol class="mt-4 space-y-2">
                @foreach ($timeline as $index => $step)
                    @php $done = $index <= $currentStep; @endphp
                    <li class="flex items-center gap-3 text-sm">
                        <span class="w-4 shrink-0 text-center text-xs {{ $done ? 'text-accent-700' : 'text-zinc-300' }}">
                            {{ $done ? '●' : '○' }}
                        </span>
                        <span class="{{ $done ? 'text-zinc-900' : 'text-zinc-400' }}">
                            {{ $step->label() }}
                        </span>
                        @if ($index === $currentStep)
                            <span class="text-xs text-zinc-500">— saat ini</span>
                        @endif
                    </li>
                @endforeach
            </ol>
        @endif
    </section>

    <div class="mt-6 grid gap-6 md:grid-cols-2">
        <section class="card p-5">
            <h2 class="text-sm font-medium">Rincian</h2>
            <ul class="mt-3 divide-y divide-zinc-200 text-sm">
                @foreach ($order->items as $item)
                    <li class="flex items-start justify-between gap-3 py-2">
                        <div class="min-w-0">
                            <p class="truncate">{{ $item->product_name }}</p>
                            <p class="mt-0.5 text-xs text-zinc-500">
                                {{ $item->quantity }} × {{ Money::format($item->unit_price) }}
                            </p>
                        </div>
                        <p class="shrink-0 tabular-nums">{{ Money::format($item->line_total) }}</p>
                    </li>
                @endforeach
            </ul>

            <dl class="mt-3 space-y-1.5 border-t border-zinc-200 pt-3 text-sm">
                <div class="flex justify-between">
                    <dt class="text-zinc-500">Subtotal</dt>
                    <dd class="tabular-nums">{{ Money::format($order->subtotal) }}</dd>
                </div>
                <div class="flex justify-between">
                    <dt class="text-zinc-500">Ongkos kirim</dt>
                    <dd class="tabular-nums">{{ Money::format($order->delivery_fee) }}</dd>
                </div>
                <div class="flex justify-between border-t border-zinc-200 pt-2 font-semibold">
                    <dt>Total</dt>
                    <dd class="tabular-nums">{{ Money::format($order->total) }}</dd>
                </div>
            </dl>
        </section>

        <section class="card p-5">
            <h2 class="text-sm font-medium">{{ $order->fulfillment_type->label() }}</h2>
            <dl class="mt-3 space-y-2.5 text-sm">
                <div>
                    <dt class="text-xs text-zinc-500">Atas nama</dt>
                    <dd>{{ $order->customer_name }}</dd>
                </div>
                <div>
                    <dt class="text-xs text-zinc-500">Kontak</dt>
                    <dd>{{ $order->customer_phone }}</dd>
                </div>
                @if ($order->address)
                    <div>
                        <dt class="text-xs text-zinc-500">Alamat</dt>
                        <dd>{{ $order->address }}</dd>
                    </div>
                @endif
                <div>
                    <dt class="text-xs text-zinc-500">Jadwal</dt>
                    <dd>
                        {{ $order->fulfillment_date?->translatedFormat('l, d F Y') }}
                        @if ($order->fulfillment_time)
                            · {{ substr($order->fulfillment_time, 0, 5) }} WIB
                        @endif
                    </dd>
                </div>
                @if ($order->notes)
                    <div>
                        <dt class="text-xs text-zinc-500">Catatan</dt>
                        <dd>{{ $order->notes }}</dd>
                    </div>
                @endif
            </dl>
        </section>
    </div>

    {{-- Snap is only loaded on the page that can actually use it. --}}
    @if (filled(config('midtrans.client_key')))
        @push('scripts')
            <script src="{{ config('midtrans.snap_url') }}"
                    data-client-key="{{ config('midtrans.client_key') }}"></script>

            @if (session('snapToken'))
                <script>
                    document.addEventListener('DOMContentLoaded', () => {
                        // Every branch reloads rather than rendering a result:
                        // Snap's callbacks report what the browser saw, which
                        // proves nothing. The status shown after the reload
                        // comes from the webhook Midtrans sent to the server.
                        window.snap.pay(@json(session('snapToken')), {
                            onSuccess: () => window.location.reload(),
                            onPending: () => window.location.reload(),
                            onError: () => window.location.reload(),
                            onClose: () => window.location.reload(),
                        });
                    });
                </script>
            @endif
        @endpush
    @endif
</x-layouts.public>
