<?php

declare(strict_types=1);

namespace App\Exceptions;

use RuntimeException;

/**
 * Carries an explicit reason so callers can map it to an HTTP status without
 * matching on message text — which would break the moment a message is
 * reworded or translated.
 */
class PaymentException extends RuntimeException
{
    public const REASON_INVALID_SIGNATURE = 'invalid_signature';

    public const REASON_UNKNOWN_ORDER = 'unknown_order';

    public const REASON_AMOUNT_MISMATCH = 'amount_mismatch';

    public const REASON_GATEWAY_FAILURE = 'gateway_failure';

    public const REASON_MISCONFIGURED = 'misconfigured';

    public readonly string $reason;

    public function __construct(string $message, string $reason)
    {
        parent::__construct($message);

        $this->reason = $reason;
    }

    public static function invalidSignature(string $orderId): self
    {
        return new self(
            "Tanda tangan notifikasi tidak valid untuk order {$orderId}.",
            self::REASON_INVALID_SIGNATURE,
        );
    }

    public static function unknownOrder(string $midtransOrderId): self
    {
        return new self(
            "Tidak ada pembayaran yang cocok dengan {$midtransOrderId}.",
            self::REASON_UNKNOWN_ORDER,
        );
    }

    public static function amountMismatch(string $expected, string $received): self
    {
        return new self(
            "Nominal pembayaran tidak cocok: mengharapkan {$expected}, menerima {$received}.",
            self::REASON_AMOUNT_MISMATCH,
        );
    }

    public static function gatewayFailure(string $message): self
    {
        return new self("Midtrans menolak permintaan: {$message}", self::REASON_GATEWAY_FAILURE);
    }

    public static function missingCredentials(): self
    {
        return new self(
            'Kredensial Midtrans belum dikonfigurasi. Isi MIDTRANS_SERVER_KEY dan MIDTRANS_CLIENT_KEY.',
            self::REASON_MISCONFIGURED,
        );
    }

    /**
     * The HTTP status a webhook response should carry.
     *
     * Only a genuine server fault returns 5xx, because that is the sole case
     * where a Midtrans retry could succeed. A bad signature or unknown order
     * will never become valid, so retrying them is pointless — and returning
     * 500 would trap Midtrans in an unbounded retry loop.
     */
    public function httpStatus(): int
    {
        return match ($this->reason) {
            self::REASON_INVALID_SIGNATURE => 403,
            self::REASON_UNKNOWN_ORDER, self::REASON_AMOUNT_MISMATCH => 404,
            // Misconfiguration and gateway outages are ours to fix, and a
            // retry after we fix them should succeed.
            default => 500,
        };
    }
}
