<?php

declare(strict_types=1);

namespace App\Enums;

/**
 * Mirrors the `orders.status` ENUM.
 *
 * There is no dedicated "paid" state: payment success is represented by
 * `confirmed`, which the Midtrans webhook sets once a settlement or capture
 * notification is verified.
 */
enum OrderStatus: string
{
    case AwaitingPayment = 'awaiting_payment';
    case Confirmed = 'confirmed';
    case Preparing = 'preparing';
    case Ready = 'ready';
    case Completed = 'completed';
    case Cancelled = 'cancelled';

    public function label(): string
    {
        return match ($this) {
            self::AwaitingPayment => 'Menunggu Pembayaran',
            self::Confirmed => 'Dikonfirmasi',
            self::Preparing => 'Sedang Disiapkan',
            self::Ready => 'Siap',
            self::Completed => 'Selesai',
            self::Cancelled => 'Dibatalkan',
        };
    }

    /**
     * Badge styling.
     *
     * Only the three states a human acts on are tinted — needs payment, is
     * done, went wrong. The rest stay neutral, so colour still means something
     * when it appears.
     */
    public function badgeClasses(): string
    {
        return match ($this) {
            self::AwaitingPayment => 'border-amber-200 bg-amber-50 text-amber-800',
            self::Completed => 'border-accent-100 bg-accent-50 text-accent-800',
            self::Cancelled => 'border-red-200 bg-red-50 text-red-800',
            default => 'border-zinc-200 bg-zinc-50 text-zinc-700',
        };
    }

    /**
     * States an admin may move this order into next.
     *
     * Deliberately forward-only. `awaiting_payment` cannot be advanced by
     * hand because only a verified Midtrans notification may confirm an
     * order — allowing a manual jump would let staff mark an unpaid order
     * as paid, which no later reconciliation could detect.
     *
     * @return array<int, self>
     */
    public function allowedTransitions(): array
    {
        return match ($this) {
            self::AwaitingPayment => [self::Cancelled],
            self::Confirmed => [self::Preparing, self::Cancelled],
            self::Preparing => [self::Ready, self::Cancelled],
            self::Ready => [self::Completed, self::Cancelled],
            self::Completed, self::Cancelled => [],
        };
    }

    public function canTransitionTo(self $target): bool
    {
        return in_array($target, $this->allowedTransitions(), strict: true);
    }

    public function isTerminal(): bool
    {
        return $this->allowedTransitions() === [];
    }

    /**
     * Whether the order has been paid for and is in the kitchen pipeline.
     */
    public function isActive(): bool
    {
        return in_array($this, [self::Confirmed, self::Preparing, self::Ready], strict: true);
    }

    /**
     * @return array<string, string> value => label, for select inputs
     */
    public static function options(): array
    {
        return array_reduce(
            self::cases(),
            static fn (array $carry, self $case): array => $carry + [$case->value => $case->label()],
            [],
        );
    }
}
