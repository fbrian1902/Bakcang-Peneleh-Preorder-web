<x-layouts.admin title="Ubah produk">
    <form method="POST" action="{{ route('admin.products.update', $product) }}" enctype="multipart/form-data">
        <x-product-form :product="$product" />
    </form>
</x-layouts.admin>
