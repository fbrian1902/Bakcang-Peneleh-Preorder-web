@php use App\Support\Money; @endphp

<x-layouts.admin title="Dasbor">
    <div class="grid gap-3 sm:grid-cols-2 xl:grid-cols-5">
        <x-stat-tile label="Pesanan hari ini" :value="number_format($counts['today'])" />
        <x-stat-tile label="Menunggu bayar" :value="number_format($counts['awaiting_payment'])" />
        <x-stat-tile label="Dikonfirmasi" :value="number_format($counts['confirmed'])" />
        <x-stat-tile label="Disiapkan" :value="number_format($counts['preparing'])" />
        <x-stat-tile label="Siap" :value="number_format($counts['ready'])" />
    </div>

    {{-- Sourced from payments.settlement_time, not order dates, so unpaid
         orders never appear as income. --}}
    <div class="mt-3 grid gap-3 sm:grid-cols-3">
        <x-stat-tile label="Pendapatan hari ini" :value="Money::format($revenue['today'])" />
        <x-stat-tile label="Bulan ini" :value="Money::format($revenue['month'])" />
        <x-stat-tile label="Total" :value="Money::format($revenue['all_time'])" />
    </div>

    <div class="mt-6 grid gap-6 lg:grid-cols-2">
        <section class="card p-5">
            <h2 class="text-sm font-medium">Pendapatan 14 hari</h2>
            <x-bar-chart class="mt-4" :series="$charts['revenue']" format="currency" label="Pendapatan harian" />
        </section>

        <section class="card p-5">
            <h2 class="text-sm font-medium">Pesanan 14 hari</h2>
            <x-bar-chart class="mt-4" :series="$charts['orders']" label="Pesanan harian" />
        </section>
    </div>

    <div class="mt-6 grid gap-6 lg:grid-cols-3">
        <section class="card p-5">
            <h2 class="text-sm font-medium">Status pembayaran</h2>

            @if ($charts['payment_status']->isEmpty())
                <x-empty-state title="Belum ada transaksi" />
            @else
                <ul class="mt-4 space-y-2 text-sm">
                    @foreach ($charts['payment_status']->sortByDesc('value') as $slice)
                        <li class="flex justify-between">
                            <span>{{ $slice['label'] }}</span>
                            <span class="tabular-nums text-zinc-500">{{ number_format($slice['value']) }}</span>
                        </li>
                    @endforeach
                </ul>
            @endif
        </section>

        <section class="card p-5">
            <h2 class="text-sm font-medium">Produk terlaris</h2>

            @if ($popular->isEmpty())
                <x-empty-state title="Belum ada penjualan" />
            @else
                <ol class="mt-4 space-y-2 text-sm">
                    @foreach ($popular as $item)
                        <li class="flex justify-between gap-3">
                            <span class="min-w-0 truncate">{{ $item->product_name }}</span>
                            <span class="shrink-0 tabular-nums text-zinc-500">
                                {{ number_format($item->total_quantity) }} pcs
                            </span>
                        </li>
                    @endforeach
                </ol>
            @endif
        </section>

        <section class="card p-5">
            <div class="flex items-center justify-between">
                <h2 class="text-sm font-medium">Pesanan terbaru</h2>
                <a href="{{ route('admin.orders.index') }}" class="text-sm text-accent-700 hover:underline">Semua</a>
            </div>

            @if ($recent->isEmpty())
                <x-empty-state title="Belum ada pesanan" />
            @else
                <ul class="mt-4 divide-y divide-zinc-200 text-sm">
                    @foreach ($recent as $order)
                        <li>
                            <a href="{{ route('admin.orders.show', $order) }}"
                               class="flex items-start justify-between gap-3 py-2 hover:bg-zinc-50">
                                <div class="min-w-0">
                                    <p class="truncate">{{ $order->customer_name }}</p>
                                    <p class="mt-0.5 text-xs text-zinc-500">{{ $order->order_number }}</p>
                                </div>
                                <div class="shrink-0 text-right">
                                    <p class="tabular-nums">{{ Money::format($order->total) }}</p>
                                    <span class="badge mt-1 {{ $order->status->badgeClasses() }}">
                                        {{ $order->status->label() }}
                                    </span>
                                </div>
                            </a>
                        </li>
                    @endforeach
                </ul>
            @endif
        </section>
    </div>
</x-layouts.admin>
