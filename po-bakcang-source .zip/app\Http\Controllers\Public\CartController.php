<?php

declare(strict_types=1);

namespace App\Http\Controllers\Public;

use App\Http\Controllers\Controller;
use App\Models\Product;
use App\Services\Cart\CartService;
use Illuminate\Http\RedirectResponse;
use Illuminate\Http\Request;

class CartController extends Controller
{
    public function __construct(
        private readonly CartService $cart,
    ) {}

    public function add(Request $request, Product $product): RedirectResponse
    {
        $validated = $request->validate([
            'quantity' => ['nullable', 'integer', 'min:1', 'max:'.config('bakcang.cart.max_quantity_per_item')],
        ]);

        // CartService re-reads price from the catalogue and merges with any
        // existing line for this product, satisfying UNIQUE (order_id, product_id).
        $this->cart->add($product->id, (int) ($validated['quantity'] ?? 1));

        return back()->with('success', "{$product->name} ditambahkan ke keranjang.");
    }

    public function update(Request $request, Product $product): RedirectResponse
    {
        $validated = $request->validate([
            'quantity' => ['required', 'integer', 'min:0', 'max:'.config('bakcang.cart.max_quantity_per_item')],
        ]);

        $this->cart->updateQuantity($product->id, (int) $validated['quantity']);

        return back();
    }

    public function remove(Product $product): RedirectResponse
    {
        $this->cart->remove($product->id);

        return back()->with('success', 'Item dihapus dari keranjang.');
    }
}
