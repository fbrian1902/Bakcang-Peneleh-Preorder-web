<?php

declare(strict_types=1);

namespace App\Repositories\Eloquent;

use App\Enums\OrderStatus;
use App\Models\Order;
use App\Repositories\Contracts\OrderRepositoryInterface;
use Illuminate\Contracts\Pagination\LengthAwarePaginator;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Support\Collection;

class OrderRepository implements OrderRepositoryInterface
{
    public function paginateForAdmin(array $filters, int $perPage): LengthAwarePaginator
    {
        return $this->filtered($filters)
            ->with(['latestPayment'])
            ->withCount('items')
            ->latest('id')
            ->paginate($perPage)
            ->withQueryString();
    }

    public function findByNumber(string $orderNumber): ?Order
    {
        return Order::query()
            ->with(['items', 'payments'])
            ->where('order_number', $orderNumber)
            ->first();
    }

    public function lockForUpdate(int $orderId): ?Order
    {
        return Order::query()
            ->whereKey($orderId)
            ->lockForUpdate()
            ->first();
    }

    public function create(array $attributes): Order
    {
        return Order::create($attributes);
    }

    /**
     * Reads the highest sequence issued for the day and returns the next one.
     *
     * This is deliberately not atomic with the insert that follows. Taking a
     * table lock to make it so would serialise every checkout; instead the
     * UNIQUE index on order_number turns a collision into an exception, and
     * OrderService retries. Contention is rare enough that optimistic retry
     * costs far less than pessimistic locking.
     */
    public function nextDailySequence(string $datePrefix): int
    {
        $pattern = $datePrefix.'-%';

        $highest = Order::query()
            ->where('order_number', 'like', $pattern)
            ->selectRaw('MAX(CAST(SUBSTRING_INDEX(order_number, "-", -1) AS UNSIGNED)) as seq')
            ->value('seq');

        return ((int) $highest) + 1;
    }

    public function dashboardCounts(): array
    {
        // One grouped pass rather than five COUNT queries.
        $byStatus = Order::query()
            ->selectRaw('status, COUNT(*) as total')
            ->groupBy('status')
            ->pluck('total', 'status');

        return [
            'today' => Order::query()->whereDate('created_at', today())->count(),
            'awaiting_payment' => (int) $byStatus->get(OrderStatus::AwaitingPayment->value, 0),
            'confirmed' => (int) $byStatus->get(OrderStatus::Confirmed->value, 0),
            'preparing' => (int) $byStatus->get(OrderStatus::Preparing->value, 0),
            'ready' => (int) $byStatus->get(OrderStatus::Ready->value, 0),
        ];
    }

    public function recent(int $limit): Collection
    {
        return Order::query()
            ->with('latestPayment')
            ->latest('id')
            ->limit($limit)
            ->get();
    }

    public function ordersPerDay(int $days): Collection
    {
        return Order::query()
            ->whereDate('created_at', '>=', today()->subDays($days - 1))
            ->selectRaw('DATE(created_at) as day, COUNT(*) as orders')
            ->groupBy('day')
            ->orderBy('day')
            ->get();
    }

    public function forExport(array $filters): Collection
    {
        return $this->filtered($filters)
            ->with(['items', 'successfulPayment'])
            ->latest('id')
            ->get();
    }

    public function updateStatus(Order $order, OrderStatus $status): Order
    {
        $order->update(['status' => $status]);

        return $order->refresh();
    }

    /**
     * @param  array{search?: string|null, status?: string|null, from?: string|null, to?: string|null}  $filters
     * @return Builder<Order>
     */
    private function filtered(array $filters)
    {
        return Order::query()
            ->search($filters['search'] ?? null)
            ->status($filters['status'] ?? null)
            ->createdBetween($filters['from'] ?? null, $filters['to'] ?? null);
    }
}
