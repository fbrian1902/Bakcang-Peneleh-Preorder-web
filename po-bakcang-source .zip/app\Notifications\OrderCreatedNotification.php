<?php

declare(strict_types=1);

namespace App\Notifications;

use App\Models\Order;
use App\Support\Money;
use Illuminate\Bus\Queueable;
use Illuminate\Contracts\Queue\ShouldQueue;
use Illuminate\Notifications\Messages\MailMessage;
use Illuminate\Notifications\Notification;

class OrderCreatedNotification extends Notification implements ShouldQueue
{
    use Queueable;

    public function __construct(public readonly Order $order) {}

    /**
     * @return array<int, string>
     */
    public function via(object $notifiable): array
    {
        return ['mail'];
    }

    public function toMail(object $notifiable): MailMessage
    {
        return (new MailMessage)
            ->subject("Pesanan {$this->order->order_number} Diterima")
            ->greeting("Halo {$this->order->customer_name},")
            ->line('Terima kasih! Pesanan Anda sudah kami terima dan sedang menunggu pembayaran.')
            ->line("Nomor Pesanan: **{$this->order->order_number}**")
            ->line('Total: '.Money::format($this->order->total))
            ->action('Bayar Sekarang', route('order.show', $this->order->order_number))
            ->line('Pesanan akan otomatis dibatalkan jika pembayaran tidak diselesaikan sebelum batas waktu.');
    }
}
