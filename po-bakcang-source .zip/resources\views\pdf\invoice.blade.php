@php use App\Support\Money; @endphp
{{--
    DomPDF renders a small, older CSS subset: no flexbox, no grid, no custom
    properties. Layout therefore uses tables and floats, and all styles are
    inlined here rather than pulled from the Tailwind bundle.
--}}
<!DOCTYPE html>
<html lang="id">
<head>
    <meta charset="utf-8">
    <title>Invoice {{ $order->order_number }}</title>
    <style>
        @page { margin: 28px 32px; }
        body { font-family: DejaVu Sans, sans-serif; font-size: 11px; color: #1C1917; line-height: 1.5; }
        .head { width: 100%; border-bottom: 2px solid #1F4D2E; padding-bottom: 14px; }
        .head td { vertical-align: top; }
        .brand { font-size: 20px; font-weight: bold; color: #1F4D2E; }
        .muted { color: #78716C; }
        .right { text-align: right; }
        .doc-title { font-size: 15px; font-weight: bold; letter-spacing: 1px; text-transform: uppercase; }
        .num { font-family: DejaVu Sans Mono, monospace; font-size: 13px; font-weight: bold; }
        .panel { width: 100%; margin-top: 20px; }
        .panel td { vertical-align: top; width: 50%; padding-right: 16px; }
        .label { font-size: 9px; text-transform: uppercase; letter-spacing: 0.8px; color: #78716C; }
        table.items { width: 100%; border-collapse: collapse; margin-top: 20px; }
        table.items th {
            background: #F1F6F2; color: #1F4D2E; text-align: left;
            padding: 8px; font-size: 9px; text-transform: uppercase; letter-spacing: 0.6px;
            border-bottom: 1px solid #BAD7C3;
        }
        table.items td { padding: 8px; border-bottom: 1px solid #EFEBE1; }
        .totals { width: 46%; margin-left: 54%; margin-top: 14px; border-collapse: collapse; }
        .totals td { padding: 5px 8px; }
        .totals .grand td { border-top: 2px solid #1F4D2E; font-size: 14px; font-weight: bold; color: #1F4D2E; }
        .stamp {
            display: inline-block; padding: 5px 14px; border-radius: 12px;
            font-size: 11px; font-weight: bold;
        }
        .paid { background: #DCEBE0; color: #1F4D2E; border: 1px solid #8FBB9E; }
        .unpaid { background: #FCE4E8; color: #9A1730; border: 1px solid #D14257; }
        .foot { margin-top: 26px; border-top: 1px solid #EFEBE1; padding-top: 14px; font-size: 9px; color: #78716C; }
    </style>
</head>
<body>
    <table class="head">
        <tr>
            <td>
                <div class="brand">{{ $store['name'] }}</div>
                <div class="muted" style="margin-top:4px">{{ $store['address'] }}</div>
                <div class="muted">{{ $store['phone'] }} · {{ $store['email'] }}</div>
            </td>
            <td class="right" style="width:38%">
                <div class="doc-title">Invoice</div>
                <div class="num" style="margin-top:4px">{{ $order->order_number }}</div>
                <div class="muted" style="margin-top:4px">
                    {{ $order->created_at?->translatedFormat('d F Y, H:i') }} WIB
                </div>
                <div style="margin-top:8px">
                    @if ($order->isPaid())
                        <span class="stamp paid">LUNAS</span>
                    @else
                        <span class="stamp unpaid">BELUM DIBAYAR</span>
                    @endif
                </div>
            </td>
        </tr>
    </table>

    <table class="panel">
        <tr>
            <td>
                <div class="label">Ditagihkan kepada</div>
                <div style="margin-top:4px; font-weight:bold">{{ $order->customer_name }}</div>
                <div class="muted">{{ $order->customer_phone }}</div>
                @if ($order->customer_email)
                    <div class="muted">{{ $order->customer_email }}</div>
                @endif
                @if ($order->address)
                    <div class="muted" style="margin-top:4px">{{ $order->address }}</div>
                @endif
            </td>
            <td>
                <div class="label">{{ $order->fulfillment_type->label() }}</div>
                <div style="margin-top:4px; font-weight:bold">
                    {{ $order->fulfillment_date?->translatedFormat('l, d F Y') }}
                    @if ($order->fulfillment_time)
                        · {{ substr($order->fulfillment_time, 0, 5) }} WIB
                    @endif
                </div>
                <div class="label" style="margin-top:10px">Status pesanan</div>
                <div style="margin-top:2px">{{ $order->status->label() }}</div>
                @if ($payment)
                    <div class="label" style="margin-top:10px">Metode pembayaran</div>
                    <div style="margin-top:2px">{{ $payment->channelLabel() }}</div>
                @endif
            </td>
        </tr>
    </table>

    <table class="items">
        <thead>
            <tr>
                <th style="width:50%">Produk</th>
                <th class="right" style="width:14%">Harga</th>
                <th class="right" style="width:12%">Qty</th>
                <th class="right" style="width:24%">Jumlah</th>
            </tr>
        </thead>
        <tbody>
            @foreach ($order->items as $item)
                <tr>
                    <td>{{ $item->product_name }}</td>
                    <td class="right">{{ Money::format($item->unit_price) }}</td>
                    <td class="right">{{ $item->quantity }}</td>
                    <td class="right">{{ Money::format($item->line_total) }}</td>
                </tr>
            @endforeach
        </tbody>
    </table>

    <table class="totals">
        <tr>
            <td class="muted">Subtotal</td>
            <td class="right">{{ Money::format($order->subtotal) }}</td>
        </tr>
        <tr>
            <td class="muted">Ongkos kirim</td>
            <td class="right">{{ Money::format($order->delivery_fee) }}</td>
        </tr>
        <tr class="grand">
            <td>Total</td>
            <td class="right">{{ Money::format($order->total) }}</td>
        </tr>
    </table>

    @if ($order->notes)
        <div style="margin-top:18px">
            <div class="label">Catatan</div>
            <div style="margin-top:3px">{{ $order->notes }}</div>
        </div>
    @endif

    <table class="foot">
        <tr>
            <td style="vertical-align:middle">
                <div>Pindai untuk melacak status pesanan ini.</div>
                <div style="margin-top:3px">{{ route('order.show', $order->order_number) }}</div>
                @if ($payment?->transaction_id)
                    <div style="margin-top:6px">Transaction ID: {{ $payment->transaction_id }}</div>
                @endif
                <div style="margin-top:6px">Terima kasih telah memesan di {{ $store['name'] }}.</div>
            </td>
            <td class="right" style="width:110px">
                <img src="{{ $qrCode }}" alt="" style="width:96px; height:96px">
            </td>
        </tr>
    </table>
</body>
</html>
