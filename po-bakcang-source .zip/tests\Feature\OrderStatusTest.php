<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Models\Order;
use App\Models\User;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class OrderStatusTest extends TestCase
{
    use RefreshDatabase;

    private function admin(): User
    {
        return User::factory()->admin()->create();
    }

    public function test_an_admin_can_advance_a_confirmed_order(): void
    {
        $order = Order::factory()->status(OrderStatus::Confirmed)->create();

        $this->actingAs($this->admin())
            ->patch(route('admin.orders.status', $order), ['status' => OrderStatus::Preparing->value])
            ->assertRedirect();

        $this->assertSame(OrderStatus::Preparing, $order->refresh()->status);
    }

    /**
     * Only a verified Midtrans notification may mark an order paid. A manual
     * path would let staff confirm an unpaid order with nothing to detect it.
     */
    public function test_an_unpaid_order_cannot_be_confirmed_by_hand(): void
    {
        $order = Order::factory()->status(OrderStatus::AwaitingPayment)->create();

        $this->actingAs($this->admin())
            ->patch(route('admin.orders.status', $order), ['status' => OrderStatus::Confirmed->value])
            ->assertSessionHasErrors('status');

        $this->assertSame(OrderStatus::AwaitingPayment, $order->refresh()->status);
    }

    public function test_status_cannot_move_backwards(): void
    {
        $order = Order::factory()->status(OrderStatus::Ready)->create();

        $this->actingAs($this->admin())
            ->patch(route('admin.orders.status', $order), ['status' => OrderStatus::Preparing->value])
            ->assertSessionHasErrors('status');

        $this->assertSame(OrderStatus::Ready, $order->refresh()->status);
    }

    public function test_a_completed_order_is_terminal(): void
    {
        $order = Order::factory()->status(OrderStatus::Completed)->create();

        $this->actingAs($this->admin())
            ->patch(route('admin.orders.status', $order), ['status' => OrderStatus::Cancelled->value])
            ->assertSessionHasErrors('status');

        $this->assertSame(OrderStatus::Completed, $order->refresh()->status);
    }

    public function test_an_order_may_be_cancelled_from_any_live_state(): void
    {
        foreach ([OrderStatus::AwaitingPayment, OrderStatus::Confirmed, OrderStatus::Preparing, OrderStatus::Ready] as $from) {
            $order = Order::factory()->status($from)->create();

            $this->actingAs($this->admin())
                ->patch(route('admin.orders.status', $order), ['status' => OrderStatus::Cancelled->value]);

            $this->assertSame(OrderStatus::Cancelled, $order->refresh()->status, "from {$from->value}");
        }
    }

    public function test_an_invalid_status_value_is_rejected(): void
    {
        $order = Order::factory()->status(OrderStatus::Confirmed)->create();

        $this->actingAs($this->admin())
            ->patch(route('admin.orders.status', $order), ['status' => 'teleported'])
            ->assertSessionHasErrors('status');
    }

    public function test_non_admins_cannot_change_status(): void
    {
        $order = Order::factory()->status(OrderStatus::Confirmed)->create();

        $this->actingAs(User::factory()->create())
            ->patch(route('admin.orders.status', $order), ['status' => OrderStatus::Preparing->value])
            ->assertNotFound();

        $this->assertSame(OrderStatus::Confirmed, $order->refresh()->status);
    }

    /**
     * The public tracking page is keyed by order_number so ids cannot be
     * walked, but it is still world-readable by design.
     */
    public function test_the_public_order_page_resolves_by_order_number(): void
    {
        $order = Order::factory()->create();

        $this->get(route('order.show', $order->order_number))
            ->assertOk()
            ->assertSee($order->order_number);
    }
}
