<?php

declare(strict_types=1);

namespace App\DataTransferObjects;

use App\Enums\FraudStatus;
use App\Enums\TransactionStatus;
use Illuminate\Support\Carbon;

/**
 * A parsed Midtrans HTTP notification.
 */
final readonly class MidtransNotificationData
{
    /**
     * @param  array<string, mixed>  $raw
     */
    public function __construct(
        public string $orderId,
        public string $statusCode,
        public string $grossAmount,
        public ?string $signatureKey,
        public TransactionStatus $transactionStatus,
        public ?FraudStatus $fraudStatus,
        public ?string $transactionId,
        public ?string $paymentType,
        public ?Carbon $transactionTime,
        public ?Carbon $settlementTime,
        public ?Carbon $expiryTime,
        public array $raw,
    ) {}

    /**
     * @param  array<string, mixed>  $payload
     */
    public static function fromArray(array $payload): self
    {
        return new self(
            orderId: (string) ($payload['order_id'] ?? ''),
            statusCode: (string) ($payload['status_code'] ?? ''),

            // Kept as the exact string Midtrans sent. The signature is computed
            // over this literal value, so reformatting it (150000 vs 150000.00)
            // silently breaks verification.
            grossAmount: (string) ($payload['gross_amount'] ?? ''),

            signatureKey: $payload['signature_key'] ?? null,
            transactionStatus: TransactionStatus::from((string) ($payload['transaction_status'] ?? 'pending')),
            fraudStatus: filled($payload['fraud_status'] ?? null)
                ? FraudStatus::tryFrom((string) $payload['fraud_status'])
                : null,
            transactionId: $payload['transaction_id'] ?? null,
            paymentType: $payload['payment_type'] ?? null,
            transactionTime: self::parseJakartaTime($payload['transaction_time'] ?? null),
            settlementTime: self::parseJakartaTime($payload['settlement_time'] ?? null),
            expiryTime: self::parseJakartaTime($payload['expiry_time'] ?? null),
            raw: $payload,
        );
    }

    /**
     * Midtrans emits timestamps as bare "Y-m-d H:i:s" strings in Western
     * Indonesian Time with no offset attached. Parsing them in the app's own
     * timezone would be correct only by accident, so the zone is stated
     * explicitly and the value converted to the application timezone.
     */
    private static function parseJakartaTime(?string $value): ?Carbon
    {
        if (blank($value)) {
            return null;
        }

        return Carbon::parse($value, 'Asia/Jakarta')->setTimezone(config('app.timezone'));
    }
}
