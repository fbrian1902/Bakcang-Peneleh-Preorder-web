<?php

declare(strict_types=1);

namespace Tests\Feature;

use App\Enums\OrderStatus;
use App\Models\Order;
use Illuminate\Foundation\Testing\RefreshDatabase;
use Tests\TestCase;

class PaymentReturnTest extends TestCase
{
    use RefreshDatabase;

    public function test_it_sends_the_customer_to_their_order(): void
    {
        $order = Order::factory()->create();

        $this->get(route('payment.return', [
            'order_id' => $order->order_number.'-1',
            'status_code' => '200',
            'transaction_status' => 'settlement',
        ]))->assertRedirect(route('order.show', $order->order_number));
    }

    public function test_it_strips_multi_digit_attempt_suffixes(): void
    {
        $order = Order::factory()->create();

        $this->get(route('payment.return', ['order_id' => $order->order_number.'-12']))
            ->assertRedirect(route('order.show', $order->order_number));
    }

    /**
     * The redirect is a customer's browser, not Midtrans. Anyone can request it
     * with any query string, so its status parameters must never move an order.
     */
    public function test_redirect_parameters_cannot_mark_an_order_paid(): void
    {
        $order = Order::factory()->status(OrderStatus::AwaitingPayment)->create();

        $this->get(route('payment.return', [
            'order_id' => $order->order_number.'-1',
            'status_code' => '200',
            'transaction_status' => 'settlement',
            'fraud_status' => 'accept',
        ]))->assertRedirect();

        $this->assertSame(OrderStatus::AwaitingPayment, $order->refresh()->status);
        $this->assertFalse($order->isPaid());
        $this->assertDatabaseCount('payments', 0);
    }

    public function test_an_unknown_order_falls_back_to_the_landing_page(): void
    {
        $this->get(route('payment.return', ['order_id' => 'BP-20260101-9999-1']))
            ->assertRedirect(route('landing'))
            ->assertSessionHas('error');
    }

    public function test_a_missing_order_id_falls_back_to_the_landing_page(): void
    {
        $this->get(route('payment.return'))->assertRedirect(route('landing'));
    }
}
