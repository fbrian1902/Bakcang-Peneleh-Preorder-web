<?php

declare(strict_types=1);

namespace App\Models;

use App\Enums\FraudStatus;
use App\Enums\TransactionStatus;
use Database\Factories\PaymentFactory;
use Illuminate\Database\Eloquent\Builder;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Relations\BelongsTo;
use Illuminate\Support\Carbon;

/**
 * A single Midtrans payment attempt. An order accumulates one row per attempt,
 * since Midtrans refuses to reuse an order_id after a failed or expired try.
 *
 * @property int $id
 * @property int $order_id
 * @property string $midtrans_order_id
 * @property string|null $snap_token
 * @property string|null $redirect_url
 * @property string|null $transaction_id
 * @property string|null $payment_type
 * @property string $gross_amount
 * @property TransactionStatus $transaction_status
 * @property FraudStatus|null $fraud_status
 * @property Carbon|null $transaction_time
 * @property Carbon|null $settlement_time
 * @property Carbon|null $expiry_time
 * @property array<string, mixed>|null $raw_notification
 */
class Payment extends Model
{
    /** @use HasFactory<PaymentFactory> */
    use HasFactory;

    protected $fillable = [
        'order_id',
        'midtrans_order_id',
        'snap_token',
        'redirect_url',
        'transaction_id',
        'payment_type',
        'gross_amount',
        'transaction_status',
        'fraud_status',
        'transaction_time',
        'settlement_time',
        'expiry_time',
        'raw_notification',
    ];

    protected function casts(): array
    {
        return [
            'transaction_status' => TransactionStatus::class,
            'fraud_status' => FraudStatus::class,
            'gross_amount' => 'decimal:2',
            'transaction_time' => 'datetime',
            'settlement_time' => 'datetime',
            'expiry_time' => 'datetime',
            'raw_notification' => 'array',
        ];
    }

    /**
     * @return BelongsTo<Order, $this>
     */
    public function order(): BelongsTo
    {
        return $this->belongsTo(Order::class);
    }

    /**
     * @param  Builder<$this>  $query
     */
    public function scopePaid(Builder $query): void
    {
        $query->whereIn('transaction_status', [
            TransactionStatus::Settlement->value,
            TransactionStatus::Capture->value,
        ]);
    }

    /**
     * @param  Builder<$this>  $query
     */
    public function scopeStatus(Builder $query, TransactionStatus|string|null $status): void
    {
        $query->when(
            filled($status),
            fn (Builder $q) => $q->where(
                'transaction_status',
                $status instanceof TransactionStatus ? $status->value : $status,
            ),
        );
    }

    /**
     * @param  Builder<$this>  $query
     */
    public function scopeSettledBetween(Builder $query, ?string $from, ?string $to): void
    {
        $query->when(filled($from), fn (Builder $q) => $q->whereDate('settlement_time', '>=', $from))
            ->when(filled($to), fn (Builder $q) => $q->whereDate('settlement_time', '<=', $to));
    }

    /**
     * Money genuinely received.
     *
     * A `capture` paired with fraud_status `challenge` is held pending manual
     * review in the Midtrans dashboard and must not be treated as revenue,
     * which is why both fields are consulted.
     */
    public function isSuccessful(): bool
    {
        if (! $this->transaction_status->isPaid()) {
            return false;
        }

        return $this->fraud_status === null || $this->fraud_status->isCleared();
    }

    public function isExpired(): bool
    {
        return $this->expiry_time !== null && $this->expiry_time->isPast();
    }

    /**
     * Snap tokens are single-use and die with their expiry window.
     */
    public function hasUsableSnapToken(): bool
    {
        return filled($this->snap_token)
            && $this->transaction_status->isPending()
            && ! $this->isExpired();
    }

    public function channelLabel(): string
    {
        return match ($this->payment_type) {
            null => '—',
            'qris' => 'QRIS',
            'gopay' => 'GoPay',
            'shopeepay' => 'ShopeePay',
            'bank_transfer' => 'Transfer Bank / VA',
            'echannel' => 'Mandiri Bill',
            'credit_card' => 'Kartu Kredit',
            'cstore' => 'Gerai Retail',
            default => str($this->payment_type)->replace('_', ' ')->title()->value(),
        };
    }
}
