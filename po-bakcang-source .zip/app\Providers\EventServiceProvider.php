<?php

declare(strict_types=1);

namespace App\Providers;

use App\Events\OrderCreated;
use App\Events\OrderStatusChanged;
use App\Events\PaymentSettled;
use App\Listeners\SendOrderCreatedNotification;
use App\Listeners\SendOrderStatusChangedNotification;
use App\Listeners\SendPaymentReceivedNotification;
use Illuminate\Foundation\Support\Providers\EventServiceProvider as ServiceProvider;

class EventServiceProvider extends ServiceProvider
{
    /**
     * Mapped explicitly rather than relying on discovery, so the wiring is
     * greppable and survives config caching.
     *
     * @var array<class-string, array<int, class-string>>
     */
    protected $listen = [
        OrderCreated::class => [
            SendOrderCreatedNotification::class,
        ],
        PaymentSettled::class => [
            SendPaymentReceivedNotification::class,
        ],
        OrderStatusChanged::class => [
            SendOrderStatusChangedNotification::class,
        ],
    ];

    public function shouldDiscoverEvents(): bool
    {
        return false;
    }
}
