<?php

declare(strict_types=1);

namespace Database\Seeders;

use Illuminate\Database\Console\Seeds\WithoutModelEvents;
use Illuminate\Database\Seeder;

class DatabaseSeeder extends Seeder
{
    use WithoutModelEvents;

    /**
     * DemoOrderSeeder is intentionally excluded so this stays safe to run in
     * production. Seed sample orders explicitly with:
     *
     *   php artisan db:seed --class=DemoOrderSeeder
     */
    public function run(): void
    {
        $this->call([
            AdminSeeder::class,
            ProductSeeder::class,
        ]);
    }
}
