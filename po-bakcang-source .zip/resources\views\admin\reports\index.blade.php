@php use App\Support\Money; @endphp

<x-layouts.admin title="Laporan">
    <form method="GET" class="flex flex-wrap items-end gap-2">
        <div>
            <label for="from" class="label">Dari</label>
            <input id="from" name="from" type="date" value="{{ $filters['from'] }}" class="field">
        </div>
        <div>
            <label for="to" class="label">Sampai</label>
            <input id="to" name="to" type="date" value="{{ $filters['to'] }}" class="field">
        </div>
        <button type="submit" class="btn-secondary">Terapkan</button>
    </form>

    <div class="mt-6 grid gap-3 sm:grid-cols-3">
        <x-stat-tile label="Pendapatan" :value="Money::format($revenue)"
                     hint="Transaksi yang settle pada rentang ini" />
        <x-stat-tile label="Pesanan" :value="number_format($orders->count())" />
        <x-stat-tile label="Rata-rata per pesanan"
                     :value="Money::format($orders->count() > 0 ? $orders->sum('total') / $orders->count() : 0)" />
    </div>

    <section class="card mt-6 p-5">
        <h2 class="text-sm font-medium">Pendapatan 30 hari</h2>
        <x-bar-chart class="mt-4" :series="$series" format="currency" label="Pendapatan 30 hari terakhir" />
    </section>

    {{-- Filters ride along in the query string so what downloads matches
         exactly what is on screen. --}}
    <section class="card mt-6 p-5">
        <h2 class="text-sm font-medium">Unduh laporan</h2>
        <p class="mt-1 text-sm text-zinc-500">Mengikuti rentang tanggal di atas.</p>

        <div class="mt-4 divide-y divide-zinc-200 text-sm">
            @foreach ([
                ['orders', 'Pesanan', 'Seluruh pesanan beserta pelanggan, jadwal dan totalnya.'],
                ['payments', 'Pembayaran', 'Transaksi Midtrans beserta status dan waktu settlement.'],
                ['products', 'Produk', 'Peringkat produk berdasarkan jumlah terjual.'],
            ] as [$type, $label, $description])
                <div class="flex flex-wrap items-center justify-between gap-3 py-3">
                    <div class="min-w-0">
                        <p class="font-medium">{{ $label }}</p>
                        <p class="mt-0.5 text-zinc-500">{{ $description }}</p>
                    </div>
                    <div class="flex shrink-0 gap-3">
                        <a href="{{ route('admin.reports.export', ['type' => $type, 'format' => 'xlsx'] + request()->query()) }}"
                           class="text-accent-700 hover:underline">Excel</a>
                        <a href="{{ route('admin.reports.export', ['type' => $type, 'format' => 'csv'] + request()->query()) }}"
                           class="text-accent-700 hover:underline">CSV</a>
                    </div>
                </div>
            @endforeach

            <div class="flex flex-wrap items-center justify-between gap-3 py-3">
                <div class="min-w-0">
                    <p class="font-medium">Ringkasan PDF</p>
                    <p class="mt-0.5 text-zinc-500">Laporan pesanan siap cetak.</p>
                </div>
                <a href="{{ route('admin.reports.pdf', request()->query()) }}"
                   class="shrink-0 text-accent-700 hover:underline">PDF</a>
            </div>
        </div>
    </section>

    <section class="card mt-6 p-5">
        <h2 class="text-sm font-medium">Produk terlaris</h2>

        @if ($popular->isEmpty())
            <x-empty-state title="Belum ada penjualan"
                description="Data muncul setelah ada pesanan yang tidak dibatalkan." />
        @else
            <div class="mt-3 overflow-x-auto">
                <table class="w-full text-sm">
                    <thead class="border-b border-zinc-200 text-left text-xs text-zinc-500">
                        <tr>
                            <th scope="col" class="py-2 font-medium">Produk</th>
                            <th scope="col" class="py-2 text-right font-medium">Terjual</th>
                            <th scope="col" class="py-2 text-right font-medium">Pendapatan</th>
                        </tr>
                    </thead>
                    <tbody class="divide-y divide-zinc-200">
                        @foreach ($popular as $item)
                            <tr>
                                <td class="py-2">{{ $item->product_name }}</td>
                                <td class="py-2 text-right tabular-nums">{{ number_format($item->total_quantity) }} pcs</td>
                                <td class="py-2 text-right tabular-nums">{{ Money::format($item->total_revenue) }}</td>
                            </tr>
                        @endforeach
                    </tbody>
                </table>
            </div>
        @endif
    </section>
</x-layouts.admin>
